# Parameters, Configuration, and Utilities Guide

This guide explains three tools that are often confused in RTL and UVM:
**parameters**, **configuration objects**, and **utilities**.  Choosing the
right one keeps the MAC reusable, avoids hidden test dependencies, and makes
failures easier to reproduce.

## 1. The decision in one table

| Need | Use | Why | Repository example |
| --- | --- | --- | --- |
| A compile-time hardware fact shared by RTL and TB | RTL parameter or central macro | It determines widths, encodings, or elaborated structure | `AXIS_DATA_WIDTH` in `src/rtl_verilog/mac_params.vh` |
| A per-test runtime policy for an environment or agent | Typed UVM configuration object | Tests can select a policy without editing drivers/monitors | `mac_env_cfg_c`, `axi_agent_cfg_c`, `rs_agent_cfg_c` |
| A test-run switch selected on the command line | Plusarg | It changes one invocation without source edits | `+MAC_FUNCTIONAL_COVERAGE`, `+UVM_TESTNAME` |
| Repeated deterministic calculation or formatting | Stateless utility function | One implementation prevents inconsistent protocol math | `mac_hvl_utils_c::keep_from_valid_bytes()` |
| A repeated wait that must never hang | Bounded utility task | It standardizes timeout and caller-owned error reporting | `mac_wait_utils_c::wait_for_count_at_least()` |
| A DUT behavior that software must program | APB transaction/sequence | It is real hardware state, not testbench configuration | Writes to `REG_GLOBAL_CONTROL` |

The key distinction is timing and ownership:

```text
compile/elaboration: RTL parameters/macros
build phase:         UVM configuration objects through config_db
run phase:           sequences, APB programming, plusargs already read
any phase:           stateless utilities; bounded waits during tasks
```

## 2. Parameters: fixed design facts

### What and why

A parameter or macro is a value that describes the design’s shape or a
protocol constant.  It must not be used for a scenario choice that changes
from one test to another.  A 512-bit AXI data path is a design fact; whether a
particular test sends ten frames is a test policy.

The shared RTL header is `src/rtl_verilog/mac_params.vh`:

```verilog
`define AXIS_DATA_WIDTH 512
`define AXIS_KEEP_WIDTH 64
`define MAC_ADDR_WIDTH 48
`define CRC_WIDTH 32
```

These values are centralized so RTL and the testbench do not silently use
different widths.  Do not duplicate `512`, `64`, `48`, or `32` in a new test
or utility when one of these names represents the intended protocol fact.

### When to add a parameter

Add a parameter only when all of these are true:

1. The value changes hardware structure, interface geometry, encoding, or a
   project-wide protocol definition.
2. Multiple RTL modules or the TB need the same value.
3. It is stable for one elaborated design instance, not a random test choice.

Examples:

| Scenario | Correct choice | Reason |
| --- | --- | --- |
| Supporting a 256-bit and 512-bit AXI data path in different builds | Parameter/macro for data and keep width | Interface and packing logic elaborate differently. |
| Ethernet source/destination address width | Central parameter | 48 bits is a protocol fact. |
| One test sends 1, 10, or 100 frames | Sequence/test field | It is scenario stimulus, not hardware shape. |
| Enabling RX in a test | APB write | RX enable is a runtime DUT register state. |
| Turning functional coverage on for one run | Plusarg/environment config | It is a verification-run policy. |

### Parameter rules

- Keep widths explicit and paired: a 512-bit data path has 64 byte lanes.
- Name constants by meaning, not by where they happen to be used.
- Keep synthesizable RTL free of SystemVerilog packages, classes, or structs.
- If a test needs to know a design constant, include/reuse the shared source;
  do not create a test-local conflicting copy.
- Do not use a macro as a mutable variable.  A macro is textual substitution,
  not per-test storage.

## 3. UVM configuration: runtime policy passed to components

### What and why

A configuration object is a typed `uvm_object` containing values that UVM
components need during construction and execution.  This project uses typed
objects rather than many unrelated wildcard configuration-database entries.
That gives a single validation point and a printable summary of the selected
policy.

The configuration flow is:

```text
mac_tb_top creates mac_tb_cfg_c
      -> publishes virtual interfaces and bootstrap intent
mac_base_test_c gets mac_tb_cfg_c
      -> creates and fills mac_env_cfg_c plus agent configurations
      -> publishes mac_env_cfg_c to env_h*
environment/agent tops get their configuration
      -> publish each agent configuration to only that agent subtree
driver, monitor, and sequence get the same typed agent configuration
```

### The configuration layers

| Object | Created by | Used for | Examples of fields |
| --- | --- | --- | --- |
| `mac_tb_cfg_c` | `mac_tb_top` | Testbench-wide bindings and bootstrap policy | virtual interfaces, APB bootstrap address/data, reset/config-complete state, RX-ready policy |
| `mac_env_cfg_c` | `mac_base_test_c` | Environment topology and global checking policy | active/passive agent counts, coverage, scoreboard policies, frame limits, RAL handles |
| `axi_agent_cfg_c` | `mac_base_test_c` | AXI agent behavior | VIF, active/passive mode, payload range, default count, monitor/logger options |
| `rs_agent_cfg_c` | `mac_base_test_c` | RS agent behavior | VIF, IPG/length policy, payload range, error injection, monitor/logger options |
| `apb_agent_cfg_c` | `mac_base_test_c` | APB agent policy | VIF, active/passive mode, wait limit, alignment policy, protocol checking, logging |

### Where to configure values

Use the narrowest correct owner.

- `mac_tb_top`: virtual-interface binding and top-level testbench behavior.
  The project rule permits modifying this testbench file for RTL port renames;
  do not change it to make a single scenario pass.
- Base test: shared environment construction, default agent policies, reset,
  APB bootstrap, and configuration publication.
- Derived test: only a scenario-specific override, such as enabling AXI
  stimulus, changing a test’s frame count, enabling coverage, or selecting a
  checker policy required by that scenario.
- Sequence: a per-sequence control such as `num_transactions` or a constrained
  frame field.  It must not mutate shared environment configuration.
- Driver/monitor: consume configuration; they should not decide test policy.

### How `uvm_config_db` is used safely

The producer creates a fully initialized object, validates it before its
consumer is built, and publishes it at the narrowest practical path.  The
consumer retrieves the exact type and key, then fails clearly if missing.

The base test uses this pattern for environment configuration:

```systemverilog
env_cfg_h = mac_env_cfg_c::type_id::create("env_cfg_h");
// Fill counts, agent config arrays, scoreboard policy, and RAL handles.
configure_test();
env_cfg_h.validate();
uvm_config_db#(mac_env_cfg_c)::set(this, "env_h*", "mac_env_cfg", env_cfg_h);
```

The environment obtains it with the matching type and key:

```systemverilog
if (!uvm_config_db#(mac_env_cfg_c)::get(this, "", "mac_env_cfg", cfg_h))
  `uvm_fatal("CONFIG_ERROR", "mac_env_cfg was not supplied")
cfg_h.validate();
```

Avoid broad `set(null, "*", ...)` calls for scenario-specific values.  They
make it difficult to know which component consumed a setting and can override
another test’s intent.  The existing top-level `mac_tb_cfg_c` publication is
a special shared binding established before `run_test`; new test policies
should be scoped below the test/environment.

### Configuration validation is required

Every configuration object in this project has a `validate()` method.  It
catches missing virtual interfaces, invalid active/passive combinations,
inverted payload ranges, bad IPG values, incorrect agent-array sizes, and
invalid APB timing/alignment policies before traffic starts.

Never bypass validation to work around a test failure.  Correct the ownership
or value instead.  A build-phase fatal is much easier to diagnose than a null
VIF or hanging driver during simulation.

## 4. Configuration scenarios and examples

### Scenario A: TX-only frame formatting test

Goal: send client AXI traffic and observe the frame on RS egress.

```systemverilog
function void mac_tx_min_frame_test_c::configure_test();
  super.configure_test();
  env_cfg_h.axi_active_agent_cfgs[0].num_tx_default = 1;
  env_cfg_h.axi_active_agent_cfgs[0].enable_error_injection = 0;
  env_cfg_h.rs_passive_agent_cfgs[0].enable_ipg_check = 0;
endfunction
```

Why these settings belong here:

- `num_tx_default` and error policy are AXI stimulus-agent policy.
- The passive RS monitor disables IPG checking because DUT TX, not the test
  driver, owns the TX IPG timing.
- The test leaves unrelated RX agents at zero; only AXI active and RS passive
  agent counts are enabled in its constructor.

### Scenario B: RX error-injection test

Goal: drive an RS bad-FCS frame and verify it is rejected.

```systemverilog
function void mac_rx_crc_error_test_c::configure_test();
  super.configure_test();
  env_cfg_h.rs_active_agent_cfgs[0].enable_error_injection = 1;
  env_cfg_h.rs_active_agent_cfgs[0].num_frames_default = 1;
endfunction
```

The derived sequence must constrain `crc_error == 1`; merely enabling the
agent’s error-injection capability does not guarantee every randomized frame
has an error.  The test should check a status/counter or an explicit negative
traffic policy after the input frame is complete.

### Scenario C: APB register-access test

Goal: exercise software-visible configuration without data traffic.

Use the existing `apb_agent_cfg_c` created by `mac_base_test_c`.  The test
starts `apb_write_sequence_c` and `apb_read_sequence_c` through the APB
sequencer; it does not directly toggle APB pins.  Keep protocol checking
enabled and use expected-error fields in read/write sequences for accesses
that are intentionally expected to return `PSLVERR`.

Choose APB agent configuration for transport policy, such as
`m_max_wait_cycles` or alignment checking.  Choose an APB sequence for the
specific address/data action.  This separation makes the APB agent reusable
across every register test.

### Scenario D: functional-coverage regression

The base test derives coverage selection from the command line:

```systemverilog
env_cfg_h.has_function_coverage = $test$plusargs("MAC_FUNCTIONAL_COVERAGE");
```

Use the build target that supplies this plusarg:

```bash
cd sim/Questasim
make run_cov TEST=mac_sanity_test_c SEED=12345
```

This is a run-level choice: do not hard-code coverage creation in a single
test just to collect it once.  Use an environment configuration field when a
test genuinely requires coverage behavior as part of its scenario.

### Scenario E: change frame geometry or protocol limits

If the requested change is “support a different hardware bus width,” it is a
design-level parameter change.  Update the central parameter definition,
RTL packing/unpacking, interfaces, and TB-visible equivalent together; then
run the full compile and regression.  Do not fake a 256-bit interface by
changing `min_payload_len` or a sequence constraint.

If the request is “test a 9000-byte frame on the current MAC,” it is runtime
test policy.  Configure payload/frame limits consistently in the environment
and agent configuration, verify their validators accept the range, then
constrain the transaction in the sequence.

## 5. Utilities: shared behavior without shared state

### What makes a good utility?

A utility is a small, deterministic, reusable helper.  It should:

- Have explicit inputs and outputs.
- Have no hierarchy access, `uvm_config_db` lookup, global counter, or hidden
  mutable state.
- Return success/error information rather than issue policy-specific UVM
  errors itself.
- Be named for the transformation or wait it performs.
- Be covered by directed vectors when it implements protocol arithmetic.

The main utility files are:

| Utility | Location | Use it for |
| --- | --- | --- |
| `mac_hvl_utils_c` | `src/hvl_top/pkg/mac_hvl_utils.svh` | Keep masks, valid-byte counts, IPG math, byte queues, endianness, FCS conversion/calculation, diagnostics |
| `mac_wait_utils_c` | `src/hvl_top/pkg/mac_wait_utils.svh` | Bounded config, monitor-count, and queue-drain waits |
| `mac_hvl_constants.svh` | `src/hvl_top/pkg/mac_hvl_constants.svh` | Shared verification constants such as completion timeout and RS IPG default |

### Example: AXI/RS keep-mask conversion

When a sequence, driver, monitor, and checker all need to derive a byte count
from `tkeep`, use the same helper rather than writing four loops:

```systemverilog
function void check_keep(input bit [63:0] keep_mask, input int unsigned keep_width);
  int valid_bytes;
  bit legal_keep;

  legal_keep  = mac_hvl_utils_c::is_contiguous_low_mask(keep_mask, keep_width);
  valid_bytes = mac_hvl_utils_c::valid_bytes_from_keep(keep_mask, keep_width);
  if (!legal_keep)
    `uvm_error("MAC_KEEP", $sformatf("Illegal keep mask %h", keep_mask))
endfunction
```

The utility decides the mathematical result; the monitor or checker decides
whether an invalid result is a warning, an error, or an expected negative-test
outcome.  This is why the utility does not call `uvm_error` itself.

### Example: bounded wait for TX egress

```systemverilog
bit timed_out;

mac_wait_utils_c::wait_for_count_at_least(
    expected_frames,
    env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
    mac_tx_vif,
    MAC_COMPLETION_TIMEOUT_NS,
    timed_out);

if (timed_out)
  `uvm_error("MAC_TX", "Timed out waiting for expected RS egress frames")
```

Use `wait_for_count_at_least()` for RS observations and
`wait_for_axi_count_at_least()` for AXI observations.  The timeout result is
an output so the test can include feature-specific context in its error.
Never replace it with an unbounded `forever` loop.

### Example: FCS and byte ordering

When constructing an expected wire frame, use `encode_be48()` for MAC
addresses, `encode_be16()` for EtherType, and `fcs_to_wire_bytes()` for the
FCS.  These functions encode the project’s wire ordering in one place.  Do
not reverse bytes ad hoc in each sequence; such code often appears to work
until a different address or FCS test exposes the inconsistency.

## 6. Common mistakes and the better choice

| Mistake | Better choice |
| --- | --- |
| Hard-code `512` or `64` in a new component | Reuse the central width parameter/macro. |
| Make a macro for a per-test frame count | Use a sequence/test field or agent configuration. |
| Configure RX enable by changing a UVM object only | Write the DUT APB register; UVM config does not program hardware. |
| Let a sequence edit `env_cfg_h` midway through a run | Set configuration before build; pass local sequence fields for scenario variation. |
| Use global wildcard config settings for a single agent | Publish the typed agent config to its named subtree. |
| Copy `tkeep` loops or FCS conversion into several components | Add/reuse a stateless `mac_hvl_utils_c` helper. |
| Put `uvm_error` inside a generic math utility | Return a status/result; let the caller apply test policy. |
| Wait forever for monitor traffic | Use a bounded `mac_wait_utils_c` wait and report `timed_out`. |

## 7. Author checklist

Before adding a value or helper, ask these questions in order:

1. Does it change elaborated hardware shape or a project-wide protocol fact?
   Use a central parameter/macro.
2. Is it a testbench policy needed by an environment, agent, monitor, or
   driver?  Add a typed field to the appropriate configuration object,
   validate it, and publish it at a narrow scope.
3. Is it a real DUT mode/state?  Program it through APB in the test sequence.
4. Is it only one sequence’s traffic variation?  Use a sequence field and
   constraints.
5. Is it repeated deterministic logic or a bounded wait?  Add/reuse a
   stateless utility with directed tests.
6. Can a future engineer reproduce the setting from the test name, seed, log,
   and configuration printout?  If not, make the policy explicit.

Following this ownership model prevents the two most expensive verification
problems: hidden configuration that changes another test, and duplicated
protocol logic that disagrees between driver, monitor, model, and scoreboard.
