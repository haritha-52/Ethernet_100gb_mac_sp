# 100G Ethernet MAC Documentation

Read these guides in order. They describe the current pure-Verilog RTL and
SystemVerilog/UVM verification environment.

| Guide | Purpose |
|---|---|
| [Architecture](architecture.md) | Data flow, clocks, resets, and directories. |
| [Interfaces](interfaces.md) | AXI, MAC/RS, APB, and packet-marker rules. |
| [RTL coding](rtl_coding_guidelines.md) | Synthesizable Verilog conventions. |
| [UVM coding](uvm_coding_guidelines.md) | Agents, sequences, tests, and logs. |
| [UVM callbacks](callbacks_guide.md) | Beginner guide to callback hooks, registration, and MAC examples. |
| [Verification](verification_guide.md) | Checking and transaction flow. |
| [Test cases](test_case_guide.md) | Creating, organizing, and reviewing tests. |
| [MAC test manifest](../src/hvl_top/test/mac/mac_test_manifest.svh) | Central UVM include registration for feature test aggregators. |
| [MAC testcase plan](../src/hvl_top/testplan/mac_testplan.csv) | Feature ownership and status for the 61 planned MAC tests. |
| [Parameters, configuration, and utilities](parameters_config_utilities_guide.md) | How to select, create, and use reusable controls. |
| [Registers and RAL](registers_ral_guide.md) | APB register values, access semantics, and register-test workflow. |
| [Jumbo and super-jumbo frames](jumbo_super_jumbo.md) | Frame-size profiles, configuration, and regressions. |
| [Simulation and debug](simulation_debug_guide.md) | WSL, Questa, Visualizer, and triage. |
| [Git workflow](git_workflow.md) | Branches, commits, and review. |

## Quick start

```bash
cd /mnt/d/Qsemiai/VLSI/Documents/Protocols/Ethernet/100g/repo/100g_ethernet/sim/Questasim
make check
make regression TESTLIST=../../src/hvl_top/testlists/smoke.list SEED=12345
```

For interactive waveform debug, run `make visualizer TEST=mac_sanity_test_c`.

Remember: a stream beat transfers only when `valid` and `ready` are both `1`
on a rising clock edge.
