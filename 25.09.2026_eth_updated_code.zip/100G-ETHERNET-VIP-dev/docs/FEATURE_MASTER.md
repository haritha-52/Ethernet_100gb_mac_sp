# 100G Ethernet MAC — Master Feature List

## Overview

Single source of truth for all 100G Ethernet MAC features. All features derived **purely from IEEE 802.3-2008 + IEEE 802.3ba-2010** (no RTL references).

**Source:** `truth_source/IEEE_Specs_MAC/`

---

## Summary

| Metric | Value |
|--------|-------|
| Total Features | 14 |
| Owners | 5 |
| IEEE Clauses | 2, 3, 4, 30, 31, 31A, 31B, 4A, 802.3ba |

---

## Feature List

| # | Feature | Owner | IEEE Clause | Status |
|---|---------|-------|-------------|--------|
| F1 | CRC / FCS | E | 3.2.9, 4.2.3.1, 4.2.4.1.2 | `NOT STARTED` |
| F2 | Preamble | A/B | 3.2.1, 4.2.5, 4A.2.9 | `NOT STARTED` |
| F3 | SFD | A/B | 3.2.2, 4.2.5, 4A.2.9 | `NOT STARTED` |
| F4 | Addressing | B | 3.2.3, 3.2.4, 3.2.5, 4.2.4.1.1 | `NOT STARTED` |
| F5 | Frame Format | E | 3.2.6, 3.2.7, 3.2.8, 4.4.2 | `NOT STARTED` |
| F6 | IPG | A | 4.4.2, 4A.2.3.2.1 | `NOT STARTED` |
| F7 | TX Path | A | 4A.1.2.1, 4.2.3, 4A.2.8 | `NOT STARTED` |
| F8 | RX Path | B | 4.2.4, 3.4, 4A.2.9 | `NOT STARTED` |
| F9 | MAC Control | C | 31.3, 31.4, 31.5, 31A.1 | `NOT STARTED` |
| F10 | Pause Frame | C | 31B.1, 31B.2, 31B.3 | `NOT STARTED` |
| F11 | Service Primitives | E | 2.3.1, 2.3.2, 31.3.1, 31.3.2 | `NOT STARTED` |
| F12 | Timing | E | 4.4.2, 4A.4.2, Table 4-2 | `NOT STARTED` |
| F13 | Full Duplex | E | 4.1.1, 4A.1, 4A.3.3 | `NOT STARTED` |
| F14 | Statistics | D | Clause 30, 30.5.1.1 | `NOT STARTED` |

---

## F1: CRC / FCS

| Field | Value |
|-------|-------|
| **Owner** | E (defines algorithm), A (TX compute), B (RX verify) |
| **IEEE Clause** | 3.2.9, 4.2.3.1, 4.2.4.1.2 |

### Spec

> **Polynomial (3.2.9):**
> G(x) = x^32 + x^26 + x^23 + x^22 + x^16 + x^12 + x^11 + x^10 + x^8 + x^7 + x^5 + x^4 + x^2 + x + 1

> **Computation procedure (3.2.9):**
> "Mathematically, the CRC value corresponding to a given MAC frame is defined by the following procedure:"
> - (a) The first 32 bits of the frame are complemented
> - (b) n bits of the protected fields are considered to be coefficients of polynomial M(x) of degree n-1. First bit of DA → x^(n-1), last bit of Data/Pad → x^0
> - (c) M(x) is multiplied by x^32 and divided by G(x), producing remainder R(x) of degree ≤ 31
> - (d) Coefficients of R(x) are a 32-bit sequence
> - (e) The bit sequence is complemented → this is the CRC

> **FCS field (3.2.9):**
> "The FCS field contains a 4-octet (32-bit) CRC value. This value is computed as a function of the contents of the protected fields: DA, SA, Length/Type, MAC Client Data, and Pad."

> **Bit ordering (3.2.9):**
> "The 32 bits of the CRC value are placed in the FCS field so that the x^31 term is the left-most bit of the first octet, and the x^0 term is the right-most bit of the last octet."

> **FCS validation (4.2.4.1.2):**
> "FCS validation is essentially identical to FCS generation. If the bits of the incoming frame (exclusive of the FCS field itself) do not generate a CRC value identical to the one received, an error has occurred and the frame is identified as invalid."

> **Client-supplied FCS (4.2.3.1):**
> "If the MAC supports the use of client-supplied frame check sequence values, then it shall use the client-supplied value, when present. If the use of client-supplied frame check sequence values is not supported, or if the client-supplied frame check sequence value is not present, then the MAC shall compute this value."

### Deliverables

- [ ] CRC32 polynomial G(x) implementation
- [ ] Step-by-step computation: complement → multiply by x^32 → divide by G(x) → complement
- [ ] Initial value: all 1s (complement of first 32 bits)
- [ ] Final XOR: all 1s (complement of remainder)
- [ ] Bit ordering: x^31 = left-most bit of first octet
- [ ] TX: compute CRC over DA+SA+Type+Data+Pad, append 4-octet FCS
- [ ] RX: compute CRC over DA+SA+Type+Data (excluding FCS), compare with received FCS
- [ ] Report frameCheckError on mismatch
- [ ] Optional client-supplied FCS support (if client provides FCS, client also provides Pad)
- [ ] Pascal constant: crcSize = 32

### Dependencies
None (foundational module)

### Consumed By
F7 (TX), F8 (RX), F10 (PAUSE frame FCS)

---

## F2: Preamble

| Field | Value |
|-------|-------|
| **Owner** | A (TX generate), B (RX detect) |
| **IEEE Clause** | 3.2.1, 4.2.5, 4A.2.9 |

### Spec

> **Exact pattern (4.2.5):**
> "The preamble pattern is:"
> `10101010  10101010  10101010  10101010  10101010  10101010  10101010`
> "The bits are transmitted in order, from left to right. The nature of the pattern is such that, for Manchester encoding, it appears as a periodic waveform on the medium that enables bit synchronization."

> **Size (3.2.1):**
> "The Preamble field is a 7-octet field that is used to allow the PLS circuitry to reach its steady-state synchronization with the received packet's timing."

> **Purpose (4.2.5):**
> "In a LAN implementation, most of the Physical Layer components are allowed to provide valid output some number of bit times after being presented valid input signals. Thus it is necessary for a preamble to be sent before the start of data, to allow the PLS circuitry to reach its steady state."

> **TX behavior (4.2.5):**
> "Upon request by TransmitLinkMgmt to transmit the first bit of a new frame, PhysicalSignalEncap shall first transmit the preamble, a bit sequence used for physical medium stabilization and synchronization, followed by the Start Frame Delimiter."

> **RX behavior (4A.2.9):**
> "PhysicalSignalDecap shall begin passing successive bits to ReceiveLinkMgmt for passing to the MAC client." Preamble bits are discarded.

> **Pascal constants (4.2.7.1):**
> `preambleSize = 56; {In bits}`
> `headerSize = 64; {preambleSize + sfdSize}`

### Deliverables

- [ ] TX: generate 7-octet preamble (0x55 × 7) before every frame
- [ ] Preamble pattern: 10101010 repeated 7 times
- [ ] RX: detect preamble pattern for byte synchronization
- [ ] RX: discard preamble bits (not passed to MAC client)
- [ ] Preamble excluded from CRC32 computation
- [ ] Pascal: preambleSize = 56 bits, headerSize = 64 bits

### Dependencies
None

### Consumed By
F7 (TX assembly), F8 (RX disassembly)

---

## F3: SFD

| Field | Value |
|-------|-------|
| **Owner** | A (TX generate), B (RX detect) |
| **IEEE Clause** | 3.2.2, 4.2.5, 4A.2.9 |

### Spec

> **Exact pattern (3.2.2):**
> "The SFD field is the sequence 10101011."

> **Position (3.2.2):**
> "It immediately follows the preamble pattern. A MAC frame starts immediately after the SFD."

> **TX behavior (4.2.5):**
> PhysicalSignalEncap transmits SFD immediately after preamble.

> **RX behavior (4A.2.9):**
> "Upon reception of the sequence 10101011 following the assertion of receiveDataValid, PhysicalSignalDecap shall begin passing successive bits to ReceiveLinkMgmt for passing to the MAC client."

> **Pascal constant (4.2.7.1):**
> `sfdSize = 8; {In bits}`

### Deliverables

- [ ] TX: append SFD (0xD5 = 10101011) after preamble
- [ ] SFD immediately follows preamble
- [ ] RX: detect SFD pattern (10101011)
- [ ] RX: mark frame start after SFD detection
- [ ] RX: begin passing bits to MAC client after SFD
- [ ] Pascal: sfdSize = 8 bits

### Dependencies
F2 (Preamble)

### Consumed By
F7 (TX assembly), F8 (RX disassembly)

---

## F4: Addressing

| Field | Value |
|-------|-------|
| **Owner** | B (RX filter), A (TX insert) |
| **IEEE Clause** | 3.2.3, 3.2.4, 3.2.5, 3.2.3.1, 4.2.4.1.1 |

### Spec

> **Address size (3.2.3):**
> "Each address field shall be 48 bits in length."

> **I/G bit (3.2.3):**
> "The first bit (LSB) shall be used in the Destination Address field as an address type designation bit to identify the Destination Address either as an individual or as a group address. If this bit is 0, it shall indicate that the address field contains an individual address. If this bit is 1, it shall indicate that the address field contains a group address."
> "In the Source Address field, the first bit is reserved and set to 0."

> **U/L bit (3.2.3):**
> "The second bit shall be used to distinguish between locally or globally administered addresses. For globally administered (or U, universal) addresses, the bit is set to 0. If an address is to be assigned locally, this bit shall be set to 1. Note that for the broadcast address, this bit is also a 1."

> **Octet order (3.2.3):**
> "Each octet of each address field shall be transmitted least significant bit first."

> **Address types (3.2.3.1):**
> - **Individual Address:** "The address associated with a particular station on the network."
> - **Group Address:** "A multidestination address, associated with one or more stations on a given network."
>   - **Multicast-Group Address:** "An address associated by higher-level convention with a group of logically related stations."
>   - **Broadcast Address:** "A distinguished, predefined multicast address that always denotes the set of all stations on a given LAN. All 1's in the Destination Address field shall be predefined to be the Broadcast Address."

> **DA field (3.2.4):**
> "The Destination Address field specifies the station(s) for which the MAC frame is intended. It may be an individual or multicast (including broadcast) address."

> **SA field (3.2.5):**
> "The Source Address field specifies the station sending the MAC frame. The Source Address field is not interpreted by the MAC sublayer."

> **Address recognition (4.2.4.1.1):**
> - Individual: "accepts any frame whose DA field contains the individual address of the station"
> - Group: "accepts any frame whose DA field contains the Broadcast address"
> - Multicast: "capable of activating some number of group addresses as specified by higher layers"
> - Promiscuous: "recognizes and accepts all valid frames, regardless of their Destination Address field values"

### Deliverables

- [ ] 48-bit DA field handling (6 octets)
- [ ] 48-bit SA field handling (6 octets)
- [ ] I/G bit decode: bit 0 of DA octet 0 (0=individual, 1=group)
- [ ] U/L bit decode: bit 1 of DA octet 0 (0=universal, 1=local)
- [ ] LSB-first transmission per octet
- [ ] Broadcast detection: DA = FF:FF:FF:FF:FF:FF
- [ ] Individual address match (compare with station address)
- [ ] Multicast group activation/deactivation (programmable)
- [ ] Promiscuous mode (optional: accept all valid frames)
- [ ] SA always individual, not interpreted by MAC

### Dependencies
None

### Consumed By
F7 (TX address insertion), F8 (RX address filtering), F10 (PAUSE DA matching)

---

## F5: Frame Format

| Field | Value |
|-------|-------|
| **Owner** | E (defines parameters), A (TX build), B (RX parse) |
| **IEEE Clause** | 3.2.6, 3.2.7, 3.2.8, 4.4.2, 4A.2.7.1 |

### Spec

> **Frame layout (Figure 3-1):**
> | Field | Octets |
> |-------|--------|
> | Preamble | 7 |
> | SFD | 1 |
> | Destination Address | 6 |
> | Source Address | 6 |
> | Length/Type | 2 |
> | MAC Client Data | 46–1500/1504/1982 |
> | Pad | variable |
> | FCS | 4 |

> **Length/Type field (3.2.6):**
> - ≤ 1500 (0x05DC): Length interpretation — number of MAC client data octets
> - ≥ 1536 (0x0600): Type interpretation — MAC client protocol identifier
> - 1501–1535: Invalid values

> **Client Data field (3.2.7):**
> "Ethernet implementations shall support at least one of three maximum MAC Client Data field sizes:"
> - 1500 octets — basic frames
> - 1504 octets — Q-tagged frames
> - 1982 octets — envelope frames
> "Full data transparency is provided in the sense that any arbitrary sequence of octet values may appear in the MAC Client Data field."

> **Pad field (3.2.8):**
> "If necessary, a Pad field (in units of octets) is appended after the MAC Client Data field prior to calculating and appending the FCS field."
> Pad length = max[0, minFrameSize - (clientDatasize + 2 × addressSize + 48)] bits

> **Frame size limits (Table 4-2, 802.3ba):**
> - minFrameSize = 512 bits (64 octets)
> - maxBasicFrameSize = 1518 octets
> - maxEnvelopeFrameSize = 2000 octets

> **maxFrameSizeLimit (4A.2.7.1):**
> Can be configured to: maxBasicFrameSize, maxBasicFrameSize + qTagPrefixSize (1522), or maxEnvelopeFrameSize (2000).

> **Invalid frame (3.4):**
> "An invalid MAC frame shall be defined as one that meets at least one of the following conditions:"
> - (a) Frame length inconsistent with Length/Type field
> - (b) Not an integral number of octets
> - (c) CRC mismatch

> **Extension field (3.2.10):**
> "The Extension field follows the FCS field... length is in the range of zero to (slotTime-minFrameSize) bits." Not used at 100G (no half duplex).

### Deliverables

- [ ] Length/Type decode: ≤1500=length, ≥1536=type, 1501–1535=invalid
- [ ] Client data size limits: 1500/1504/1982 configurable
- [ ] Pad calculation: max[0, 64 - (data + 14 + 4)] octets
- [ ] Min frame size enforcement: 64 octets (512 bits)
- [ ] Max frame size enforcement: 1518 basic, 2000 envelope
- [ ] maxFrameSizeLimit configuration: 1518/1522/2000
- [ ] Pad excluded from client data count but included in FCS
- [ ] No extension field at 100G (full duplex only)

### Dependencies
None

### Consumed By
F7 (TX frame build), F8 (RX frame parse)

---

## F6: IPG

| Field | Value |
|-------|-------|
| **Owner** | A (TX enforce) |
| **IEEE Clause** | 4.4.2, 4A.2.3.2.1, 4A.4.2 |

### Spec

> **IPG value (Table 4-2):**
> "interPacketGap: 96 bits" — same for all speeds including 100 Gb/s.

> **Purpose (4.2.3.2.2):**
> "The rules for deferring to passing packets ensure a minimum interpacket spacing of interPacketGap bit times. This is intended to provide interpacket recovery time for other CSMA/CD sublayers and for the physical medium."

> **Measurement (4.2.3.2.2):**
> "Note that interPacketGap is the minimum value of the interpacket gap. If necessary for implementation reasons, a transmitting sublayer may use a larger value with a resulting decrease in its throughput."

> **Full duplex IPG (4A.2.3.2.1):**
> "After the last bit of a transmitted frame, the MAC continues to defer for a proper interPacketGap."

> **IPG shrinkage at 100G (802.3ba, NOTE 7):**
> "For 40 Gb/s and 100 Gb/s operation, the received interPacketGap (the spacing between two packets, from the last bit of the FCS field of the first packet to the first bit of the Preamble of the second packet) can have a minimum value of 8 BT (bit times), as measured at the XLGMII or CGMII receive signals at the DTE due to clock tolerance and lane alignment requirements."

> **Measurement points (4A):**
> - 10 Gb/s: 40 BT at XGMII
> - 40/100 Gb/s: 8 BT at XLGMII/CGMII

### Deliverables

- [ ] IPG timer: 96-bit (12-octet) minimum between TX frames
- [ ] Measured from last bit of FCS to first bit of next preamble
- [ ] TX enforces ≥96 bits
- [ ] RX accepts ≥8 BT (100G shrinkage)
- [ ] Configurable to use larger IPG if needed

### Dependencies
None

### Consumed By
F7 (TX deference)

---

## F7: TX Path

| Field | Value |
|-------|-------|
| **Owner** | A |
| **IEEE Clause** | 4A.1.2.1, 4.2.3.1, 4.2.3.3, 4.2.5, 4A.2.3.2.1, 4A.2.8, 31B.3.2.6, 4A.2.7.1 |

### Spec

> **TX encapsulation (4A.1.2.1):**
> "When a MAC client requests the transmission of a frame, the Transmit Data Encapsulation component of the full duplex MAC sublayer constructs the frame from the client-supplied data. It prepends a preamble and a Start Frame Delimiter to the beginning of the frame. Using information provided by the client, the MAC sublayer also appends a Pad at the end of the MAC information field of sufficient length to ensure that the transmitted frame length satisfies a minimum frame-size requirement. It also prepends destination and source addresses, the length/type field, and appends a frame check sequence to provide for error detection."

> **TransmitDataEncap procedure (4A.2.8):**
> ```pascal
> procedure TransmitDataEncap;
> begin
>   with outgoingFrame do
>   begin {Assemble frame}
>     view := fields;
>     destinationField := destinationParam;
>     sourceField := sourceParam;
>     lengthOrTypeField := lengthOrTypeParam;
>     if fcsParamPresent then
>     begin
>       dataField := dataParam;
>       fcsField := fcsParamValue
>     end
>     else
>     begin
>       dataField := ComputePad(dataParam);
>       fcsField := CRC32(outgoingFrame)
>     end;
>     view := bits
>   end {Assemble frame}
>   with outgoingHeader do
>   begin
>     headerView := headerFields;
>     preamble := ...; {* '1010...10,' LSB to MSB*}
>     sfd := ...; {* '10101011,' LSB to MSB*}
>     headerView := headerBits
>   end
> end;
> ```

> **Full duplex TX (4.2.3.2.6):**
> "In full duplex mode, there is never contention for a shared physical medium. Full duplex stations do not defer to received traffic, nor abort transmission, jam, backoff, and reschedule transmissions. Transmissions may be initiated whenever the station has a packet queued, subject only to the interpacket gap."

> **TransmitLinkMgmt (4A.2.8):**
> ```pascal
> function TransmitLinkMgmt: TransmitStatus;
> begin
>   while deferring do nothing;
>   StartTransmit;
>   while transmitting do nothing;
>   LayerMgmtTransmitCounters;
>   TransmitLinkMgmt := transmitOK
> end;
> ```

> **TransmitStatus codes (4A.2.7.1):**
> `TransmitStatus = (transmitDisabled, transmitOK, excessiveCollisionError, lateCollisionErrorStatus);`
> "excessiveCollisionError and lateCollisionErrorStatus are artifacts of the CSMA/CD MAC and maintained here for historical purposes. These codes are never generated by this full duplex MAC."

> **PAUSE inhibit (31B.3.2.6):**
> "Data frame transmission only allowed when pause_timerDone = true."
> PAUSE frame transmission can occur even when paused.

### Deliverables

- [ ] Frame assembly: Preamble+SFD+DA+SA+Type+Data+Pad+FCS
- [ ] TransmitDataEncap: assemble frame from client parameters
- [ ] Pad to 64-octet minimum (ComputePad function)
- [ ] Compute/append FCS (CRC32) or accept client-supplied FCS
- [ ] Defer for IPG (96 bits) after frame (while deferring do nothing)
- [ ] StartTransmit: pass bits to PHY
- [ ] Wait while transmitting
- [ ] Inhibit data TX when paused (MAC Control always allowed)
- [ ] TransmitStatus: transmitOK, transmitDisabled
- [ ] LayerMgmtTransmitCounters: update statistics

### Dependencies
F1 (CRC), F2 (Preamble), F3 (SFD), F4 (Addressing), F5 (Frame Format), F6 (IPG), F10 (PAUSE status)

### Consumed By
F14 (TX events)

---

## F8: RX Path

| Field | Value |
|-------|-------|
| **Owner** | B |
| **IEEE Clause** | 4.2.4.1, 4.2.4.2.1, 3.4, 4A.2.9 |

### Spec

> **RX decapsulation (4.1.2.1.2):**
> "At each receiving station, the arrival of a frame is first detected by the Physical Layer, which responds by synchronizing with the incoming preamble, and by turning on the receiveDataValid signal. As the encoded bits arrive from the medium, they are decoded and translated back into binary data. The Physical Layer passes subsequent bits up to the MAC sublayer, where the leading bits are discarded, up to and including the end of the preamble and Start Frame Delimiter."

> **ReceiveDataDecap function (4A.2.9):**
> ```pascal
> function ReceiveDataDecap: ReceiveStatus;
> var status: ReceiveStatus;
> begin
>   with incomingFrame do
>   begin
>     view := fields;
>     receiveSucceeding := LayerMgmtRecognizeAddress(destinationField);
>     if receiveSucceeding then
>     begin
>       destinationParam := destinationField;
>       sourceParam := sourceField;
>       lengthOrTypeParam := lengthOrTypeField;
>       dataParam := RemovePad(lengthOrTypeField, dataField);
>       fcsParamValue := fcsField;
>       fcsParamPresent := passReceiveFCSMode;
>       exceedsMaxLength := ...;
>       if exceedsMaxLength then status := frameTooLong
>       else if fcsField = CRC32(incomingFrame) then
>         if validLength then status := receiveOK else status := lengthError
>       else if excessBits = 0 then status := frameCheckError
>       else status := alignmentError;
>       LayerMgmtReceiveCounters(status);
>       view := bits
>     end
>   end;
>   ReceiveDataDecap := status
> end;
> ```

> **ReceiveLinkMgmt (4A.2.9):**
> ```pascal
> procedure ReceiveLinkMgmt;
> begin
>   repeat
>     StartReceive;
>     while receiving do nothing;
>     excessBits := frameSize mod 8;
>     frameSize := frameSize - excessBits;
>     receiveSucceeding := (frameSize >= minFrameSize)
>   until receiveSucceeding
> end;
> ```

> **ReceiveStatus codes (4A.2.7.1):**
> `ReceiveStatus = (receiveDisabled, receiveOK, frameTooLong, frameCheckError, lengthError, alignmentError);`

> **Invalid frame (3.4):**
> "An invalid MAC frame shall be defined as one that meets at least one of the following conditions:"
> - (a) Frame length inconsistent with Length/Type
> - (b) Not integral number of octets
> - (c) CRC mismatch

> **Octet truncation (4.2.4.2.1b):**
> "Complete MAC frames that do not contain an integer number of octets are truncated to the nearest octet boundary. If frame check sequence validation detects an error in such a MAC frame, the status code alignmentError is reported."

> **Min frame discard (4.2.4.2.2):**
> "The shortest valid transmission in full duplex mode must be at least minFrameSize in length. A full duplex MAC nevertheless discards received frames containing less than minFrameSize bits."

> **RemovePad (4A.2.9):**
> "Strips padding generated for minFrameSize constraint. When the MAC sublayer operates in the mode that enables passing of the frame check sequence field, it shall not strip the padding."

### Deliverables

- [ ] ReceiveLinkMgmt: StartReceive → wait → truncate to octet boundary
- [ ] Preamble/SFD strip (discard leading bits)
- [ ] Address filter: LayerMgmtRecognizeAddress (individual, group, broadcast, promiscuous)
- [ ] FCS verify: CRC32(incomingFrame) vs received FCS
- [ ] RemovePad: strip pad unless passReceiveFCSMode
- [ ] Invalid frame detection (length mismatch, non-octet, CRC error)
- [ ] Octet truncation: excessBits = frameSize mod 8
- [ ] Min frame discard: frameSize < minFrameSize → discarded (not error)
- [ ] Max frame enforcement: optional truncation
- [ ] ReceiveStatus: receiveOK, frameTooLong, frameCheckError, lengthError, alignmentError
- [ ] LayerMgmtReceiveCounters: update statistics

### Dependencies
F1 (CRC), F2 (Preamble), F3 (SFD), F4 (Addressing), F5 (Frame Format), F13 (passReceiveFCSMode)

### Consumed By
F14 (RX events)

---

## F9: MAC Control

| Field | Value |
|-------|-------|
| **Owner** | C |
| **IEEE Clause** | 31.3, 31.4, 31.5, 31A.1 |

### Spec

> **Architecture (31.1):**
> "This clause specifies an optional MAC Control sublayer (MAC Control) for use with the CSMA/CD MAC. MAC Control provides for real-time control and manipulation of MAC sublayer operation."

> **Transparency (31.1):**
> "Operation of the MAC Control sublayer is transparent to the CSMA/CD MAC."

> **Frame format (31.4.1, Figure 31-3):**
> | Field | Octets |
> |-------|--------|
> | Destination Address | 6 |
> | Source Address | 6 |
> | Length/Type (88-08) | 2 |
> | MAC Control Opcode | 2 |
> | MAC Control Parameters | 0 to (minFrameSize-160)/8 |
> | Reserved (zeros) | variable |

> **Type field (31.4.1.3):**
> "The Length/Type field of a MAC Control frame shall contain the hexadecimal value: 88-08."

> **Opcode field (31.4.1.4):**
> "The MAC Control Opcode field shall contain a 2-octet operation code indicating the MAC Control function. A MAC Control frame shall contain exactly one MAC Control opcode."

> **Parameters field (31.4.1.5):**
> "The MAC Control Parameters field shall contain MAC Control opcode-specific parameters. This field may contain none, one, or more parameters. The length varies from 0 to (minFrameSize-160) bits."

> **Reserved field (31.4.1.6):**
> "The Reserved field is used when the MAC Control parameters do not fill the fixed length MAC Control frame. The Reserved field is transmitted as all zeros."

> **Opcode transmission order (31A):**
> "Opcodes are transmitted high-order octet first. Within each octet, bits are transmitted least-significant bit first."

> **Defined opcodes (31A.1, Table 31A-1):**
> | Opcode | Function | Clause |
> |--------|----------|--------|
> | 0x0000 | Reserved | — |
> | 0x0001 | PAUSE | 31B |
> | 0x0002 | GATE | 64 |
> | 0x0003 | REPORT | 64 |
> | 0x0004 | REGISTER_REQ | 64 |
> | 0x0005 | REGISTER | 64 |
> | 0x0006 | REGISTER_ACK | 64 |
> | 0x0007–0xFFFF | Reserved | — |

> **Generic Rx state machine (31.5.3.4, Figure 31-4):**
> States: BEGIN → WAIT FOR RX → CHECK TYPE → CHECK OPCODE → PASS TO CLIENT / INITIATE MAC CONTROL FUNCTION
> - "The opcode-specific operation is launched as a parallel process by the MAC Control sublayer, and not as a synchronous function."

> **Frame parsing (31.5.1):**
> "MAC Control frames with a length of minFrameSize and a supported opcode field are interpreted and acted upon. MAC Control frames with a length greater than minFrameSize may be either discarded, or truncated to minFrameSize."

> **Unsupported opcode (31.5.2):**
> "If the MAC Control sublayer entity does not support the function requested by the specified opcode, it discards the MAC Control frame."

> **Sink requirement (31.3):**
> "MAC Control sublayer entities shall always sink MAC Control frames."

### Deliverables

- [ ] Detect Type = 0x8808
- [ ] Parse opcode: high-order octet first, LSB first within octet
- [ ] Opcode decode: 0x0001–0x0006
- [ ] Reserved opcodes (0x0000, 0x0007–0xFFFF): discard
- [ ] Parameters field: opcode-specific, variable length
- [ ] Reserved field: zeros to pad to fixed frame length
- [ ] Validate frame length (minFrameSize or truncate)
- [ ] Generic MAC Control Rx state machine
- [ ] Opcode-specific function launch as parallel process
- [ ] MA_CONTROL.request (mandatory): client → MAC Control
- [ ] MA_CONTROL.indication (mandatory): MAC Control → client
- [ ] Control frames consumed, not passed to MAC client

### Dependencies
F5 (Length/Type decode)

### Consumed By
F10 (PAUSE), F11 (Service Primitives), F14 (Control events)

---

## F10: Pause Frame

| Field | Value |
|-------|-------|
| **Owner** | C |
| **IEEE Clause** | 31B.1, 31B.2, 31B.3, 802.3ba |

### Spec

> **Purpose (31B.1):**
> "The PAUSE operation is used to inhibit transmission of data frames for a specified period of time."

> **Multicast address (31B.1):**
> "The globally assigned 48-bit multicast address 01-80-C2-00-00-01 has been reserved for use in MAC Control PAUSE frames for inhibiting transmission of data frames from a DTE in a full duplex mode IEEE 802.3 LAN."

> **Bridge isolation (31B.1):**
> "IEEE 802.1D-conformant bridges will not forward frames sent to this multicast destination address, regardless of the state of the bridge's ports."

> **Data-only inhibit (31B.1):**
> "The PAUSE operation cannot be used to inhibit transmission of MAC Control frames."

> **Full duplex only (31B.1):**
> "PAUSE frames shall only be sent by DTEs configured to the full duplex mode of operation."

> **pause_time parameter (31B.2):**
> "A 2-octet, unsigned integer containing the length of time for which the receiving station is requested to inhibit data frame transmission. The field is transmitted most-significant octet first, and least-significant octet second."

> **pause_quanta unit (31B.2):**
> "The pause_time is measured in units of pause_quanta, equal to 512 bit times of the particular implementation."

> **pause_time range (31B.2):**
> "The range of possible pause_time is 0 to 65535 pause_quanta."

> **PAUSE frame construction (31B.3.1):**
> "Upon receipt of a MA_CONTROL.request primitive containing the PAUSE opcode, the MAC Control sublayer calls MAC:MA_DATA.request with:"
> - (a) destination_address = 01-80-C2-00-00-01
> - (b) source_address = station's individual address
> - (c) length/type = 88-08
> - (d) remainder = PAUSE opcode + pause_time + zeros
> - (e) frame_check_sequence is omitted (computed by MAC)

> **TX state machine (31B.3.2.6, Figure 31B-1):**
> States: BEGIN → INITIALIZE TX → HALT TX → PAUSED → TRANSMIT READY → SEND CONTROL FRAME / SEND DATA FRAME
> - "It is not required that an implementation be able to transmit PAUSE frames."
> - PAUSE frame TX can occur even when paused (pause_timerDone = FALSE)
> - Data frame TX only when pause_timerDone = true

> **Receive state machine (31B.3.4.4, Figure 31B-2):**
> States: Entry → WAIT FOR TRANSMISSION COMPLETION → PAUSE FUNCTION → END PAUSE
> - Validates DA against reserved_multicast_address AND phys_Address
> - Extracts n_quanta_rx = data[17:32]
> - Starts pause_timer(n_quanta_rx × pause_quantum)
> - Waits for in-progress TX to complete before pausing

> **Indication state machine (31B.3.6.4, Figure 31B-3):**
> States: BEGIN → NOT PAUSED → PAUSED
> - Sets pause_status to paused or not_paused
> - Indicates via MA_CONTROL.indication primitive

> **No effect on submitted frame (31B.3.7):**
> "Reception of a PAUSE frame shall not affect the transmission of a MAC frame that has been submitted by the MAC Control sublayer to the underlying MAC (i.e., the MAC:MA_DATA.request service primitive is synchronous, and is never interrupted)."

> **Timing constraints per speed (31B.3.7, 802.3ba):**
> | Speed | Max Delay | Measurement Point |
> |-------|-----------|-------------------|
> | 100 Mb/s (MII) | 1 × pause_quantum | MII |
> | 100 Mb/s (no MII) | (pause_quantum + 64) | MDI |
> | 1 Gb/s | 2 × pause_quantum | MDI |
> | 10 Gb/s (non-10GBASE-T) | 60 × pause_quantum | MDI |
> | 10 Gb/s (10GBASE-T) | 74 × pause_quantum | MDI |
> | 40 Gb/s | 118 × pause_quantum | MDI |
> | **100 Gb/s** | **394 × pause_quantum** | **MDI** |

### Deliverables

- [ ] PAUSE frame detection: DA=01-80-C2-00-00-01 + Type=0x8808 + Opcode=0x0001
- [ ] Pause timer: pause_time × 512 bit times countdown
- [ ] pause_status output: paused / not_paused
- [ ] TX inhibit: data frames blocked when pause_timerDone=false
- [ ] MAC Control frames always allowed (even when paused)
- [ ] PAUSE frame transmission (optional per spec)
- [ ] New PAUSE overrides earlier (reload timer)
- [ ] Wait for in-progress TX before pausing
- [ ] In-progress TX not interrupted by PAUSE reception
- [ ] 100G timing: ≤394 × pause_quantum bit times at MDI
- [ ] TX state diagram (Figure 31B-1)
- [ ] Receive state diagram (Figure 31B-2)
- [ ] Indication state diagram (Figure 31B-3)
- [ ] pause_status indicated via MA_CONTROL.indication

### Dependencies
F1 (CRC for PAUSE frame FCS), F9 (MAC Control frame parsing)

### Consumed By
F7 (TX reads pause_status)

---

## F11: Service Primitives

| Field | Value |
|-------|-------|
| **Owner** | E |
| **IEEE Clause** | 2.3.1, 2.3.2, 31.3.1, 31.3.2 |

### Spec

> **MA_DATA.request (2.3.1.2):**
> ```
> MA_DATA.request (
>     destination_address,
>     source_address,
>     mac_service_data_unit,
>     frame_check_sequence
> )
> ```
> "This primitive defines the transfer of data from a MAC client entity to a single peer entity or multiple peer entities in the case of group addresses."
> - `destination_address`: "may specify either an individual or a group MAC entity address"
> - `source_address`: "if present, must specify an individual MAC address; if omitted, the local MAC sublayer entity will insert a value"
> - `mac_service_data_unit`: "specifies the MAC service data unit to be transmitted"
> - `frame_check_sequence`: "if present, must specify the frame check sequence field; if omitted, the local MAC sublayer entity will compute this field"

> **MA_DATA.indication (2.3.2.2):**
> ```
> MA_DATA.indication (
>     destination_address,
>     source_address,
>     mac_service_data_unit,
>     frame_check_sequence,
>     reception_status
> )
> ```
> "This primitive defines the transfer of data from the MAC sublayer entity (through the optional MAC Control sublayer, if implemented) to the MAC client entity."
> - `reception_status`: "is used to pass status information to the MAC client entity"

> **Mandatory (2.2.4):**
> "The MA_DATA.request and MA_DATA.indication service primitives described in this subclause are mandatory."

> **MAC Control transparency (2.3.2):**
> "The MA_DATA.indication is passed from the MAC sublayer entity (through the optional MAC Control sublayer, if implemented) to the MAC client entity."
> "Frames destined for the optional MAC Control sublayer are not passed to the MAC client if the MAC Control sublayer is implemented."

> **MA_CONTROL.request (31.3.1.2):**
> ```
> MA_CONTROL.request (
>     destination_address,
>     opcode,
>     request_operand_list
> )
> ```
> "Implementation of the MA_CONTROL.request primitive is mandatory."
> - `destination_address`: "may specify either an individual or a group MAC entity address"
> - `opcode`: "specifies the control operation requested"
> - `request_operand_list`: "opcode-specific set of parameters"

> **MA_CONTROL.indication (31.3.2.2):**
> ```
> MA_CONTROL.indication (
>     opcode,
>     indication_operand_list
> )
> ```
> "Implementation of the MA_CONTROL.indication primitive is mandatory."
> - `indication_operand_list`: "opcode-specific, specified in Annex 31A, Annex 31B, and Clause 64"

> **Interface signal map (31.3, Figure 31-2):**
> - MAC Client → MAC Control: MCF:MA_DATA.request, MCF:MA_CONTROL.request
> - MAC Control → MAC Client: MCF:MA_DATA.indication, MCF:MA_CONTROL.indication
> - MAC Control → MAC: MAC:MA_DATA.request
> - MAC → MAC Control: MAC:MA_DATA.indication

### Deliverables

- [ ] MA_DATA.request signal map (client → MAC): DA, SA, data, FCS
- [ ] MA_DATA.indication signal map (MAC → client): DA, SA, data, FCS, status
- [ ] MA_CONTROL.request signal map (client → MAC Control): DA, opcode, operands
- [ ] MA_CONTROL.indication signal map (MAC Control → client): opcode, operands
- [ ] All parameter definitions (mandatory/optional)
- [ ] MAC Control transparency: control frames consumed, not passed to client
- [ ] Data frames pass through MAC Control to client

### Dependencies
None

### Consumed By
F7 (TX), F8 (RX), F9 (MAC Control), F10 (PAUSE)

---

## F12: Timing

| Field | Value |
|-------|-------|
| **Owner** | E (defines), A (TX enforce) |
| **IEEE Clause** | 4.4.2, 4A.4.2, Table 4-2, 802.3ba |

### Spec

> **Table 4-2 — MAC parameters (802.3ba):**
> | Parameter | ≤100Mb/s | 1Gb/s | 10Gb/s | 40/100Gb/s |
> |-----------|----------|-------|--------|------------|
> | slotTime | 512 BT | 4096 BT | N/A | N/A |
> | interPacketGap | 96 bits | 96 bits | 96 bits | 96 bits |
> | attemptLimit | 16 | 16 | N/A | N/A |
> | backoffLimit | 10 | 10 | N/A | N/A |
> | jamSize | 32 bits | 32 bits | N/A | N/A |
> | maxBasicFrameSize | 1518 octets | 1518 octets | 1518 octets | 1518 octets |
> | maxEnvelopeFrameSize | 2000 octets | 2000 octets | 2000 octets | 2000 octets |
> | minFrameSize | 512 bits | 512 bits | 512 bits | 512 bits |
> | burstLimit | N/A | 65536 bits | N/A | N/A |
> | ipgStretchRatio | N/A | N/A | 104 bits | N/A |

> **Table 4A-2 — Full duplex MAC parameters (Annex 4A):**
> | Parameter | Value |
> |-----------|-------|
> | interPacketGap | 96 bits |
> | maxBasicFrameSize | 1518 octets |
> | maxEnvelopeFrameSize | 2000 octets |
> | minFrameSize | 512 bits (64 octets) |

> **NOTE 7 (802.3ba, Clause 4):**
> "For 40 Gb/s and 100 Gb/s operation, the received interPacketGap can have a minimum value of 8 BT (bit times), as measured at the XLGMII or CGMII receive signals at the DTE due to clock tolerance and lane alignment requirements."

> **NOTE 4 (802.3ba, Annex 4A):**
> Same as NOTE 7 — 8 BT minimum at XLGMII/CGMII.

### Deliverables

- [ ] interPacketGap = 96 bits (constant)
- [ ] IPG shrinkage: received min = 8 BT at 100G
- [ ] minFrameSize = 512 bits / 64 octets (constant)
- [ ] maxBasicFrameSize = 1518 octets (constant)
- [ ] maxEnvelopeFrameSize = 2000 octets (constant)
- [ ] slotTime, attemptLimit, backoffLimit, jamSize, burstLimit = N/A at 100G

### Dependencies
None

### Consumed By
F5 (Frame Format), F6 (IPG)

---

## F13: Full Duplex

| Field | Value |
|-------|-------|
| **Owner** | E |
| **IEEE Clause** | 4.1.1, 4A.1.1, 4A.1.2, 4A.2.7.3, 4A.3.3, 802.3ba |

### Spec

> **Full duplex only at 100G (802.3ba, Table 4-2):**
> For 40/100 Gb/s: slotTime = N/A, attemptLimit = N/A, backoffLimit = N/A, jamSize = N/A, burstLimit = N/A. All CSMA/CD parameters not applicable.

> **Full duplex requirements (4.1.1):**
> "The full duplex mode of operation can be used when all of the following are true:"
> 1. "The physical medium is capable of supporting simultaneous transmission and reception without interference."
> 2. "There are exactly two stations on the LAN."
> 3. "Both stations on the LAN are capable of and have been configured to use full duplex operation."

> **No CSMA/CD (4A.1.1):**
> "This MAC does not support the half duplex mode of operation so there is no need for collision detection or handling."

> **Full duplex transmission (4.2.3.2.6):**
> "In full duplex mode, there is never contention for a shared physical medium. Full duplex stations do not defer to received traffic, nor abort transmission, jam, backoff, and reschedule transmissions. Transmissions may be initiated whenever the station has a packet queued, subject only to the interpacket gap."

> **PHY interface signals (4A.3.3, Table 4A-1):**
> | Type | Name | Description |
> |------|------|-------------|
> | Function | ReceiveBit: Bit | Retrieve one bit from PHY |
> | Procedure | TransmitBit(bitParam: Bit) | Pass one bit to PHY |
> | Procedure | Wait(bitTimes: integer) | Wait specified bit times |
> | Variable | transmitting: Boolean | True during frame transmission |
> | Variable | receiveDataValid: Boolean | PHY indicates incoming data |
> | Variable | carrierSense: Boolean | PHY congestion indicator |
> | Variable | collisionDetect: Boolean | Not used (artifact) |

> **carrierSense handling (4A.1.2):**
> "Frame transmission may be initiated once the carrierSense signal has been removed and after the interframe delay, regardless of the presence of receive activity."
> "When carrierSenseMode = FALSE, the carrierSense variable is ignored."

> **passReceiveFCSMode (4A.2.7.3):**
> "Indicates the desired mode of operation, and enables passing of the frame check sequence field of all received frames from the MAC sublayer to the MAC client."
> When enabled, padding is not stripped.

> **maxFrameSizeLimit (4A.2.7.1):**
> Can be: maxBasicFrameSize (1518), +qTagPrefixSize (1522), or maxEnvelopeFrameSize (2000).

> **100G PHY types (802.3ba, Clause 30):**
> - 100GBASE-R: Multi-PCS lane 64B/66B (Clause 82)
> - 100GBASE-CR10: 10-lane copper (Clause 85)
> - 100GBASE-SR10: 10-lane multimode fiber (Clause 86)
> - 100GBASE-LR4: 4 WDM lane single-mode fiber, long reach (Clause 88)
> - 100GBASE-ER4: 4 WDM lane single-mode fiber, extended reach (Clause 88)

### Deliverables

- [ ] Full duplex operation only (no half duplex)
- [ ] No CSMA/CD (no collision detection/handling)
- [ ] No carrier extension or frame bursting
- [ ] transmitting variable: true during TX, false after
- [ ] receiveDataValid input from PHY
- [ ] carrierSense input from PHY (optional, configurable)
- [ ] carrierSenseMode: ignore carrierSense when FALSE
- [ ] passReceiveFCSMode: pass FCS to client, don't strip pad
- [ ] maxFrameSizeLimit: 1518/1522/2000 configurable
- [ ] PHY interface: TransmitBit, ReceiveBit, Wait procedures

### Dependencies
None

### Consumed By
F7 (TX), F8 (RX)

---

## F14: Statistics

| Field | Value |
|-------|-------|
| **Owner** | D |
| **IEEE Clause** | Clause 30, 30.5.1.1, Clause 45 |

### Spec

> **aBIPErrorCount (30.5.1.1.10a):**
> "A SEQUENCE of generalized nonresetable counters. Each counter has a maximum increment rate of 5,000 counts per second for 100 Gb/s implementations."
> "For 40/100GBASE-R PHYs, an array of BIP error counters. The indices (0 to n-1) denote the PCS lane number. Each element contains a count of BIP errors for that PCS lane. Increment by one for each BIP error detected during alignment marker removal in the PCS."

> **aLaneMapping (30.5.1.1.10b):**
> "A SEQUENCE of INTEGERs. For 40/100GBASE-R PHYs, an array of PCS lane identifiers. The indices (0 to n-1) denote the service interface lane number."

> **aFECmode (30.5.1.1.14):**
> "An ENUMERATION: unknown, disabled, enabled. A read-write value indicating the mode of operation of the optional FEC sublayer."

> **aFECCorrectedBlocks (30.5.1.1.15):**
> "A SEQUENCE of generalized nonresetable counters. Each counter has a maximum increment rate of 2,500,000 counts per second for 100 Gb/s implementations."
> "For 10/40/100GBASE-R PHYs, an array of corrected FEC blocks counters. The indices (0 to N-1) denote the PCS lane number. Increment by one for each received block corrected by FEC."

> **aFECUncorrectableBlocks (30.5.1.1.16):**
> "A SEQUENCE of generalized nonresetable counters. Each counter has a maximum increment rate of 2,500,000 counts per second for 100 Gb/s implementations."
> "Increment by one for each FEC block determined to be uncorrectable."

> **aSymbolErrorDuringCarrier (30.3.2.1.5):**
> "For 10/40/100 Gb/s, a count of the number of times the receiving media is non-idle for a period ≥ minFrameSize, and during which there was at least one 'Receive Error' indication."

> **100G MDIO registers (Clause 45):**
> | Register | Description |
> |----------|-------------|
> | 1.0.5:2 = 0011 | 100G speed select |
> | 1.4.9 | 100G capable bit |
> | 1.7.5:0 = 101000 | 100GBASE-CR10 |
> | 1.7.5:0 = 101001 | 100GBASE-SR10 |
> | 1.7.5:0 = 101010 | 100GBASE-LR4 |
> | 1.7.5:0 = 101011 | 100GBASE-ER4 |
> | 1.170 | BASE-R FEC ability |
> | 1.171 | BASE-R FEC control |
> | 1.300–1.339 | FEC corrected blocks, lanes 0–19 |
> | 1.700–1.739 | FEC uncorrected blocks, lanes 0–19 |

> **Counter summary:**
> | Counter | Type | Max Rate (100G) | Width | Index |
> |---------|------|-----------------|-------|-------|
> | aBIPErrorCount | nonresetable | 5,000/s | per-lane | 0 to n-1 |
> | aFECCorrectedBlocks | nonresetable | 2,500,000/s | per-lane | 0 to N-1 |
> | aFECUncorrectableBlocks | nonresetable | 2,500,000/s | per-lane | 0 to N-1 |
> | aSymbolErrorDuringCarrier | nonresetable | — | single | N/A |

### Deliverables

- [ ] TX frame counter (saturating, read/clear)
- [ ] RX frame counter (saturating, read/clear)
- [ ] Error counters: CRC, length, alignment (saturating)
- [ ] aBIPErrorCount: per-lane array, max 5000/s, nonresetable
- [ ] aFECCorrectedBlocks: per-lane array, max 2.5M/s, nonresetable
- [ ] aFECUncorrectableBlocks: per-lane array, max 2.5M/s, nonresetable
- [ ] aFECmode: unknown/disabled/enabled (read-write)
- [ ] aPhyType: 100GBASE-R
- [ ] aMAUType: CR10/SR10/LR4/ER4
- [ ] aLaneMapping: PCS lane array
- [ ] aSymbolErrorDuringCarrier: single counter
- [ ] MDIO register map (Clause 45): speed select, FEC control/status, counters

### Dependencies
F7 (TX events), F8 (RX events), F10 (Control events)

### Consumed By
Host software (external)

---

## Interface Contracts

| Interface | Defined By | Consumed By | Description |
|-----------|-----------|-------------|-------------|
| CRC32 | F1 | F7, F8, F10 | Polynomial and computation |
| MA_DATA | F11 | F7, F8, F9 | Client-MAC data interface |
| MA_CONTROL | F11 | F9, F10 | Client-MAC Control interface |
| pause_status | F10 | F7 | paused / not_paused |
| transmitting | F13 | F7 | True during TX |
| receiveDataValid | F13 | F8 | PHY data valid |
| carrierSense | F13 | F7 | PHY congestion |
| passReceiveFCSMode | F13 | F8 | FCS passthrough |
| maxFrameSizeLimit | F13 | F8 | Max frame config |
| Statistics events | F14 | — | Frame/error counters |

---

## Dependency Flow

```
    F13 (Full Duplex) ────────────────────────┐
    F12 (Timing) ─────────────────────────────┤
    F1 (CRC) ────────┐                        │
    F2 (Preamble) ───┤                        │
    F3 (SFD) ────────┤                        │
    F4 (Addressing) ─┤                        │
    F5 (Frame Format)┤                        │
                     ▼                        ▼
            ┌──────────────┐        ┌──────────────┐
            │  F7 (TX Path)│        │  F8 (RX Path)│
            └──────┬───────┘        └──────┬───────┘
                   │                       │
                   ▼                       ▼
            ┌────────────────────────────────────┐
            │     F11 (Service Primitives)       │
            └──────────────┬─────────────────────┘
                           │
               ┌───────────┴───────────┐
               ▼                       ▼
      ┌──────────────┐       ┌──────────────┐
      │ F9 (MAC Ctrl)│       │ F14 (Stats)  │
      └──────┬───────┘       └──────────────┘
             │
             ▼
      ┌──────────────┐
      │ F10 (PAUSE)  │
      └──────────────┘
```

---

## Owner Assignees

| Owner | Features | Name | Email | Start Date |
|-------|----------|------|-------|------------|
| A (TX) | F2, F3, F6, F7 | `[Name]` | `[Email]` | `[Date]` |
| B (RX) | F2, F3, F4, F8 | `[Name]` | `[Email]` | `[Date]` |
| C (Control) | F9, F10 | `[Name]` | `[Email]` | `[Date]` |
| D (Stats) | F14 | `[Name]` | `[Email]` | `[Date]` |
| E (Integration) | F1, F5, F11, F12, F13 | `[Name]` | `[Email]` | `[Date]` |

---

## Rules

| Rule | Description |
|------|-------------|
| R1 | Each feature has exactly one owner |
| R2 | CRC defined by E; A uses for TX, B uses for RX verify |
| R3 | Frame format defined by E; A builds, B extracts |
| R4 | pause_status defined by C; A reads it to inhibit TX |
| R5 | Statistics collected by D; A, B, C provide events |
| R6 | Interface changes require owner approval + doc update |

---

## Version History

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | `[Date]` | `[Author]` | Initial — 14 master features, basic |
| 2.0 | `[Date]` | `[Author]` | Extended — full spec text, state machines, deliverables |

---

*Source: truth_source/IEEE_Specs_MAC/ (IEEE 802.3-2008 + IEEE 802.3ba-2010)*
*100G Ethernet MAC — 14 features, 5 owners, pure spec, zero overlap*
