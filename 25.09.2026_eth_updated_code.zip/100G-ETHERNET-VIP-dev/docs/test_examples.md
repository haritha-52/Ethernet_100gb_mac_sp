# MAC UVM Test-Case Writing Guide

This guide is the required workflow for adding or modifying a MAC UVM test.
It keeps individual development fast while protecting the shared regression.

---

## 0. What is a UVM Test? (Beginner Introduction)

### The Problem UVM Tests Solve

Without UVM, your testbench might look like this:

```systemverilog
// Monolithic test - everything in one file
module my_testbench;
  // Drive signals
  // Wait for response
  // Check result
  // Print pass/fail
endmodule
```

Problems:
- Every new test requires copying and modifying the entire file
- No reuse of common infrastructure (reset, configuration, monitoring)
- No standardized way to coordinate multiple agents (AXI, RS, APB)
- Difficult to run the same test with different seeds
- No built-in scoreboard or coverage collection

### What a UVM Test Gives You

A UVM test is a **focused behavioral claim** about your DUT. Think of it as a
**scientific experiment**:

```
┌─────────────────────────────────────────────────────────────────────┐
│                     YOUR TEST (the experiment)                     │
│                                                                     │
│  HYPOTHESIS: "When I send a frame with a bad CRC, the MAC drops it"│
│                                                                     │
│  PROCEDURE:                                                        │
│    1. Configure MAC through APB registers                         │
│    2. Send a frame with corrupted FCS via RS agent                │
│    3. Observe that no frame appears on AXI RX                    │
│                                                                     │
│  CONCLUSION: PASS or FAIL                                          │
└─────────────────────────────────────────────────────────────────────┘
```

### The UVM Test Architecture in This Project

```
┌─────────────────────────────────────────────────────────────────────┐
│                        YOUR TEST CLASS                             │
│                                                                     │
│  class mac_rx_crc_error_test_c extends mac_base_test_c;           │
│    // 1. Configure agent topology (which ports are active/passive)│
│    // 2. Implement run_stimulus() with your test logic            │
│  endclass                                                          │
│                                                                     │
│  You only write the BLUE parts. The RED parts are provided.       │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     BASE TEST (mac_base_test_c)                    │
│                                                                     │
│  Provides EVERYTHING for free:                                     │
│    ✓ Reset sequence execution                                     │
│    ✓ APB bootstrap (write initial config)                         │
│    ✓ RAL model creation and binding                               │
│    ✓ Virtual interface extraction                                 │
│    ✓ Environment and agent configuration                          │
│    ✓ UVM objection management                                     │
│    ✓ Standard reporting                                           │
│                                                                     │
│  You NEVER override build_phase() or run_phase()!                 │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     UVM ENVIRONMENT (mac_env_c)                    │
│                                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐            │
│  │  AXI Agent   │  │   RS Agent   │  │   APB Agent  │            │
│  │  (client)    │  │   (line)     │  │   (config)   │            │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘            │
│         │                  │                  │                     │
│         ▼                  ▼                  ▼                     │
│  ┌─────────────────────────────────────────────────────┐          │
│  │              VIRTUAL SEQUENCER                      │          │
│  │  Coordinates all agent sequencers in one place     │          │
│  └─────────────────────────────────────────────────────┘          │
│         │                  │                  │                     │
│         ▼                  ▼                  ▼                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐            │
│  │  Scoreboard  │  │ Ref Model    │  │  Coverage    │            │
│  │  (check)     │  │ (predict)    │  │  (measure)   │            │
│  └──────────────┘  └──────────────┘  └──────────────┘            │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│                           DUT (MAC)                                 │
│                                                                     │
│  AXI interface ←→ MAC TX engine ←→ RS interface                   │
│  RS interface  ←→ MAC RX engine ←→ AXI interface                  │
│  APB interface ←→ Register block                                  │
└─────────────────────────────────────────────────────────────────────┘
```

### Key Benefits in This Project

1. **One claim per test** — each test proves one thing, making failures easy to diagnose
2. **Reuse infrastructure** — reset, APB bootstrap, RAL, scoreboard all come free
3. **Seed replay** — run the exact same test again with `SEED=12345`
4. **Independent execution** — tests don't depend on other tests running first
5. **Standardized checks** — UVM error/fatal reporting with clear messages

### Test vs Sequence vs Component

```
┌─────────────────────────────────────────────────────────────────────┐
│                        TEST                                         │
│  - The top-level "experiment"                                      │
│  - Extends mac_base_test_c                                        │
│  - Configures agents and runs stimulus                            │
│  - Reports PASS/FAIL                                              │
│  - Example: mac_rx_crc_error_test_c                               │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                        SEQUENCE                                     │
│  - Creates and drives transaction objects                         │
│  - Runs on a specific agent sequencer                             │
│  - Example: mac_sanity_tx_sequence_c (creates 10 AXI frames)     │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                        COMPONENT                                    │
│  - Long-lived object that lives in the environment                │
│  - Examples: scoreboard, reference model, coverage, agents        │
│  - You don't create these — they're already built                │
└─────────────────────────────────────────────────────────────────────┘
```

---

## 1. Test ownership and boundaries

A test owns one behavioral claim: a feature, under one condition, with a
defined expected result.  For example, `mac_rx_crc_error_test_c` proves that
an ingress RS frame with a bad FCS is rejected; it does not also test PAUSE or
register reset behavior.

All MAC tests must:

- Extend `mac_base_test_c` in `src/hvl_top/test/base/mac_base_test.svh`.
- Use the existing APB, AXI4-Stream, RS-stream, reset, scoreboard, and
  reference-model infrastructure.
- Apply configuration through APB and send/observe traffic through agents.
- Avoid DUT internal `force`, `release`, hierarchical writes, and dependence
  on another test having run first.
- Raise and drop UVM objections correctly, finish independently, and report
  failures through UVM errors or fatals.

For RTL port-renaming work, the only permitted testbench source modification
is `src/hvl_top/tb/mac_tb_top.sv`.  New test scenarios belong under
`src/hvl_top/test/mac/<feature>/` and must not require changes to agents, the environment,
or the scoreboard unless that infrastructure change is separately reviewed.

---

## 2. What the Base Test Provides (Architecture)

### 2.1 Complete Component Hierarchy

```
mac_tb_top (SystemVerilog interface wrapper)
  └── mac_test_pkg::mac_base_test_c (your test extends this)
        └── mac_env_c (env_h — the environment)
              ├── axi4_stream_agent_top_h
              │     ├── active[0]   → TX driver + sequencer + monitor
              │     └── passive[0]  → RX monitor only
              │
              ├── mac_rs_stream_agent_top_h
              │     ├── active[0]   → RX driver + sequencer + monitor
              │     └── passive[0]  → TX monitor only
              │
              ├── apb3_agent_top_h
              │     └── active[0]   → APB master driver + sequencer + monitor
              │
              ├── reset_agent_top_h
              │     ├── agents[0]   → MAC reset
              │     └── agents[1]   → APB reset
              │
              ├── virtual_sequencer_h
              │     ├── client_ingress_seqr_h  → AXI active[0] sequencer
              │     ├── line_ingress_seqr_h    → RS active[0] sequencer
              │     ├── apb_seqr_h             → APB active[0] sequencer
              │     ├── mac_reset_seqr_h       → reset agent[0] sequencer
              │     └── apb_reset_seqr_h       → reset agent[1] sequencer
              │
              ├── scoreboard_h           → TX + RX expected vs actual
              ├── reference_model_h      → golden model for TX/RX/APB
              ├── coverage_h             → functional coverage
              ├── protocol_checker_h     → protocol rule checking
              └── ral_predictor_h        → APB monitor → RAL mirror
```

### 2.2 What the Base Test Does for You

When you run `make run TEST=mac_rx_crc_error_test_c SEED=12345`, the base
test automatically executes this sequence:

```
┌─────────────────────────────────────────────────────────────────────┐
│  PHASE 1: build_phase                                              │
│                                                                     │
│  1. Fetch mac_tb_cfg_c from config DB (published by mac_tb_top)   │
│  2. Extract 6 virtual interfaces (AXI TX/RX, RS TX/RX, reset x2) │
│  3. Create mac_env_cfg_c with your agent counts                   │
│  4. Call YOUR configure_test() — you set agent counts here        │
│  5. Create all agents, scoreboard, RAL, etc.                     │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│  PHASE 2: end_of_elaboration_phase                                 │
│                                                                     │
│  1. Bind RAL default_map to APB sequencer through adapter         │
│  2. Print UVM topology (for debugging)                            │
└─────────────────────────────────┬───────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────┐
│  PHASE 3: run_phase                                                │
│                                                                     │
│  1. RAISE UVM objection (prevents sim from ending)                │
│  2. Run reset sequence on each reset agent                        │
│  3. Run APB bootstrap sequence (write REG_GLOBAL_CONTROL)         │
│  4. Wait for config_done flag                                     │
│  5. Call YOUR run_stimulus() — this is where your test logic goes │
│  6. DROP UVM objection (allows sim to end)                        │
└─────────────────────────────────────────────────────────────────────┘
```

### 2.3 The run_stimulus Hook

The base test provides an empty `run_stimulus()` task. You override it:

```systemverilog
// Base test (you never touch this):
task mac_base_test_c::run_stimulus(uvm_phase phase);
  #1ns;  // Empty by default
endtask

// Your test (you write this):
task mac_rx_crc_error_test_c::run_stimulus(uvm_phase phase);
  // Your test logic goes here
  // 1. Configure registers
  // 2. Drive traffic
  // 3. Check results
endtask
```

### 2.4 Agent Topology Configuration

You configure which agents are active (drive traffic) and passive (monitor only)
in your constructor:

```systemverilog
function mac_rx_crc_error_test_c::new(...);
  super.new(name, parent);
  // RS RX is ACTIVE — we drive bad-CRC frames into the MAC
  num_rs_active_agents   = 1;
  // AXI RX is PASSIVE — we monitor to confirm no frame is delivered
  num_axi_passive_agents = 1;
  // No AXI TX or RS TX needed for this test
endfunction
```

**Agent Topology Quick Reference:**

| Scenario | Active Agents | Passive Agents |
| --- | --- | --- |
| MAC TX path (client → MAC → wire) | AXI TX | RS TX |
| MAC RX path (wire → MAC → client) | RS RX | AXI RX |
| Register-only (no traffic) | APB only | None needed |
| PAUSE RX (line-side stimulus) | RS RX + APB | AXI RX |
| PAUSE TX (register-driven) | APB | RS TX |
| Bidirectional sanity | AXI TX + RS RX | RS TX + AXI RX |

---

## 3. Step-by-step: write a new test

### Step 1: establish the baseline

Before editing, run the known-good sanity test with a fixed seed from the
Questa directory:

```bash
cd sim/Questasim
make run TEST=mac_sanity_test_c SEED=12345
```

If this fails, stop and resolve or report the baseline failure before adding a
new test.  Never use a new test to hide an existing regression failure.

### Step 2: write the test contract

Record these five items in the test header or review description before
implementing it:

1. **Feature and condition** — for example, RX CRC handling with a bad FCS.
2. **Ingress stimulus** — APB setup and AXI or RS traffic to be driven.
3. **Expected egress behavior** — forwarded frame, dropped frame, generated
   control frame, register/status update, or error indication.
4. **Checks** — scoreboard comparison, monitor count, APB readback, protocol
   checker, or coverage point.
5. **Completion condition** — a monitor count, event, response, or bounded
   timeout that proves the scenario has completed.

Choose a precise class name in this form:

```text
mac_<tx-or-rx-or-feature>_<condition>_test_c
```

Examples: `mac_tx_min_frame_test_c`, `mac_rx_crc_error_test_c`, and
`mac_pause_rx_test_c`.

### Step 3: create the test class

Create `src/hvl_top/test/mac/<feature>/mac_<feature>_<nnn>_test.svh`, using this shape:

```systemverilog
class mac_rx_crc_error_test_c extends mac_base_test_c;
  `uvm_component_utils(mac_rx_crc_error_test_c)

  extern function new(string name = "mac_rx_crc_error_test_c",
                      uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);
endclass

function mac_rx_crc_error_test_c::new(string name = "mac_rx_crc_error_test_c",
                                      uvm_component parent = null);
  super.new(name, parent);
  num_rs_active_agents   = 1;
  num_axi_passive_agents = 1;
endfunction

function void mac_rx_crc_error_test_c::configure_test();
  super.configure_test();
  // Add only scenario-specific agent or register-model configuration here.
endtask

task mac_rx_crc_error_test_c::run_stimulus(uvm_phase phase);
  // Configure through APB, start the sequence, wait for monitored completion,
  // and issue a UVM error if the observable result is wrong.
endtask
```

Use the constructor for agent counts and default frame counts.  Override
`configure_test()` only for scenario-specific configuration; always call
`super.configure_test()` first.  Put scenario behavior in `run_stimulus()`.
The base test supplies reset, APB bootstrap, configuration publication, UVM
objection handling, and standard reporting.

### Step 4: add or reuse sequences

Prefer an existing sequence when it describes the required traffic.  Otherwise
place reusable stimulus in the appropriate directory:

| Traffic scope | Location |
| --- | --- |
| AXI client-side ingress traffic | `src/hvl_top/sequences/axi/` |
| RS line-side ingress traffic | `src/hvl_top/sequences/rs/` |
| Cross-agent/reset/APB orchestration | `src/hvl_top/sequences/virtual/` |
| Single-test-only helper | The test file, kept small and clearly named |

Sequences create and randomize transaction objects, then start on the named
agent sequencer.  Tests coordinate sequences and evaluate the observable DUT
result; they should not duplicate packet-building logic across files.

### Step 5: configure only needed agents

Select active agents only for ports that drive stimulus and passive agents
only for ports that observe the expected output.  Typical mappings are:

| Scenario | Active agent | Passive agent |
| --- | --- | --- |
| MAC TX path | AXI TX | RS TX |
| MAC RX path | RS RX | AXI RX |
| Register-only behavior | APB | Only the monitor needed for the result |
| PAUSE RX | RS RX plus APB | AXI RX |
| PAUSE TX | APB | RS TX |

Do not enable unused agents merely because another test does.  This reduces
unrelated traffic and makes failures easier to diagnose.

### Step 6: implement checks and completion

Every test must check both the functional output and any relevant status or
error behavior.  Use the scoreboard/reference model for frame correctness,
monitors for observed transaction counts, and APB reads for software-visible
state.

Wait for a real completion condition, such as a target monitor count or APB
response.  Use the shared wait utilities and a bounded timeout.  Do not use a
bare fixed delay as proof of completion.  A fixed delay is allowed only for a
known CDC or hardware-settling requirement; document the reason, expected
latency, and why an event-based wait is unavailable.

Report mismatches with `uvm_error` and unrecoverable setup failures with
`uvm_fatal`.  Error messages must state the feature, expected value/behavior,
observed value/behavior, and relevant address/frame count when applicable.

---

## 4. Detailed Worked Examples

### Example 1: TX-Only Sanity Test (Traffic Without Register Config)

```systemverilog
class mac_tx_sanity_test_c extends mac_base_test_c;
  `uvm_component_utils(mac_tx_sanity_test_c)

  localparam int unsigned TX_COUNT = 10;

  extern function new(string name = "mac_tx_sanity_test_c",
                      uvm_component parent = null);
  extern virtual task run_stimulus(uvm_phase phase);
endclass

function mac_tx_sanity_test_c::new(...);
  super.new(name, parent);
  // AXI TX is ACTIVE — we drive frames into the MAC
  num_axi_active_agents  = 1;
  // RS TX is PASSIVE — we monitor frames leaving the MAC
  num_rs_passive_agents  = 1;
  num_tx_frames          = TX_COUNT;
endfunction

task mac_tx_sanity_test_c::run_stimulus(uvm_phase phase);
  mac_sanity_tx_sequence_c tx_seq_h;
  bit timed_out;

  // Step 1: Create and configure the sequence
  tx_seq_h = mac_sanity_tx_sequence_c::type_id::create("tx_seq_h");
  tx_seq_h.num_transactions = TX_COUNT;

  // Step 2: Start the sequence on the AXI sequencer
  tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);

  // Step 3: Wait for DUT to process all frames
  mac_wait_utils_c::wait_for_count_at_least(
      TX_COUNT,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif,
      MAC_COMPLETION_TIMEOUT_NS,
      timed_out);

  // Step 4: Check result
  if (timed_out)
    `uvm_error("MAC_TX_SANITY", "Timed out waiting for TX frames")
  else
    `uvm_info("MAC_TX_SANITY", $sformatf("PASS: %0d TX frames completed", TX_COUNT), UVM_NONE)
endtask
```

### Example 2: Register-Only Test (No Traffic)

```systemverilog
class mac_reg_write_read_test_c extends mac_base_test_c;
  `uvm_component_utils(mac_reg_write_read_test_c)

  extern function new(string name = "mac_reg_write_read_test_c",
                      uvm_component parent = null);
  extern virtual task run_stimulus(uvm_phase phase);
endclass

function mac_reg_write_read_test_c::new(...);
  super.new(name, parent);
  // No active agents needed — we only use APB (which is always active)
  // No passive agents needed — we only check register readback
endfunction

task mac_reg_write_read_test_c::run_stimulus(uvm_phase phase);
  uvm_status_e status;
  uvm_reg_data_t data;

  // Step 1: Write a known value to MAX_FRAME_SIZE
  ral_h.registers["max_frame_size"].write(status, 32'd1536,
                                            UVM_FRONTDOOR, ral_h.default_map);
  if (status != UVM_IS_OK)
    `uvm_fatal("MAC_REG_RW", "APB write failed")

  // Step 2: Read it back
  ral_h.registers["max_frame_size"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);

  // Step 3: Verify (only check defined bits [15:0])
  if (status != UVM_IS_OK || data[15:0] != 16'd1536)
    `uvm_error("MAC_REG_RW", $sformatf("Readback mismatch: got %h, expected 1536", data))
  else
    `uvm_info("MAC_REG_RW", "PASS: MAX_FRAME_SIZE readback correct", UVM_NONE)
endtask
```

### Example 3: PAUSE RX Test (Register Config + Traffic + Status Check)

```systemverilog
// From test/mac/pause_frame/mac_pause_test.svh — the real PAUSE RX test
task mac_pause_rx_test_c::run_stimulus(uvm_phase phase);
  mac_pause_frame_sequence_c seq_h;
  bit [apb_transfer_t::DATA_WIDTH-1:0] status_data;
  int axi_rx_cnt;

  // Step 1: Enable RX PAUSE through APB
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0095);

  // Step 2: Wait for CDC (config crosses to MAC domain)
  #200;

  // Step 3: Drive a PAUSE frame into the MAC
  seq_h = mac_pause_frame_sequence_c::type_id::create("pause_frame_seq_h");
  seq_h.pause_quanta = 16'h0100;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);

  // Step 4: Wait for DUT to process the PAUSE frame
  #1us;

  // Step 5: Read status register — pause_active should be set
  apb_read(reg_map_pkg::REG_RX_STATUS, status_data);
  if (status_data[0])
    `uvm_info("MAC_PAUSE_RX", "PASS: pause_active asserted", UVM_NONE)
  else
    `uvm_error("MAC_PAUSE_RX", "FAIL: pause_active not asserted")

  // Step 6: Verify PAUSE frame was consumed (not delivered to AXI)
  axi_rx_cnt = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (axi_rx_cnt == 0)
    `uvm_info("MAC_PAUSE_RX", "PASS: PAUSE frame consumed, no client delivery", UVM_NONE)
  else
    `uvm_error("MAC_PAUSE_RX", $sformatf("FAIL: %0d frames delivered to AXI", axi_rx_cnt))
endtask
```

### Example 4: Concurrent TX/RX Test (Fork-Join Pattern)

```systemverilog
// From mac_sanity_test.c — concurrent traffic
task mac_sanity_test_c::run_stimulus(uvm_phase phase);
  mac_sanity_tx_sequence_c tx_seq_h;
  mac_sanity_rx_sequence_c rx_seq_h;
  bit tx_timed_out, rx_timed_out;

  // Create sequences
  tx_seq_h = mac_sanity_tx_sequence_c::type_id::create("tx_seq_h");
  rx_seq_h = mac_sanity_rx_sequence_c::type_id::create("rx_seq_h");
  tx_seq_h.num_transactions = 10;
  rx_seq_h.num_transactions = 15;

  // Run TX and RX concurrently using fork-join
  fork
    tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
    rx_seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
  join

  // Wait for DUT to process all frames
  mac_wait_utils_c::wait_for_count_at_least(
      20,  // 10 TX + 10 TX from parallel
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, tx_timed_out);

  mac_wait_utils_c::wait_for_axi_count_at_least(
      30,  // 15 RX + 15 RX from parallel
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, rx_timed_out);

  if (tx_timed_out || rx_timed_out)
    `uvm_error("MAC_SANITY", "Concurrent traffic timed out")
  else
    `uvm_info("MAC_SANITY", "PASS: Concurrent TX/RX completed", UVM_NONE)
endtask
```

### Example 5: Using APB Helpers for Direct Register Access

```systemverilog
// From test/mac/apb/mac_register_access_test.svh — direct APB helpers
class mac_register_access_test_c extends mac_base_test_c;
  // ... class definition ...

  // Helper task: single APB write
  task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                 bit [apb_transfer_t::DATA_WIDTH-1:0] data);
    apb_write_sequence_c seq_h;
    seq_h = apb_write_sequence_c::type_id::create($sformatf("reg_wr_%h", addr));
    seq_h.m_addr = addr;
    seq_h.m_wdata = data;
    seq_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  endtask

  // Helper task: single APB read
  task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr, bit expect_slverr = 1'b0);
    apb_read_sequence_c seq_h;
    seq_h = apb_read_sequence_c::type_id::create($sformatf("reg_rd_%h", addr));
    seq_h.m_addr = addr;
    seq_h.m_expect_slverr = expect_slverr;
    seq_h.m_expected_status = expect_slverr ? APB_SLVERR : APB_OK;
    seq_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  endtask

  // Helper task: APB read with expected value check
  task apb_read_expect(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       bit [apb_transfer_t::DATA_WIDTH-1:0] expected,
                       bit [apb_transfer_t::DATA_WIDTH-1:0] mask = '1);
    apb_read_sequence_c seq_h;
    seq_h = apb_read_sequence_c::type_id::create($sformatf("reg_rd_check_%h", addr));
    seq_h.m_addr = addr;
    seq_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
    if ((seq_h.m_rdata & mask) !== (expected & mask))
      `uvm_error("MAC_RAL_READBACK", $sformatf(
                 "Readback mismatch addr=%h got=%h expected=%h mask=%h",
                 addr, seq_h.m_rdata, expected, mask))
  endtask
endclass
```

---

## 5. Sequence Architecture

### 5.1 Sequence Hierarchy

```
uvm_sequence#(uvm_sequence_item)
  └── mac_base_virtual_sequence_c
        └── mac_boot_virtual_sequence_c   (APB bootstrap)

uvm_sequence#(axi_item_c)
  ├── axi_sequence_c                      (generic TX)
  └── mac_sanity_tx_sequence_c            (sanity TX)

uvm_sequence#(frame_xtn_c)
  ├── rs_sequence_c                       (generic RX)
  ├── mac_sanity_rx_sequence_c            (sanity RX)
  └── mac_pause_frame_sequence_c          (PAUSE control frame)

apb_sequence_base_c
  ├── apb_write_sequence_c                (single write)
  └── apb_read_sequence_c                 (single read)
```

### 5.2 How Sequences Work

```
┌─────────────────────────────────────────────────────────────────────┐
│                        SEQUENCE LIFECYCLE                          │
│                                                                     │
│  1. Create sequence object                                        │
│     seq_h = mac_sanity_tx_sequence_c::type_id::create("seq_h");  │
│                                                                     │
│  2. Configure sequence parameters                                  │
│     seq_h.num_transactions = 10;                                   │
│                                                                     │
│  3. Start sequence on a sequencer                                  │
│     seq_h.start(env_h.axi4_stream_agent_top_h                     │
│                      .active_agents[0].sequencer_h);              │
│                                                                     │
│  4. Inside body() task:                                            │
│     repeat (num_transactions) begin                               │
│       item_h = axi_item_c::type_id::create("item_h");            │
│       item_h.randomize();                                         │
│       start_item(item_h);    // Wait for sequencer arbitration    │
│       finish_item(item_h);   // Send to driver, wait for response │
│     end                                                           │
│                                                                     │
│  5. Sequence completes, control returns to test                   │
└─────────────────────────────────────────────────────────────────────┘
```

### 5.3 When to Create a New Sequence

| Situation | Action |
| --- | --- |
| Existing sequence does exactly what you need | Reuse it |
| Need different randomization constraints | Create a new sequence with `with` constraints |
| Need to orchestrate multiple agents | Create a virtual sequence |
| Single-test-only stimulus (< 20 lines) | Put it directly in `run_stimulus()` |

---

## 6. Completion and Timeout Patterns

### 6.1 The Right Way: Event-Based Wait

```systemverilog
// Wait for monitor to see N frames
mac_wait_utils_c::wait_for_count_at_least(
    target_count,
    env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
    mac_tx_vif,                    // Clock source for sampling
    MAC_COMPLETION_TIMEOUT_NS,     // Bounded timeout (1 ms)
    timed_out                      // Flag: true if timeout expired
);

if (timed_out)
  `uvm_error("TEST", "Timed out waiting for frames")
```

### 6.2 The Wrong Way: Fixed Delay

```systemverilog
// NEVER do this as proof of completion!
#10us;
// What if DUT is faster? You waste time.
// What if DUT is slower? You get a false pass.
```

### 6.3 When Fixed Delays Are Allowed

```systemverilog
// ONLY for documented CDC settling:
apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0095);
#200;  // CDC handshake: APB → MAC clock domain (~44-55 ns)
// Document the reason, expected latency, and why event-based wait is unavailable
```

### 6.4 Wait Utility Reference

| Utility | Purpose | Clock Source |
| --- | --- | --- |
| `wait_for_count_at_least()` | Wait for RS monitor count | `mac_rs_stream_if` |
| `wait_for_axi_count_at_least()` | Wait for AXI monitor count | `axi4_stream_if` |
| `wait_for_queue_empty()` | Wait for queue to drain | `mac_rs_stream_if` |
| `wait_for_config_done()` | Wait for APB bootstrap | None (1ns steps) |

---

## 7. Register and run the test

### Register it for UVM factory creation

Add the new test file to `src/hvl_top/pkg/mac_test_pkg.sv` after the base-test
include and alongside the other test-layer includes:

```systemverilog
`include "mac_rx_crc_error_test.svh"
```

The class must also contain its `uvm_component_utils` registration.  Both are
required for `+UVM_TESTNAME=mac_rx_crc_error_test_c` to work.

### Run an individual test

Run commands from `sim/Questasim`:

```bash
# Normal development run
make run TEST=mac_rx_crc_error_test_c SEED=12345

# More UVM diagnostic output
make run TEST=mac_rx_crc_error_test_c SEED=12345 VERBOSITY=UVM_HIGH

# Run with functional coverage enabled
make run_cov TEST=mac_rx_crc_error_test_c SEED=12345

# Launch GUI waveform debugging
make gui_waves TEST=mac_rx_crc_error_test_c SEED=12345

# Open the Visualizer flow for a completed/debug run
make visualizer TEST=mac_rx_crc_error_test_c SEED=12345
```

Use a fixed seed while developing and debugging.  On any failure, preserve the
test name, seed, command line, and generated run directory.  Once stable, run
several additional seeds before requesting review.

### Add a stable test to the shared regression

After the individual test is deterministic, self-terminating, and reviewed,
add its class name to the smallest relevant list under `src/hvl_top/testlists/`
(for example `tx.list` or `control.list`), then to `full_regression.list` when
it belongs in the complete suite. Keep each list one test per line; comments
and blank lines are allowed.

Run the complete shared regression before merge:

```bash
make regression SEED=12345
```

The current regression includes the bidirectional sanity test, APB register
access test, and PAUSE RX/TX tests.  Do not add a long-running, unstable, or
order-dependent test to this shared smoke list.

---

## 8. Common Pitfalls and How to Avoid Them

### Pitfall 1: Overriding build_phase or run_phase

**Wrong:**
```systemverilog
function void my_test::build_phase(uvm_phase phase);
  super.build_phase(phase);
  // Don't create agents here — the base test does this!
endfunction
```

**Correct:**
```systemverilog
function void my_test::configure_test();
  super.configure_test();  // Always call super first!
  // Only set agent counts and scenario-specific config here
endfunction
```

### Pitfall 2: Forgetting super.configure_test()

**Wrong:**
```systemverilog
function void my_test::configure_test();
  // Missing super.configure_test()!
  // APB agent config and RAL won't be created!
endfunction
```

**Correct:**
```systemverilog
function void my_test::configure_test();
  super.configure_test();  // REQUIRED — creates APB, RAL, etc.
  // Now add your scenario-specific config
endfunction
```

### Pitfall 3: Using Fixed Delays as Completion

**Wrong:**
```systemverilog
task my_test::run_stimulus(uvm_phase phase);
  send_frame();
  #10us;  // "Wait for it to finish"
  check_result();
endtask
```

**Correct:**
```systemverilog
task my_test::run_stimulus(uvm_phase phase);
  bit timed_out;
  send_frame();
  mac_wait_utils_c::wait_for_count_at_least(
      1, monitor_count, vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  if (timed_out) `uvm_error("TEST", "Timeout")
  else check_result();
endtask
```

### Pitfall 4: Not Checking UVM Status

**Wrong:**
```systemverilog
ral_h.registers["max_frame_size"].write(status, data);
// Ignoring status — what if APB failed?
```

**Correct:**
```systemverilog
ral_h.registers["max_frame_size"].write(status, data);
if (status != UVM_IS_OK)
  `uvm_error("TEST", $sformatf("APB write failed: %s", status.name()))
```

### Pitfall 5: Enabling Unused Agents

**Wrong:**
```systemverilog
// Copying from another test without understanding
num_axi_active_agents  = 1;  // Not driving AXI traffic!
num_rs_active_agents   = 1;  // Not driving RS traffic!
```

**Correct:**
```systemverilog
// Only enable what you need
num_rs_active_agents   = 1;  // Driving RS frames
num_axi_passive_agents = 1;  // Monitoring AXI output
// AXI active and RS passive are 0 (default)
```

### Pitfall 6: Dependence on Test Order

**Wrong:**
```systemverilog
task my_test::run_stimulus(uvm_phase phase);
  // Assumes mac_sanity_test already ran and left state!
  // This WILL break in regression.
endtask
```

**Correct:**
```systemverilog
task my_test::run_stimulus(uvm_phase phase);
  // Every test must be self-contained
  // Configure everything you need from scratch
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0095);
  // Don't rely on previous test's state
endtask
```

---

## 9. Debugging Test Failures

### 9.1 Common Error Messages

| Error Message | Likely Cause | Fix |
| --- | --- | --- |
| `UVM_FATAL: mac_tb_cfg was not published` | mac_tb_top not compiled | Check compilation order |
| `UVM_FATAL: MAC environment not built` | configure_test() missing super call | Add `super.configure_test()` |
| `UVM_ERROR: Timed out waiting for frames` | DUT not processing traffic | Check APB config, reset, clock |
| `UVM_ERROR: Readback mismatch` | Register value wrong | Check address, mask, CDC latency |
| `UVM_ERROR: pause_active not asserted` | PAUSE not enabled | Check REG_GLOBAL_CONTROL bit 4 |

### 9.2 Debug Commands

```bash
# Run with maximum verbosity
make run TEST=mac_rx_crc_error_test_c SEED=12345 VERBOSITY=UVM_HIGH

# Run with waveform viewer
make gui_waves TEST=mac_rx_crc_error_test_c SEED=12345

# Check UVM topology (prints component hierarchy)
# Add to your test temporarily:
#   uvm_top.print_topology();

# Enable RAL tracing
make run TEST=mac_rx_crc_error_test_c SEED=12345 +UVM_REG_TRACE
```

### 9.3 Debugging Checklist

1. **Check the UVM error count** — any `uvm_error` means the test failed
2. **Look at the first error** — subsequent errors are often cascading failures
3. **Check the seed** — can you reproduce with the same seed?
4. **Check the waveform** — did the DUT receive the stimulus?
5. **Check the scoreboard** — did the reference model predict correctly?
6. **Check the APB monitor** — did the register write complete?

---

## 10. Glossary of UVM Test Terms

| Term | Definition |
| --- | --- |
| **Test** | Top-level class that defines a behavioral claim about the DUT. Extends `mac_base_test_c`. |
| **Sequence** | Creates and drives transaction objects on an agent sequencer. |
| **Virtual Sequence** | Coordinates sequences across multiple agent sequencers. |
| **Agent** | Contains driver, sequencer, and monitor for one interface (AXI, RS, APB). |
| **Active Agent** | Agent with a driver that can stimulate the DUT. |
| **Passive Agent** | Agent with only a monitor (no driver). |
| **Sequencer** | Accepts sequence items and arbitrates between multiple sequences. |
| **Driver** | Converts sequence items into pin-level protocol transactions. |
| **Monitor** | Observes pin-level transactions and converts them to sequence items. |
| **Scoreboard** | Compares expected vs actual transactions. |
| **Reference Model** | Golden model that predicts DUT behavior. |
| **Config DB** | UVM mechanism for passing configuration between components. |
| **Objection** | Mechanism to prevent simulation from ending while test is running. |
| **Factory** | UVM mechanism for creating objects by type name (enables overrides). |
| **Analysis Port** | One-way communication from monitor to scoreboard/coverage. |
| **TLM Port** | Transaction-level modeling port for component communication. |

---

## 11. Do-not-break-the-suite checklist

Before submitting a test change, verify all of the following:

- [ ] The fixed-seed sanity baseline passed before development.
- [ ] The test has one behavioral claim and a descriptive class/file name.
- [ ] It extends `mac_base_test_c` and uses existing APB/AXI/RS infrastructure.
- [ ] It neither forces nor writes DUT internals and has no dependency on test order.
- [ ] Required agents are configured; unused agents are not activated.
- [ ] The stimulus has an explicit expected result and observable checks.
- [ ] Completion waits on an event/count/response with a bounded timeout.
- [ ] Any CDC or settling delay is justified and documented.
- [ ] The file is included by `mac_test_pkg.sv` and has UVM factory registration.
- [ ] The new test passes with its recorded fixed seed and additional seeds.
- [ ] `mac_sanity_test_c`, `mac_register_access_test_c`, `mac_pause_rx_test_c`,
  and `mac_pause_tx_test_c` still pass.
- [ ] `make regression SEED=12345` passes before merge.

## 12. Review and handoff template

Include the following in the pull request, review request, or team handoff:

```text
Test class:
Purpose / behavioral claim:
Feature and condition:
APB configuration:
Ingress interface and sequence:
Expected egress behavior:
Checks (scoreboard, monitor, status, coverage):
Completion condition and timeout:
Any documented CDC/settling delay:
Individual test commands and passing seeds:
Baseline test result:
Regression result:
Known limitations or follow-up coverage:
```

Reviewers should be able to reproduce the result using the recorded command
and seed without relying on interactive simulation state or prior test runs.
