# Simulation and Debug Guide

## WSL commands

Run the Makefile from Ubuntu WSL. The flow requires GNU Make, Python 3, and a
Questa installation available on the WSL `PATH` (`vlog`, `vsim`, and related
commands). The repository is mounted by WSL at `/mnt/d/...`.

```bash
cd /mnt/d/Qsemiai/VLSI/Documents/Protocols/Ethernet/100g/repo/100g_ethernet/sim/Questasim

# Compile-only validation; no simulation starts.
make check

# Run the short per-change regression with a reproducible seed.
make regression TESTLIST=../../src/hvl_top/testlists/smoke.list SEED=12345

# Run the complete regression suite.
make regression TESTLIST=../../src/hvl_top/testlists/full_regression.list SEED=12345
```

The testlists are in `src/hvl_top/testlists/`: use `smoke.list` for quick
feedback, feature lists such as `feature/pause_frame.list`,
`feature/integration.list`, and `feature/apb.list` while developing, and
`full_regression.list` for the complete suite. The 61-case ownership and
implementation status are tracked in `src/hvl_top/testplan/mac_testplan.csv`.
Run `make -n regression TESTLIST=...` to inspect the generated commands
without compiling or running.

The WSL flow was validated with GNU Make 4.3 and QuestaSim 2024.1 using:

```bash
make check
```

This compilation completed with zero errors.

Run `make help` for the complete target list. There is no forced global UVM
timeout. Request one only when necessary:

```bash
make run TEST=mac_sanity_test_c UVM_TIMEOUT=50000000
```

## GUI and Visualizer

```bash
make gui_waves TEST=mac_sanity_test_c
make visualizer TEST=mac_sanity_test_c
make visualizer_wlf TEST=mac_sanity_test_c
```

`waves.do` shows reset, APB3, TX AXI ingress, TX MAC/RS egress, RX MAC/RS
ingress, and RX AXI egress in order.

## Failure triage

1. Read the final UVM summary and find the first error.
2. Check reset release and APB configuration.
3. Check `valid && ready` at the source and sink boundaries.
4. Check `sop`, `eop`, `keep`, and `frame_end_byte_index`.
5. Trace the packet ID through logs, monitor output, expected item, and
   scoreboard result.
6. Reproduce with the same seed before trying a new seed.
