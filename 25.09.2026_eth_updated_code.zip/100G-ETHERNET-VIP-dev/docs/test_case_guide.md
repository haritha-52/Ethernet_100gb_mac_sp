# Test Case Guide — Quick Reference

## 1. Workflow Overview

```text
test -> sequence -> sequencer -> driver -> DUT
monitor -> scoreboard
```

- **Test**: scenario + checks
- **Sequence**: traffic pattern
- **Sequencer**: connects sequence to driver
- **Driver**: drives protocol signals
- **Monitor**: observes DUT output

## 2. Key Files

| File | Purpose |
| --- | --- |
| `src/hvl_top/test/base/mac_base_test.svh` | Base test (reset, APB, env) |
| `src/hvl_top/sequences/axi/axi_seq.sv` | AXI sequences |
| `src/hvl_top/sequences/rs/rs_seq.sv` | RS sequences |
| `src/hvl_top/pkg/mac_test_pkg.sv` | Test registration |
| `src/hvl_top/test/mac/` | Feature-organized MAC testcase source |
| `src/hvl_top/test/mac/mac_test_manifest.svh` | Central manifest that registers each feature test aggregator with `mac_test_pkg.sv` |
| `src/hvl_top/testplan/mac_testplan.csv` | 61-case ownership and traceability plan |
| `src/hvl_top/testlists/full_regression.list` | Full regression list |

## 3. Steps to Add a Test

1. Run baseline:
   ```bash
   make run TEST=mac_sanity_test_c SEED=12345
   ```

2. Create a reusable sequence in the matching `src/hvl_top/sequences/mac/<feature>/` directory.

3. Create test file `src/hvl_top/test/mac/<feature>/mac_<feature>_<nnn>_test.svh`:
   ```systemverilog
   class mac_tx_example_test_c extends mac_base_test_c;
     `uvm_component_utils(mac_tx_example_test_c)

     extern function new(string name, uvm_component parent);
     extern virtual task run_stimulus(uvm_phase phase);
   endclass

   function mac_tx_example_test_c::new(string name, uvm_component parent);
     super.new(name, parent);
     num_axi_active_agents = 1;
     num_rs_passive_agents = 1;
   endfunction

   task mac_tx_example_test_c::run_stimulus(uvm_phase phase);
     // create sequence, start on sequencer, wait for completion
   endtask
   ```

4. Add the test include to the feature aggregator under `test/mac/<feature>/`.
   The aggregator is registered through
   [`mac_test_manifest.svh`](../src/hvl_top/test/mac/mac_test_manifest.svh),
   which is included by `mac_test_pkg.sv`:
   ```systemverilog
   `include "mac_tx_example_test.svh"
   ```

5. Run:
   ```bash
   make run TEST=mac_tx_example_test_c SEED=12345
   ```

6. Debug with verbosity or waves:
   ```bash
   make run TEST=mac_tx_example_test_c SEED=12345 VERBOSITY=UVM_HIGH
   make gui_waves TEST=mac_tx_example_test_c SEED=12345
   ```

7. Add to regression list once stable:
   ```bash
   make regression SEED=12345
   ```

## 4. Rules

- Wait for monitor count/event — never use bare `#delay` as proof.
- Keep drivers generic; put traffic in sequences, checks in tests.
- Test one feature per test.
- Always use fixed seeds for debugging.
- Add test to `mac_test_pkg.sv` or UVM cannot create it.
