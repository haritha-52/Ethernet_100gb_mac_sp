# MAC Registers and UVM RAL Guide

This guide is the team reference for writing APB register tests in this MAC.
It explains what each address means, which values are safe to use, and when to
use a direct APB sequence versus the UVM Register Abstraction Layer (RAL).

The RTL address definitions are in `src/rtl_verilog/registers/mac_reg_map.vh`.
The mirrored UVM constants are in `src/hvl_top/pkg/mac_reg_map_pkg.sv`; use
`reg_map_pkg::REG_*` in SystemVerilog tests, never copied address literals.

---

## 0. What is RAL? (Beginner Introduction)

### The Problem RAL Solves

Without RAL, every register access in your test looks like this:

```systemverilog
// Hardcoded address - what is 0x0004? What does bit 7 mean?
apb_write(16'h0004, 32'h0000_0085);
apb_read(16'h0004, data);
```

Problems:
- You must remember hex addresses (is it 0x0004 or 0x0008?)
- You must know which bits are which
- If the address map changes, every test breaks
- No automatic readback checking

### What RAL Gives You

RAL (Register Abstraction Layer) is a UVM library that creates a **software
model** of your DUT's registers. Think of it as a **remote control** for your
DUT:

```
 You press a button          RAL translates it          DUT receives the command
 on the remote      --->     into a signal      --->    and responds
 (write "TX enable")        (APB bus transaction)       (register stores the value)
```

### The RAL Remote Control Analogy

```
┌─────────────────────────────────────────────────────────────────────┐
│                        YOUR TEST (the user)                        │
│                                                                     │
│  ral_h.registers["global_control"].write(status, 32'h0000_0085);  │
│                                                                     │
│  "I want to enable RX and TX" (human-readable intent)              │
└─────────────────────────────┬───────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     RAL MODEL (the remote control)                 │
│                                                                     │
│  - Knows "global_control" is at address 0x0004                    │
│  - Knows which bits are RX enable, TX enable, etc.                │
│  - Keeps a mirror (copy) of the last value you wrote              │
│  - Automatically checks readback matches your intent              │
└─────────────────────────────┬───────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   APB ADAPTER (the IR signal)                      │
│                                                                     │
│  - Converts RAL write into APB bus transaction                    │
│  - Sets pwrite=1, addr=0x0004, wdata=0x0000_0085                 │
│  - Sends to APB sequencer                                         │
└─────────────────────────────┬───────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                   APB AGENT (the wiring)                           │
│                                                                     │
│  - APB sequencer queues the transaction                           │
│  - APB driver drives pwrite, penable, paddr, pwdata on the bus   │
│  - APB monitor observes what happened                             │
└─────────────────────────────┬───────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────────┐
│                     DUT (the TV)                                    │
│                                                                     │
│  - MAC register block receives the APB write                      │
│  - Stores 0x0000_0085 in REG_GLOBAL_CONTROL                      │
│  - MAC enables RX and TX                                          │
└─────────────────────────────────────────────────────────────────────┘
```

### Key Benefits in This Project

1. **No hardcoded addresses** — use `ral_h.registers["global_control"]` instead
   of `apb_write(16'h0004, ...)`
2. **Automatic mirror** — RAL remembers what you wrote, so you can check it later
3. **Named registers** — code is self-documenting
4. **APB adapter** — automatically converts between RAL and APB bus protocol
5. **Predictor** — automatically updates the mirror when APB transactions happen
   on the bus (even from direct APB sequences)

### When to Use RAL vs Direct APB

| Situation | Use RAL | Use Direct APB |
| --- | --- | --- |
| Write/read a named configuration register | Yes | No |
| Check APB protocol behavior (PSLVERR, wait states) | No | Yes |
| Clear an interrupt (W1C) | No | Yes |
| Verify a register's effect on traffic | Yes for setup | No |
| Sweep all addresses for access violations | No | Yes |

---

## 1. Key RAL Concepts Explained

### 1.1 Mirror vs Desired

RAL maintains two copies of each register value:

```
┌─────────────────────────────────────────────────────────────────┐
│                     RAL Register Model                         │
│                                                                 │
│  ┌─────────────────┐        ┌─────────────────┐               │
│  │    MIRROR       │        │    DESIRED      │               │
│  │                 │        │                 │               │
│  │ Last known      │        │ Value waiting   │               │
│  │ hardware value  │        │ to be written   │               │
│  │                 │        │                 │               │
│  │ 0x0000_0040     │        │ 0x0000_0085     │               │
│  │ (reset value)   │        │ (your write)    │               │
│  └─────────────────┘        └─────────────────┘               │
│                                                                 │
│  After write():  Mirror updates to match Desired               │
│  After read():   Mirror updates to match hardware              │
└─────────────────────────────────────────────────────────────────┘
```

**Example:**

```systemverilog
// Mirror starts at reset value: 0x0000_0040
uvm_reg_data_t mirror_val;

ral_h.registers["global_control"].write(status, 32'h0000_0085);

// After write(), mirror is updated to 0x0000_0085
ral_h.registers["global_control"].mirror(status, mirror_val);
// mirror_val == 0x0000_0085

// BUT: mirror() also does a read to verify hardware matches!
// For volatile registers, this is dangerous - see section 1.4
```

**Important:** For volatile registers (status, counters), NEVER use `mirror()`.
Always do a fresh `read()` instead.

### 1.2 Frontdoor vs Backdoor Access

```
┌─────────────────────────────────────────────────────────────────────┐
│                        FRONTDOOR ACCESS                            │
│                                                                     │
│  Test ──→ RAL ──→ APB Adapter ──→ APB Agent ──→ DUT Register    │
│                                                                     │
│  The REAL bus path. Takes time. Follows APB protocol.             │
│  This is what the actual hardware does.                            │
│                                                                     │
│  Usage:                                                             │
│  ral_h.registers["name"].write(status, data,                       │
│                                UVM_FRONTDOOR, ral_h.default_map); │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                        BACKDOOR ACCESS                             │
│                                                                     │
│  Test ──→ RAL ──→ Direct memory poke (bypasses APB)              │
│                                                                     │
│  Bypasses the bus entirely. Instant. Does not test APB protocol.  │
│  NOT USED in this project.                                         │
│                                                                     │
│  Usage:                                                             │
│  ral_h.registers["name"].write(status, data,                       │
│                                UVM_BACKDOOR);  // NOT USED HERE   │
└─────────────────────────────────────────────────────────────────────┘
```

**In this project, always use UVM_FRONTDOOR.** The APB adapter translates
RAL operations into real APB bus transactions.

### 1.3 Volatile vs Non-Volatile Registers

```
┌─────────────────────────────────────────────────────────────────────┐
│                    NON-VOLATILE (Configuration)                    │
│                                                                     │
│  - Stores what software writes                                     │
│  - Readback matches last write (after masking reserved bits)      │
│  - Examples: global_control, mac_addr_low, max_frame_size         │
│                                                                     │
│  Test pattern:                                                     │
│    1. Write a value                                                │
│    2. Read it back                                                 │
│    3. Compare (with mask for reserved bits)                        │
└─────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────┐
│                      VOLATILE (Status/Counter)                     │
│                                                                     │
│  - Hardware updates it based on events                             │
│  - Software writes are IGNORED or have special meaning (W1C)     │
│  - Readback changes anytime                                        │
│  - Examples: rx_status, interrupt_status, rx_invalid_count        │
│                                                                     │
│  Test pattern:                                                     │
│    1. Cause an event (send a bad frame, trigger interrupt)        │
│    2. Wait for event to complete                                   │
│    3. Read the register                                            │
│    4. Check the expected bit/counter value                         │
│                                                                     │
│  NEVER use mirror() for volatile registers!                        │
└─────────────────────────────────────────────────────────────────────┘
```

### 1.4 W1C (Write-1-to-Clear) Behavior

Some registers use W1C access type:

```
┌─────────────────────────────────────────────────────────────────────┐
│                    W1C (Write-1-to-Clear)                          │
│                                                                     │
│  Writing a '1' to a bit CLEARS that bit                           │
│  Writing a '0' to a bit LEAVES IT UNCHANGED                       │
│                                                                     │
│  Example: REG_INTERRUPT_STATUS                                    │
│  ┌───────────────────────────────────────────────┐                 │
│  │ Bit:  6   5   4   3   2   1   0              │                 │
│  │       TX  PAU PAU UNS OVR CRC INV            │                 │
│  │       ERR EXP ACT SUP     ERR                 │                 │
│  │                                               │                 │
│  │ Current value: 0b0000_0101 (bits 0 and 2 set)│                 │
│  │                                               │                 │
│  │ Write 0b0000_0001 → clears bit 0 only        │                 │
│  │ New value:       0b0000_0100                  │                 │
│  │                                               │                 │
│  │ Write 0b0000_0100 → clears bit 2 only        │                 │
│  │ New value:       0b0000_0000                  │                 │
│  └───────────────────────────────────────────────┘                 │
│                                                                     │
│  IMPORTANT: W1C registers are mapped as "RW" in the RAL map       │
│  (UVM 1.1d limitation). The field-level policy remains "W1C".    │
└─────────────────────────────────────────────────────────────────────┘
```

**W1C Test Pattern:**

```systemverilog
// 1. Enable an interrupt cause
ral_h.registers["interrupt_enable"].write(status, 32'h0000_0001);

// 2. Cause the interrupt (send invalid frame, etc.)
// ... traffic generation ...

// 3. Read interrupt status - bit 0 should be set
ral_h.registers["interrupt_status"].read(status, data);
if (data[0] != 1'b1)
  `uvm_error("TEST", "Interrupt bit 0 not set")

// 4. Clear ONLY bit 0 by writing 1 to it
ral_h.registers["interrupt_status"].write(status, 32'h0000_0001);

// 5. Read again - bit 0 should be clear
ral_h.registers["interrupt_status"].read(status, data);
if (data[0] != 1'b0)
  `uvm_error("TEST", "Interrupt bit 0 not cleared")
```

### 1.5 Register Fields and Masking

A 32-bit register can contain multiple named fields:

```
┌─────────────────────────────────────────────────────────────────────┐
│              REG_GLOBAL_CONTROL (0x0004)                           │
│                                                                     │
│  31        7    6      5      4      3      2      1    0         │
│  ┌────────┬────┬──────┬──────┬──────┬──────┬──────┬────┬────┐    │
│  │Reserved│OVFL│PAUSE │COLL  │PAUSE │CARR  │ TX   │ RSV│ RX │    │
│  │        │POL │      │ISION │      │      │      │    │    │    │
│  └────────┴────┴──────┴──────┴──────┴──────┴──────┴────┴────┘    │
│                                                                     │
│  Reset value: 0x0000_0040 (only bit 6 set = oversize policy)      │
│                                                                     │
│  To set RX and TX without touching other bits:                    │
│    1. Read current value                                           │
│    2. Set bits 0 and 2                                             │
│    3. Write back                                                   │
│                                                                     │
│  OR use named constants from reg_map_pkg:                         │
│    data = current_value;                                           │
│    data |= (1 << reg_map_pkg::CTRL_RX_BIT);                       │
│    data |= (1 << reg_map_pkg::CTRL_TX_BIT);                       │
└─────────────────────────────────────────────────────────────────────┘
```

**Masking Example:**

```systemverilog
// REG_MAC_ADDR_HIGH only uses bits [15:0]
// Upper bits [31:16] are reserved and read as 0

// Write upper 16 bits of MAC address
ral_h.registers["mac_addr_high"].write(status, 32'h0000_4567);

// Read back and check only defined bits
ral_h.registers["mac_addr_high"].read(status, data);
if (data[15:0] != 16'h4567)
  `uvm_error("TEST", $sformatf("Readback mismatch: %h", data))
// Don't check bits [31:16] - they're reserved!
```

---

## 2. Register access model

The MAC exposes a 32-bit APB register interface with 16-bit byte addresses.
All defined registers are word-aligned on 4-byte boundaries.

```text
test -> APB read/write sequence or RAL frontdoor operation
     -> APB sequencer -> APB driver -> APB bus -> MAC register block
     -> APB monitor / RAL predictor / status and traffic checks
```

Two kinds of values appear in the map:

- **Configuration registers** store software-programmed intent.  Readback can
  be compared to the written value, after masking reserved bits.
- **Status and counter registers** report live MAC-domain state through a
  clock-domain crossing.  They must be tested by causing the corresponding
  event, then reading the observed result; do not expect a software write to
  remain in a status register.

An APB write completing means the APB-side register accepted the command.  If
the setting crosses to the MAC clock domain, allow an observable handshake or
documented settling interval before testing data-path behavior.

---

## 3. Register map, values, and purpose

### Identification and global control

| Address | Register | Access | Reset/read value | Purpose and test notes |
| --- | --- | --- | --- | --- |
| `0x0000` | `REG_VERSION` | RO | `0x4150_4231` (`"APB1"`) | Immutable implementation ID. Read through direct APB and RAL frontdoor. A write must not change it. |
| `0x0004` | `REG_GLOBAL_CONTROL` | RW | `0x0000_0040` | Main MAC enables and policy controls. Write only defined bits and compare defined bits. |
| `0x0008` | `REG_MAC_ADDR_LOW` | RW | `0x0000_0000` | Low 32 bits of the MAC address. |
| `0x000C` | `REG_MAC_ADDR_HIGH` | RW, bits `[15:0]` | `0x0000_0000` | Upper 16 bits of the MAC address; upper read bits are reserved zero. |
| `0x0010` | `REG_MAX_CLIENT_DATA` | RW, bits `[15:0]` | `1500` | Client payload/data length limit. |
| `0x0014` | `REG_OVERSIZE_CONTROL` | RO alias | bit 6 of global control | Read-only view of the global oversize control. |
| `0x0018` | `REG_PAUSE_CONTROL` | RO alias | bits `[5:4]` of global control | Read-only view of global PAUSE and collision/policy control bits. |

Defined global-control bit positions are provided by `reg_map_pkg`:

| Bit | Name | Meaning |
| --- | --- | --- |
| 0 | `CTRL_RX_BIT` | RX enable |
| 2 | `CTRL_TX_BIT` | TX enable |
| 3 | `CTRL_CARRIER_BIT` | Carrier-related control |
| 4 | `CTRL_PAUSE_BIT` | RX PAUSE/control handling enable |
| 5 | `CTRL_COLLISION_BIT` | Collision-related control |
| 6 | `CTRL_OVERSIZE_BIT` | Oversize policy control |
| 7 | `CTRL_PROMISCUOUS_BIT` | Promiscuous receive mode |

Example baseline value `32'h0000_0085` enables RX, TX, and promiscuous mode.
Use named bit positions when changing an individual field so the test does
not accidentally clear an unrelated control bit.

### Status, interrupts, and counters

| Address | Register | Access | Purpose and test notes |
| --- | --- | --- | --- |
| `0x001C` | `REG_PAUSE_STATUS` | RO, volatile | Bit 0 reports PAUSE expiry. Generate/expire a PAUSE condition, then read it. |
| `0x0020` | `REG_RX_STATUS` | RO, volatile | Bit 0 reports `pause_active`. `mac_pause_rx_test_c` demonstrates this use. |
| `0x0024` | `REG_TX_STATUS` | RO, volatile | Bit 0 reports a TX error event. |
| `0x0028` | `REG_INTERRUPT_ENABLE` | RW | Enables interrupt causes, bits `[6:0]`. Reset is zero (all masked). |
| `0x002C` | `REG_INTERRUPT_STATUS` | W1C, volatile | Active enabled interrupt causes. Write `1` to a bit to request clear; writing `0` leaves it unchanged. |
| `0x0030` | `REG_RX_INVALID_COUNT` | RO, volatile; write bit 0 clears | Count of RX invalid-frame events. |
| `0x0034` | `REG_RX_OVERSIZE_COUNT` | RO, volatile; write bit 0 clears | Count of RX oversize events. |
| `0x0038` | `REG_RX_UNSUPPORTED_COUNT` | RO, volatile; write bit 0 clears | Count of unsupported-control events. |

Interrupt bit positions are:

| Bit | Name | Cause |
| --- | --- | --- |
| 0 | `INT_RX_INVALID_BIT` | Invalid RX frame |
| 1 | `INT_RX_CRC_BIT` | RX CRC error |
| 2 | `INT_RX_OVERSIZE_BIT` | RX oversize frame |
| 3 | `INT_RX_UNSUPPORTED_BIT` | Unsupported control frame |
| 4 | `INT_PAUSE_ACTIVE_BIT` | PAUSE active |
| 5 | `INT_PAUSE_EXPIRED_BIT` | PAUSE expiry |
| 6 | `INT_TX_ERROR_BIT` | TX error event |

`REG_INTERRUPT_STATUS` is the enabled-cause view: the MAC forms it from
latched causes AND `REG_INTERRUPT_ENABLE[6:0]`.  Therefore an event with its
enable bit clear may affect a counter but will not appear in interrupt status.

### PAUSE, speed, and frame-size configuration

| Address | Register | Access | Reset | Purpose and defined fields |
| --- | --- | --- | --- | --- |
| `0x003C` | `REG_PAUSE_TX_CONFIG` | RW, bits `[15:0]` | `0` | Bit 0 enables TX PAUSE; bit 1 is soft request; bits `[15:0]` carry PAUSE quanta. Clear soft request after issuing it because it is level-sensitive. |
| `0x0040` | `REG_MAC_SPEED_CONFIG` | RW | `0x4` | Bits `[2:0]` program speed; bit 3 enables override; bits `[6:4]` read effective speed synchronized from MAC clock. |
| `0x0044` | `REG_MAX_FRAME_SIZE` | RW, bits `[15:0]` | `1518` | Maximum frame-size policy. |
| `0x0048` | `REG_MIN_FRAME_SIZE` | RW, bits `[15:0]` | `64` | Minimum frame-size policy. |
| `0x004C` | `REG_FRAME_SIZE_STATUS` | RO, volatile | `0` | Frame-size status. Read after a scenario that is expected to update it. |

For `REG_MAC_SPEED_CONFIG`, compare only bits `[3:0]` immediately after a
write.  Bits `[6:4]` are asynchronous-effective state returning through CDC,
so a same-cycle full-word readback check is unsafe.

### Address-filter groups

There are four 48-bit address-filter entries.  For group `n` (`0..3`):

| Register | Address formula | Fields |
| --- | --- | --- |
| `group<n>_low` | `0x0050 + n * 0x8` | Address bits `[31:0]` |
| `group<n>_high` | `0x0054 + n * 0x8` | Address bits `[47:32]`; bit 16 is group-valid |

Use `reg_map_pkg::group_low_addr(index)` and
`reg_map_pkg::group_high_addr(index)` instead of calculating addresses in a
test.  A group-address test should program both halves, read them back with a
mask of `32'h0001_FFFF` for the high word, then drive a frame that proves the
configured address is accepted or rejected as intended.

---

## 4. Direct APB sequence versus RAL

Use direct APB sequences for bus-level behavior and RAL for named register
intent.  Both use the same APB driver and must agree on expected behavior.

| Need | Preferred approach | Why |
| --- | --- | --- |
| Verify APB setup/access response, `PSLVERR`, or APB wait behavior | `apb_read_sequence_c` / `apb_write_sequence_c` | The test needs bus response details. |
| Write/read one named configuration register | RAL frontdoor `write()` / `read()` | Named register avoids raw address duplication. |
| Check masks/reserved bits or a special readback alias | Direct APB helper or RAL read plus explicit mask | The expected value is semantic, not merely the mirror. |
| Clear W1C interrupt status/counters | Direct APB sequence with explicit clear mask | The write is an action, not a normal stored value. |
| Verify a traffic side effect after a register write | APB/RAL for setup, then AXI/RS sequence and monitor/scoreboard checks | Readback alone does not prove the datapath used the setting. |

RAL is not a second register implementation.  It is a UVM model of the APB
boundary.  In this project `mac_ral_block_c` creates a 32-bit APB map,
`mac_apb_reg_adapter_c` translates RAL operations to `apb_transfer_t`, and
`mac_base_test_c` binds the map to the APB virtual sequencer in
`end_of_elaboration_phase`.

---

## 5. How to use RAL

### 5.1 The Complete RAL Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           TEST CLASS                                       │
│                                                                             │
│  ral_h.registers["global_control"].write(status, 32'h0000_0085);          │
│  ral_h.registers["global_control"].read(status, data);                     │
│                                                                             │
│  Handles provided by mac_base_test_c:                                      │
│    ral_h          — the register block (all named registers)              │
│    ral_adapter_h  — translates RAL ↔ APB                                  │
└─────────────────────────────────┬───────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                     RAL BLOCK (mac_ral_block_c)                            │
│                                                                             │
│  registers["version"]          → mac_ral_reg_c @ 0x0000 (RO)             │
│  registers["global_control"]   → mac_ral_reg_c @ 0x0004 (RW)             │
│  registers["mac_addr_low"]     → mac_ral_reg_c @ 0x0008 (RW)             │
│  ... (20 fixed + 8 group registers)                                       │
│                                                                             │
│  default_map: 32-bit addresses, 4-byte granularity, little-endian         │
│  Bound to APB sequencer in end_of_elaboration_phase                       │
└─────────────────────────────────┬───────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                  APB ADAPTER (mac_apb_reg_adapter_c)                       │
│                                                                             │
│  reg2bus():                                                                │
│    Input:  uvm_reg_bus_op (kind, addr, data)                              │
│    Output: apb_transfer_t (pwrite, addr, wdata)                           │
│                                                                             │
│  bus2reg():                                                                │
│    Input:  apb_transfer_t (rdata, status)                                  │
│    Output: uvm_reg_bus_op (data, status → UVM_IS_OK/UVM_NOT_OK)          │
└─────────────────────────────────┬───────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                     APB AGENT                                               │
│                                                                             │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                 │
│  │   Sequencer  │───→│    Driver    │───→│   Monitor    │                 │
│  │              │    │              │    │              │                 │
│  │ Accepts      │    │ Drives APB   │    │ Observes     │                 │
│  │ apb_transfer │    │ signals on   │    │ transactions │                 │
│  │ items        │    │ the bus      │    │ on the bus   │                 │
│  └──────────────┘    └──────────────┘    └──────┬───────┘                 │
│                                                  │                         │
│                                                  ▼                         │
│                                         ┌──────────────────┐              │
│                                         │   RAL Predictor  │              │
│                                         │                  │              │
│                                         │ Auto-updates     │              │
│                                         │ mirror from      │              │
│                                         │ observed APB     │              │
│                                         │ transactions     │              │
│                                         └──────────────────┘              │
└─────────────────────────────────────────────────────────────────────────────┘
                                  │
                                  ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                           DUT (MAC)                                         │
│                                                                             │
│  APB interface: psel, penable, pwrite, paddr[15:0], pwdata[31:0]         │
│                          ↕                                                  │
│  Register block: REG_GLOBAL_CONTROL, REG_VERSION, etc.                    │
│                          ↕                                                  │
│  MAC datapath: TX engine, RX engine, CRC, etc.                            │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 How RAL is Created and Bound

**Step 1: Base test creates RAL objects** (in `configure_test()`)

```systemverilog
// mac_base_test.svh lines 87-91
ral_h = mac_ral_block_c::type_id::create("ral_h");  // Create the block
ral_h.build();                                        // Build all registers
ral_adapter_h = mac_apb_reg_adapter_c::type_id::create("ral_adapter_h");
env_cfg_h.ral_h = ral_h;                             // Pass to env config
env_cfg_h.ral_adapter_h = ral_adapter_h;
```

**Step 2: Base test binds RAL map to APB sequencer** (in `end_of_elaboration_phase`)

```systemverilog
// mac_base_test.svh line 134
ral_h.default_map.set_sequencer(env_h.virtual_sequencer_h.apb_seqr_h,
                                 ral_adapter_h);
```

This single line connects the RAL model to the real APB bus. Now any
`ral_h.registers["name"].write()` or `read()` will go through the APB agent.

**Step 3: Environment creates RAL predictor** (in `mac_tb.sv`)

```systemverilog
// mac_tb.sv lines 54-55, 131-134
ral_predictor_h = uvm_reg_predictor#(apb_transfer_t)::type_id::create(...);
ral_predictor_h.map = cfg_h.ral_h.get_default_map();
ral_predictor_h.adapter = cfg_h.ral_adapter_h;
apb3_agent_top_h.active_agents[0].monitor_h.ap.connect(ral_predictor_h.bus_in);
```

The predictor watches APB transactions on the bus and automatically updates the
RAL mirror. This means even direct APB sequences (not going through RAL) will
update the mirror.

### 5.3 RAL Read/Write Operations

The base test provides these handles:

```systemverilog
mac_ral_block_c       ral_h;
mac_apb_reg_adapter_c ral_adapter_h;
```

The RAL block holds named registers in `ral_h.registers[string]`.  Use the
frontdoor map so the operation crosses the real APB interface:

```systemverilog
uvm_status_e status;
uvm_reg_data_t data;

ral_h.registers["version"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
if (status != UVM_IS_OK || data != 32'h4150_4231)
  `uvm_error("MAC_RAL", $sformatf("Version read failed: status=%s data=%h",
                                  status.name(), data))
```

For a normal writable register:

```systemverilog
ral_h.registers["max_client_data"].write(status, 16'd1500,
                                          UVM_FRONTDOOR, ral_h.default_map);
if (status != UVM_IS_OK)
  `uvm_error("MAC_RAL", "MAX_CLIENT_DATA write failed")

ral_h.registers["max_client_data"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
if (status != UVM_IS_OK || data[15:0] != 16'd1500)
  `uvm_error("MAC_RAL", $sformatf("MAX_CLIENT_DATA readback=%h", data))
```

Use a fresh frontdoor read for volatile status/counter registers.  Do not rely
on a RAL mirror prediction as proof of a live MAC event, and do not call
`mirror()` as a substitute for a defined functional expectation.

### 5.4 What Happens During a RAL Write

```
Timeline of a RAL write operation:

Cycle 1: Test calls write()
  └─→ ral_h.registers["global_control"].write(status, 32'h0000_0085)

Cycle 2: RAL calls adapter.regbus()
  └─→ adapter creates apb_transfer_t with:
        pwrite = 1 (write)
        addr   = 0x0004
        wdata  = 0x0000_0085

Cycle 3: APB sequencer accepts the item
  └─→ Item enters the sequencer's FIFO

Cycle 4: APB driver gets the item
  └─→ Driver drives APB signals:
        psel    = 1
        paddr   = 16'h0004
        pwdata  = 32'h0000_0085
        pwrite  = 1

Cycle 5: APB transfer completes
  └─→ Driver sets penable = 1
  └─→ DUT registers the write

Cycle 6: Response returns to RAL
  └─→ adapter.bus2reg() converts response
  └─→ RAL updates mirror to 0x0000_0085
  └─→ status = UVM_IS_OK
```

### 5.5 What Happens During a RAL Read

```
Timeline of a RAL read operation:

Cycle 1: Test calls read()
  └─→ ral_h.registers["version"].read(status, data)

Cycle 2: RAL calls adapter.regbus()
  └─→ adapter creates apb_transfer_t with:
        pwrite = 0 (read)
        addr   = 0x0000

Cycle 3: APB transfer completes
  └─→ Driver drives APB signals
  └─→ DUT responds with rdata = 0x4150_4231

Cycle 4: Response returns to RAL
  └─→ adapter.bus2reg() extracts rdata
  └─→ data = 0x4150_4231
  └─→ RAL updates mirror to 0x4150_4231
  └─→ status = UVM_IS_OK
```

---

## 6. How to write a register test

Create a focused test extending `mac_base_test_c`.  Reuse the APB helpers in
`mac_register_access_test_c` or create local helpers with the same pattern.

### 6.1 Basic Test Template

```systemverilog
class mac_max_frame_size_test_c extends mac_base_test_c;
  `uvm_component_utils(mac_max_frame_size_test_c)

  extern virtual task run_stimulus(uvm_phase phase);
endclass

task mac_max_frame_size_test_c::run_stimulus(uvm_phase phase);
  uvm_status_e status;
  uvm_reg_data_t data;

  // Step 1: Write the register
  ral_h.registers["max_frame_size"].write(status, 16'd1536,
                                            UVM_FRONTDOOR, ral_h.default_map);
  if (status != UVM_IS_OK)
    `uvm_fatal("MAC_FRAME_SIZE", "APB write failed")

  // Step 2: Read back and verify
  ral_h.registers["max_frame_size"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
  if (status != UVM_IS_OK || data[15:0] != 16'd1536)
    `uvm_error("MAC_FRAME_SIZE", $sformatf("Readback got %h; expected 0x0600", data))

  // Step 3: Verify the register's effect on traffic
  // Start AXI or RS traffic here and verify the intended size-policy effect
  // using the monitor, scoreboard, and relevant status/counter register.
endtask
```

### 6.2 Example: Testing a Volatile Status Register

```systemverilog
task mac_rx_status_test_c::run_stimulus(uvm_phase phase);
  uvm_status_e status;
  uvm_reg_data_t data;

  // Step 1: Enable RX PAUSE in global control
  ral_h.registers["global_control"].write(status, 32'h0000_0095,
                                            UVM_FRONTDOOR, ral_h.default_map);

  // Step 2: Wait for CDC to settle (config crosses to MAC domain)
  #200;

  // Step 3: Cause the event - drive a PAUSE frame
  // ... (traffic generation code) ...

  // Step 4: Wait for DUT to process the frame
  #1us;

  // Step 5: Read the STATUS register (NOT mirror!)
  ral_h.registers["rx_status"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);

  // Step 6: Check the specific bit
  if (data[0] != 1'b1)
    `uvm_error("MAC_RX_STATUS", $sformatf("pause_active not set: %h", data))
endtask
```

### 6.3 Example: Testing with Masks for Reserved Bits

```systemverilog
task mac_speed_config_test_c::run_stimulus(uvm_phase phase);
  uvm_status_e status;
  uvm_reg_data_t data;

  // Step 1: Write speed config (bits [2:0] = speed, bit 3 = override enable)
  ral_h.registers["mac_speed_config"].write(status, 32'h0000_000C,
                                              UVM_FRONTDOOR, ral_h.default_map);

  // Step 2: Read back - only check bits [3:0]
  // Bits [6:4] are CDC-synchronized and may not match yet
  ral_h.registers["mac_speed_config"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
  if ((data[3:0]) != 4'hC)
    `uvm_error("MAC_SPEED", $sformatf("Speed config mismatch: %h", data))
  // Don't check bits [6:4] - they cross clock domains!
endtask
```

### 6.4 Example: Testing W1C Interrupt Clear

```systemverilog
task mac_interrupt_clear_test_c::run_stimulus(uvm_phase phase);
  uvm_status_e status;
  uvm_reg_data_t data;

  // Step 1: Enable interrupt for RX invalid frame
  ral_h.registers["interrupt_enable"].write(status, 32'h0000_0001,
                                              UVM_FRONTDOOR, ral_h.default_map);

  // Step 2: Cause an invalid frame event
  // ... (send frame with CRC error) ...

  // Step 3: Wait for event
  #1us;

  // Step 4: Read interrupt status - bit 0 should be set
  ral_h.registers["interrupt_status"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
  if (data[0] != 1'b1)
    `uvm_error("MAC_INT", $sformatf("Interrupt bit 0 not set: %h", data))

  // Step 5: Clear ONLY bit 0 (write 1 to clear it)
  ral_h.registers["interrupt_status"].write(status, 32'h0000_0001,
                                              UVM_FRONTDOOR, ral_h.default_map);

  // Step 6: Verify bit 0 is cleared
  ral_h.registers["interrupt_status"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
  if (data[0] != 1'b0)
    `uvm_error("MAC_INT", $sformatf("Interrupt bit 0 not cleared: %h", data))
endtask
```

### 6.5 Example: Testing Address-Filter Groups

```systemverilog
task mac_addr_filter_test_c::run_stimulus(uvm_phase phase);
  uvm_status_e status;
  uvm_reg_data_t data;

  // Step 1: Program group 0 with a MAC address
  ral_h.registers["group0_low"].write(status, 32'hA5A5_0001,
                                        UVM_FRONTDOOR, ral_h.default_map);
  ral_h.registers["group0_high"].write(status, 32'h0001_0203,
                                         UVM_FRONTDOOR, ral_h.default_map);

  // Step 2: Read back with mask for reserved bits
  ral_h.registers["group0_low"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
  if (data != 32'hA5A5_0001)
    `uvm_error("MAC_ADDR_FILTER", $sformatf("group0_low mismatch: %h", data))

  ral_h.registers["group0_high"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
  if (data[15:0] != 16'h0203 || data[16] != 1'b1)
    `uvm_error("MAC_ADDR_FILTER", $sformatf("group0_high mismatch: %h", data))

  // Step 3: Drive a frame with that MAC address
  // ... (traffic generation code) ...

  // Step 4: Verify frame is accepted/rejected based on global_control settings
endtask
```

### 6.6 Test Checklist

Every register test follows this sequence:

1. Define one register behavior and one expected external consequence.
2. Verify reset value or initial state if it is part of the requirement.
3. Program only defined writable bits.
4. Read back with a mask for reserved bits, aliases, or dynamic fields.
5. For a control register, run the AXI/RS scenario that proves the datapath
   consumed the control value.
6. For status/counter/interrupt registers, generate the relevant event and
   wait for the APB status response; do not write an arbitrary status value.
7. For W1C/counter-clear behavior, write a one-bit clear mask then reread and
   prove only the intended bit/counter changed.
8. Record the seed and run the shared regression before adding the test to the
   regression list.

---

## 7. Worked scenarios

### A. Read-only version register

- Direct APB read `REG_VERSION`; expect `32'h4150_4231` and `APB_OK`.
- Repeat with RAL frontdoor read; expect `UVM_IS_OK` and the same data.
- Attempt a write only if the specification requires RO-write behavior to be
  tested; verify the value remains unchanged.  Do not expect `PSLVERR` unless
  the RTL contract explicitly specifies it.

### B. Global-control and alias readback

- Write `REG_GLOBAL_CONTROL` with a defined combination such as `0xD5`.
- Read `REG_GLOBAL_CONTROL` and compare the intended defined bits.
- Read `REG_OVERSIZE_CONTROL`; compare mask `32'h0000_0040`.
- Read `REG_PAUSE_CONTROL`; compare mask `32'h0000_0030`.
- Drive traffic that proves one selected feature, for example promiscuous RX
  acceptance or PAUSE RX handling.  This is a separate focused test from the
  readback check if it needs substantial traffic setup.

### C. PAUSE TX soft request

- Write `REG_PAUSE_TX_CONFIG = 0x0001` to enable PAUSE TX.
- Write `0x0003` to assert soft request.
- Write `0x0001` again to clear the level-sensitive request.
- Wait with `mac_wait_utils_c::wait_for_count_at_least()` for one RS egress
  frame, then let the scoreboard/reference model validate it.  This is the
  existing `mac_pause_tx_test_c` pattern.

### D. Interrupt W1C behavior

- Enable one interrupt cause in `REG_INTERRUPT_ENABLE`.
- Drive the exact traffic/error that causes that event.
- Read `REG_INTERRUPT_STATUS` and verify the enabled cause bit is set.
- Write a clear mask containing only that bit to `REG_INTERRUPT_STATUS`.
- Read again and verify the requested cause clears without clearing unrelated
  latched causes.  Test masked-event behavior separately.

### E. Address-filter group behavior

- Program `group_low_addr(0)` with the lower 32 address bits.
- Program `group_high_addr(0)` with upper 16 bits and valid bit 16 set.
- Read both halves with appropriate masks.
- Drive an RS frame addressed to that MAC address; expect delivery according
  to the current global-control/promiscuous policy.
- Clear valid bit 16 and rerun the frame as a separate negative scenario.

---

## 8. Common Pitfalls and How to Avoid Them

### Pitfall 1: Using mirror() for Volatile Registers

**Wrong:**
```systemverilog
// mirror() does a read AND compares to cached value
// For volatile registers, this is unreliable
ral_h.registers["rx_status"].mirror(status, data);
if (data[0] != 1'b1)
  `uvm_error("TEST", "pause_active not set")
```

**Correct:**
```systemverilog
// Always use fresh read() for volatile registers
ral_h.registers["rx_status"].read(status, data, UVM_FRONTDOOR, ral_h.default_map);
if (data[0] != 1'b1)
  `uvm_error("TEST", "pause_active not set")
```

### Pitfall 2: Not Masking Reserved Bits

**Wrong:**
```systemverilog
// REG_MAC_ADDR_HIGH has bits [31:16] reserved
ral_h.registers["mac_addr_high"].write(status, 32'h0000_4567);
ral_h.registers["mac_addr_high"].read(status, data);
if (data != 32'h0000_4567)  // FAILS! Upper bits may not be 0
  `uvm_error("TEST", "mismatch")
```

**Correct:**
```systemverilog
ral_h.registers["mac_addr_high"].write(status, 32'h0000_4567);
ral_h.registers["mac_addr_high"].read(status, data);
if (data[15:0] != 16'h4567)  // Only check defined bits
  `uvm_error("TEST", "mismatch")
```

### Pitfall 3: Forgetting CDC Latency

**Wrong:**
```systemverilog
// Config crosses to MAC clock domain - need time to settle!
ral_h.registers["global_control"].write(status, 32'h0000_0095);
// Immediately drive traffic - CONFIG NOT YET APPLIED!
send_pause_frame();
```

**Correct:**
```systemverilog
ral_h.registers["global_control"].write(status, 32'h0000_0095);
#200;  // Wait for CDC handshake to complete
send_pause_frame();
```

### Pitfall 4: Writing to RO Registers

**Wrong:**
```systemverilog
// REG_VERSION is read-only - write is ignored
ral_h.registers["version"].write(status, 32'h1234_5678);
// Don't expect the value to change!
```

**Correct:**
```systemverilog
// Test RO behavior explicitly
ral_h.registers["version"].write(status, 32'h1234_5678);
ral_h.registers["version"].read(status, data);
if (data != 32'h4150_4231)  // Value unchanged
  `uvm_error("TEST", "RO register changed!")
```

### Pitfall 5: Using Address Literals

**Wrong:**
```systemverilog
apb_write(16'h0004, 32'h0000_0085);  // What is 0x0004?
```

**Correct:**
```systemverilog
// Use named constants from reg_map_pkg
apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0085);
// OR use RAL
ral_h.registers["global_control"].write(status, 32'h0000_0085);
```

### Pitfall 6: Not Checking APB Status

**Wrong:**
```systemverilog
ral_h.registers["max_frame_size"].write(status, data);
// Ignore status - what if APB failed?
```

**Correct:**
```systemverilog
ral_h.registers["max_frame_size"].write(status, data);
if (status != UVM_IS_OK)
  `uvm_error("TEST", $sformatf("APB write failed: %s", status.name()))
```

---

## 9. Debugging RAL Issues

### 9.1 Check if RAL Map is Bound

If RAL operations don't work, the map might not be bound to the sequencer.

**Symptom:** RAL read/write hangs or times out.

**Debug steps:**

```systemverilog
// In your test, check if the map is bound
if (ral_h.default_map.get_sequencer() == null)
  `uvm_error("DEBUG", "RAL map not bound to sequencer!")
else
  `uvm_info("DEBUG", "RAL map is bound", UVM_LOW)
```

### 9.2 Read Mirror for Debugging

```systemverilog
uvm_reg_data_t mirror_val;
uvm_status_e status;

// Get the mirror value without doing a bus read
ral_h.registers["global_control"].mirror(status, mirror_val);
`uvm_info("DEBUG", $sformatf("Mirror value: %h", mirror_val), UVM_LOW)
```

### 9.3 Enable UVM RAL Tracing

Add this plusarg to your simulation command:

```bash
+UVM_VERBOSITY=UVM_HIGH
+UVM_REG_TRACE
```

This will print detailed RAL operation traces:

```
UVM_INFO @ 0: uvm_reg [ral_h.registers[global_control]] Write: 'h00000085
UVM_INFO @ 0: uvm_reg [ral_h.registers[global_control]] Read: 'h00000085
```

### 9.4 Common Error Messages

| Error Message | Cause | Fix |
| --- | --- | --- |
| `UVM_FATAL: RAL map not bound` | RAL default_map has no sequencer | Check `end_of_elaboration_phase` binding |
| `UVM_ERROR: bus2reg: Expected apb_transfer_t` | Adapter received wrong type | Check APB agent configuration |
| `UVM_ERROR: Status: UVM_NOT_OK` | APB transaction failed | Check APB protocol, address, DUT reset |
| `UVM_WARNING: Register is volatile` | Using mirror() on volatile register | Use read() instead |

### 9.5 Verify RAL is Properly Wired

The `mac_register_access_test_c` includes a RAL frontdoor validation:

```systemverilog
// This test confirms the RAL frontdoor is actually wired
ral_h.registers["version"].read(ral_status, ral_data, UVM_FRONTDOOR, ral_h.default_map);
if (ral_status != UVM_IS_OK || ral_data != 32'h4150_4231)
  `uvm_error("MAC_RAL_FRONTDOOR", "RAL frontdoor not working!")
```

If this test passes, your RAL infrastructure is correctly connected.

---

## 10. Glossary of RAL Terms

| Term | Definition |
| --- | --- |
| **Mirror** | The RAL's cached copy of a register's value. Updated after read() or write(). |
| **Desired** | The value you want to write to a register. May differ from mirror if write() hasn't completed. |
| **Frontdoor** | Access through the real bus interface (APB in this project). Takes time, follows protocol. |
| **Backdoor** | Direct memory access bypassing the bus. NOT used in this project. |
| **Predictor** | Component that watches bus transactions and automatically updates the mirror. |
| **Adapter** | Translates between RAL operations and bus-specific transactions (apb_transfer_t). |
| **Map** | Address map that defines register locations and access policies. |
| **Field** | A sub-portion of a register (e.g., bits [6:0] for interrupt enable). |
| **Access Policy** | How a register can be accessed: RW, RO, WO, W1C, etc. |
| **Volatile** | A register that can change asynchronously due to hardware events (status, counters). |
| **W1C** | Write-1-to-Clear: writing 1 clears the bit, writing 0 does nothing. |
| **CDC** | Clock Domain Crossing: register value crosses between clock domains (APB → MAC). |

---

## 11. RAL and APB test checklist

- [ ] Use `reg_map_pkg::REG_*` or RAL register names; do not copy offsets.
- [ ] Confirm the access type: RW, RO, W1C, counter-clear, alias, or volatile.
- [ ] Compare only defined bits; apply a mask for reserved fields.
- [ ] Treat MAC-domain status as asynchronous/volatile and check it after its
  causing event.
- [ ] Use RAL frontdoor for named-register intent; use APB sequences for bus
  status, expected `PSLVERR`, and explicit clear actions.
- [ ] Check a control register's actual traffic/status consequence, not only
  its APB readback.
- [ ] Preserve APB protocol checking and verify `APB_OK`/expected `APB_SLVERR`.
- [ ] Run `make run TEST=mac_register_access_test_c SEED=12345` and the full
  `make regression SEED=12345` before merge.

For the general test-authoring process, see [the test-case writing guide](test_case_guide.md).
