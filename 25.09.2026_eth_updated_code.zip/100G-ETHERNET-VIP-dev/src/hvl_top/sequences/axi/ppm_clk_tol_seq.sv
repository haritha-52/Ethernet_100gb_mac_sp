/**
 * @brief PPM clock-tolerance traffic sequence.
 *
 * Provides deterministic traffic helper methods for the PPM_LINK_001 test.
 * One class, methods only — each method creates and starts the appropriate
 * child sequence (axi_sequence_c or rs_sequence_c) on the passed sequencer.
 */
class ppm_clk_tol_seq_c extends uvm_sequence;
  `uvm_object_utils(ppm_clk_tol_seq_c)

  extern function new(string name = "ppm_clk_tol_seq_c");

  // AXI TX: send count frames with specified payload bounds.
  extern task send_axi_traffic(axi_sequencer_c seqr,
                               int unsigned count,
                               int unsigned payload_min,
                               int unsigned payload_max);

  // RS RX: send count frames with specified payload bounds.
  extern task send_rs_traffic(rs_sequencer_c seqr,
                              int unsigned count,
                              int unsigned payload_min,
                              int unsigned payload_max);

  // AXI TX: mixed 64B, 1518B, 9000B frames in round-robin.
  extern task send_mixed_frame_sizes(axi_sequencer_c seqr,
                                     int unsigned total_frames);

  // AXI TX: back-to-back minimum-IFG frames.
  extern task send_back_to_back_min_ifg(axi_sequencer_c seqr,
                                        int unsigned count);

  // AXI TX: sustained line-rate traffic (large burst, minimal gap).
  extern task send_sustained_line_rate(axi_sequencer_c seqr,
                                       int unsigned count);

  // AXI TX: randomized long-duration traffic with varied IPG.
  extern task send_randomized_long_duration(axi_sequencer_c seqr,
                                            int unsigned count);
endclass

// =============================================================================
// Constructor
// =============================================================================

function ppm_clk_tol_seq_c::new(string name = "ppm_clk_tol_seq_c");
  super.new(name);
endfunction

// =============================================================================
// AXI TX traffic with configurable payload bounds
// =============================================================================

task ppm_clk_tol_seq_c::send_axi_traffic(axi_sequencer_c seqr,
                                          int unsigned count,
                                          int unsigned payload_min,
                                          int unsigned payload_max);
  axi_sequence_c seq_h;
  seq_h            = axi_sequence_c::type_id::create("axi_ppm_traffic");
  seq_h.num_tx     = count;
  seq_h.payload_min = payload_min;
  seq_h.payload_max = payload_max;
  seq_h.start(seqr);
endtask

// =============================================================================
// RS RX traffic with configurable payload bounds
// =============================================================================

task ppm_clk_tol_seq_c::send_rs_traffic(rs_sequencer_c seqr,
                                         int unsigned count,
                                         int unsigned payload_min,
                                         int unsigned payload_max);
  repeat (count) begin
    rs_sequence_c rs_seq;
    rs_seq            = rs_sequence_c::type_id::create("rs_ppm_traffic");
    rs_seq.num_frames = 1;
    rs_seq.payload_min = payload_min;
    rs_seq.payload_max = payload_max;
    rs_seq.start(seqr);
  end
endtask

// =============================================================================
// Mixed frame sizes: round-robin through 64B, 1518B, 9000B
// =============================================================================

task ppm_clk_tol_seq_c::send_mixed_frame_sizes(axi_sequencer_c seqr,
                                                int unsigned total_frames);
  int unsigned payload_sizes[3] = '{46, 1500, 8946};  // 64B, 1518B, 9000B on wire
  int unsigned idx;

  idx = 0;
  repeat (total_frames) begin
    axi_sequence_c seq_h;
    seq_h            = axi_sequence_c::type_id::create($sformatf("axi_mixed_%0d", idx));
    seq_h.num_tx     = 1;
    seq_h.payload_min = payload_sizes[idx % 3];
    seq_h.payload_max = payload_sizes[idx % 3];
    seq_h.start(seqr);
    idx++;
  end
endtask

// =============================================================================
// Back-to-back minimum IFG: zero inter-frame delay burst
// =============================================================================

task ppm_clk_tol_seq_c::send_back_to_back_min_ifg(axi_sequencer_c seqr,
                                                   int unsigned count);
  axi_clean_sequence_c seq_h;
  seq_h            = axi_clean_sequence_c::type_id::create("axi_b2b_min_ifg");
  seq_h.num_tx     = count;
  seq_h.payload_min = 46;
  seq_h.payload_max = 46;
  seq_h.start(seqr);
endtask

// =============================================================================
// Sustained line-rate: large burst of mixed-size frames
// =============================================================================

task ppm_clk_tol_seq_c::send_sustained_line_rate(axi_sequencer_c seqr,
                                                  int unsigned count);
  axi_clean_sequence_c seq_h;
  int unsigned remaining;
  int unsigned burst_count;
  remaining = count;

  while (remaining > 0) begin
    burst_count = (remaining > 100) ? 100 : remaining;

  seq_h            = axi_clean_sequence_c::type_id::create("axi_line_rate");
  seq_h.num_tx     = burst_count;
  seq_h.payload_min = 46;
  seq_h.payload_max = 1500;
  seq_h.start(seqr);
  
   remaining -= burst_count;
  end
endtask

// =============================================================================
// Randomized long-duration: varied IPG between bursts
// =============================================================================

task ppm_clk_tol_seq_c::send_randomized_long_duration(axi_sequencer_c seqr,
                                                       int unsigned count);
  repeat (count) begin
    axi_clean_sequence_c seq_h;
    time ipg;
    ipg = $urandom_range(10, 500) * 1ns;
    seq_h            = axi_clean_sequence_c::type_id::create("axi_long_dur");
    seq_h.num_tx     = 1;
    seq_h.payload_min = 46;
    seq_h.payload_max = 1500;
    seq_h.start(seqr);
    #(ipg);
  end
endtask
