/**
 * @brief AXI TX Length/Type Mismatch Sequence.
 *
 * Drives a single AXI4-Stream TX frame where the caller-controlled
 * EtherType (which may encode a length value) is decoupled from the
 * actual payload byte count.  This enables tests to verify the MAC TX
 * path behaviour when the declared Length/Type field is inconsistent
 * with the client-supplied data.
 *
 * Extends axi_sequence_base_c so it inherits config resolution and the
 * do_axi_item() driving helper.
 */
class axi_tx_len_mismatch_seq_c extends axi_sequence_base_c;
  `uvm_object_utils(axi_tx_len_mismatch_seq_c)

  // Caller-configurable fields ------------------------------------------------
  int        payload_length    = 46;        // actual payload bytes to send
  bit [15:0] ether_type_val    = 16'h0800;  // EtherType on the wire (may mismatch)
  bit        insert_fcs        = 1'b1;      // 1 = client FCS, 0 = DUT generates
  bit [47:0] dst_addr          = 48'hFF_FF_FF_FF_FF_FF;
  bit [47:0] src_addr          = 48'h02_00_00_00_00_01;
  mac_hvl_utils_c::payload_pattern_e pattern = mac_hvl_utils_c::PAYLOAD_INCREMENTING;

  extern function new(string name = "axi_tx_len_mismatch_seq_c");
  extern task body();
endclass

function axi_tx_len_mismatch_seq_c::new(string name = "axi_tx_len_mismatch_seq_c");
  super.new(name);
endfunction

task axi_tx_len_mismatch_seq_c::body();
  axi_item_c item;
  bit [31:0] computed_fcs;

  item = axi_item_c::type_id::create("item");

  // Build the payload with the requested pattern and length.
  if (!mac_hvl_utils_c::make_payload(item.payload, payload_length, pattern))
    `uvm_fatal(get_type_name(), $sformatf("make_payload failed for pattern %0d", pattern))

  // Set header fields -- ether_type is independent of payload_length.
  item.dst_addr   = dst_addr;
  item.src_addr   = src_addr;
  item.ether_type = ether_type_val;
  item.insert_fcs = insert_fcs;

  // Clear error flags -- this is a clean (non-corrupted) frame.
  item.crc_error       = 1'b0;
  item.length_error    = 1'b0;
  item.alignment_error = 1'b0;

  // Compute FCS if the client supplies it.
  if (insert_fcs) begin
    computed_fcs = item.compute_fcs();
    item.fcs = computed_fcs;
  end

  do_axi_item(item);
endtask
