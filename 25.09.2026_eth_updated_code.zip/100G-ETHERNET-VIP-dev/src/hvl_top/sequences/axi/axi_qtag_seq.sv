`ifndef AXI_QTAG_SEQ_SV
`define AXI_QTAG_SEQ_SV

// Sends one Q-tagged (IEEE 802.1Q VLAN) AXI TX frame.
// Sets EtherType = 0x8810 and prepends the 4-byte VLAN tag
// (TCI + Inner EtherType) as the first bytes of the payload.
// The caller configures fields before start().
class axi_qtag_seq_c extends axi_sequence_base_c;
  `uvm_object_utils(axi_qtag_seq_c)

  typedef mac_hvl_utils_c::payload_pattern_e payload_pattern_e;

  int unsigned             payload_length     = 1500;
  payload_pattern_e        payload_pattern    = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
  int unsigned             payload_seed       = 32'hc001_cafe;
  bit                      client_fcs_present = 1'b0;
  bit               [31:0] client_fcs         = '0;
  bit               [47:0] dst_addr           = 48'h02_00_00_00_00_01;
  bit               [47:0] src_addr           = 48'h02_00_00_00_00_02;
  bit               [15:0] vlan_tci           = 16'h0001;
  bit               [15:0] inner_ether_type   = 16'h0800;

  extern function new(string name = "axi_qtag_seq_c");
  extern virtual task body();
endclass

function axi_qtag_seq_c::new(string name = "axi_qtag_seq_c");
  super.new(name);
endfunction

task axi_qtag_seq_c::body();
  axi_item_c item;
  int unsigned data_bytes;

  if (payload_length + 4 > MAC_SUPER_JUMBO_PAYLOAD_BYTES)
    `uvm_fatal(get_type_name(), $sformatf(
               "Payload length %0d exceeds the super-jumbo limit", payload_length))

  item                 = axi_item_c::type_id::create("qtag_item");
  item.packet_id       = axi_item_c::next_packet_id++;
  item.dst_addr        = dst_addr;
  item.src_addr        = src_addr;
  item.ether_type      = 16'h8810;
  item.insert_fcs      = client_fcs_present;
  item.crc_error       = 1'b0;
  item.length_error    = 1'b0;
  item.alignment_error = 1'b0;

  data_bytes = payload_length;
  item.payload = new[4 + data_bytes];

  item.payload[0] = vlan_tci[15:8];
  item.payload[1] = vlan_tci[7:0];
  item.payload[2] = inner_ether_type[15:8];
  item.payload[3] = inner_ether_type[7:0];

  begin
    byte unsigned pattern_data[];
    if (!mac_hvl_utils_c::make_payload(pattern_data, data_bytes, payload_pattern, payload_seed))
      `uvm_fatal(get_type_name(), "Unsupported payload pattern")
    for (int i = 0; i < data_bytes; i++)
      item.payload[4 + i] = pattern_data[i];
  end

  item.fcs = client_fcs_present ? client_fcs : '0;

  do_axi_item(item);
endtask

`endif  // AXI_QTAG_SEQ_SV
