/**
 * @brief RS RX sequence with caller-controlled DA, SA, EtherType, payload
 *        pattern, and error injection.
 *
 * Provides fine-grained field-level control for RX frame disassembly
 * and end-to-end delivery tests.  Unlike rs_sequence_c (randomized) and
 * rx_len_custom_frame_seq_c (broadcast DA only), every Ethernet header
 * field and the payload pattern are caller-settable.
 */
class rx_frame_field_seq_c extends rs_sequence_base_c;
  `uvm_object_utils(rx_frame_field_seq_c)

  int                          num_frames_to_send = 1;
  int                          payload_length     = 46;
  bit [47:0]                   dst_addr           = 48'hFF_FF_FF_FF_FF_FF;
  bit [47:0]                   src_addr           = 48'h02_00_00_00_00_01;
  bit [15:0]                   ether_type_val     = 16'h0800;
  bit                          insert_fcs         = 1'b1;
  bit                          crc_error          = 1'b0;
  mac_hvl_utils_c::payload_pattern_e payload_pattern =
      mac_hvl_utils_c::PAYLOAD_INCREMENTING;
  int                          payload_seed       = 0;

  extern function new(string name = "rx_frame_field_seq_c");
  extern task body();
endclass

function rx_frame_field_seq_c::new(string name = "rx_frame_field_seq_c");
  super.new(name);
endfunction

task rx_frame_field_seq_c::body();
  frame_xtn_c frm;

  repeat (num_frames_to_send) begin
    frm = frame_xtn_c::type_id::create("frm");
    start_item(frm);

    if (!mac_hvl_utils_c::make_payload(frm.payload, payload_length,
                                        payload_pattern, payload_seed)) begin
      `uvm_fatal(get_type_name(),
                 $sformatf("make_payload failed for pattern %0d", payload_pattern))
    end

    frm.dst_addr       = dst_addr;
    frm.src_addr       = src_addr;
    frm.ether_type     = ether_type_val;
    frm.insert_fcs     = insert_fcs;
    frm.crc_error      = crc_error;
    frm.length_error   = 1'b0;
    frm.alignment_error = 1'b0;
    frm.preamble       = 56'h55_5555_5555_5555;
    frm.sfd            = 8'hD5;
    frm.preamble_len   = 7;
    frm.sfd_present    = 1;

    if (insert_fcs) frm.fcs = frm.compute_fcs();
    else            frm.fcs = '0;

    if (crc_error) frm.fcs = frm.fcs ^ 32'h0000_0001;

    finish_item(frm);
  end
endtask
