/**
 * @brief RS RX sequence that injects a single CRC-corrupted frame.
 *
 * Constructs a clean frame, computes the correct FCS, then XORs
 * the FCS with a mask to produce a deterministic CRC error at the DUT.
 * The frame's crc_error flag is set for scoreboard/monitor annotation.
 */
class rx_emit_error_frame_seq_c extends rs_sequence_base_c;
  `uvm_object_utils(rx_emit_error_frame_seq_c)

  extern function new(string name = "rx_emit_error_frame_seq_c");
  extern task body();
endclass

function rx_emit_error_frame_seq_c::new(string name = "rx_emit_error_frame_seq_c");
  super.new(name);
endfunction

task rx_emit_error_frame_seq_c::body();
  frame_xtn_c frm;
  frm = frame_xtn_c::type_id::create("frm");
  start_item(frm);
  if (!frm.randomize() with {
        preamble_len    == 7;
        sfd_present     == 1;
        preamble        == 56'h55_5555_5555_5555;
        sfd             == 8'hD5;
        dst_addr        == 48'hFF_FF_FF_FF_FF_FF;
        crc_error       == 1;
        length_error    == 0;
        alignment_error == 0;
        insert_fcs      == 1;
        payload.size()  == 64;
      }) begin
    `uvm_fatal(get_type_name(), "frame randomization failed")
  end
  frm.fcs = frm.compute_fcs() ^ 32'h0000_0001;
  finish_item(frm);
endtask
