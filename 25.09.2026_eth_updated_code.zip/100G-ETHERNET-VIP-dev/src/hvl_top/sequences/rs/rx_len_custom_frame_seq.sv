/**
 * @brief RS RX sequence with caller-controlled EtherType and payload size.
 *
 * Minimal extension of rs_sequence_base_c that lets the test set an
 * arbitrary ether_type (including length-encoded values <= 1500 which
 * send_clean_frame() cannot produce) and a fixed payload size.
 *
 * Used by FF-002 (RX_LEN_001) for declared-length and reserved
 * Length/Type validation scenarios.
 */
class rx_len_custom_frame_seq_c extends rs_sequence_base_c;
  `uvm_object_utils(rx_len_custom_frame_seq_c)

  int        payload_len    = 46;
  bit [15:0] ether_type_val = 16'h0800;

  extern function new(string name = "rx_len_custom_frame_seq_c");
  extern task body();
endclass

function rx_len_custom_frame_seq_c::new(string name = "rx_len_custom_frame_seq_c");
  super.new(name);
endfunction

task rx_len_custom_frame_seq_c::body();
  frame_xtn_c frm;
  frm = frame_xtn_c::type_id::create("frm");
  start_item(frm);
  if (!frm.randomize() with {
        preamble_len    == 7;
        sfd_present     == 1;
        preamble        == 56'h55_5555_5555_5555;
        sfd             == 8'hD5;
        dst_addr        == 48'hFF_FF_FF_FF_FF_FF;
        crc_error       == 0;
        length_error    == 0;
        alignment_error == 0;
        insert_fcs      == 1;
        ether_type      == ether_type_val;
        payload.size()  == payload_len;
      }) begin
    `uvm_fatal(get_type_name(), "frame randomization failed")
  end
  finish_item(frm);
endtask
