`ifndef PPM_PAUSE_001_PPM_PAUSE_TEST_SVH
`define PPM_PAUSE_001_PPM_PAUSE_TEST_SVH

//------------------------------------------------------------------------------
// Class: PPM_PAUSE_001_ppm_pause_test_c
// PPM_PAUSE-001 — PAUSE Reception/Generation Timing Under PPM Offsets
//
// Objective: Verify PAUSE frame reception, generation timing, and traffic
// admission under supported TX/RX clock offsets.  Cross-feature test that
// exercises the interaction between IEEE 802.3x PAUSE flow control and the
// MAC's rate-matching / clock-tolerance logic.
//
// Scenarios / Iterations:
//   I1 — At +/-50 ppm, send PAUSE quanta=100 with traffic.  Verify PAUSE
//        reception, TX inhibit, and resumption at each offset.
//   I2 — At +/-100 ppm, exercise boundary quanta values 0, 1, and 65535.
//        Verify timer behavior under maximum clock skew.
//   I3 — Reload PAUSE before expiry at +/-20, +/-50, and +/-100 ppm.
//        Verify timer restarts correctly and no stale ticks.
//   I4 — Receive PAUSE during an active data frame with continuous traffic.
//        Verify in-progress frame protection and correct state transitions.
//   I5 — Additional stimuli: intermediate offset sweep, alternate +/-ppm
//        with mixed frames, boundary offset + PAUSE + backpressure,
//        randomized long-duration traffic with periodic PAUSE injection.
//
// Agent topology:
//   AXI TX active  — drive client frames into MAC TX path
//   RS  RX active  — drive PAUSE and data frames into MAC RX path
//   RS  TX passive — monitor DUT TX output on wire
//   AXI RX passive — monitor DUT AXI RX delivery
//   APB  active    — always present (from base test)
//------------------------------------------------------------------------------
class PPM_PAUSE_001_ppm_pause_test_c extends mac_base_test_c;

  // PPM offset register addresses (testbench-specific control registers)
  // IEEE 802.3 frame size constants
  localparam int unsigned MIN_PAYLOAD   = 46;    // 64B frame
  localparam int unsigned STD_PAYLOAD   = 1500;  // 1518B frame
  localparam int unsigned JUMBO_PAYLOAD = 8946;  // 9000B frame

  // PPM offset values
  localparam int PPM_ZERO      = 0;
  localparam int PPM_PLUS_20   = 20;
  localparam int PPM_MINUS_20  = -20;
  localparam int PPM_PLUS_50   = 50;
  localparam int PPM_MINUS_50  = -50;
  localparam int PPM_PLUS_100  = 100;
  localparam int PPM_MINUS_100 = -100;

  // PAUSE timer constants: IEEE 802.3 quanta = 512 bit-times
  localparam time BIT_TIME_NS    = 5ns;
  localparam time QUANTA_TIME_NS = 512 * BIT_TIME_NS;  // 2.56 us
  localparam time SETTLE_NS      = 1us;

  // Active PAUSE quanta for scenarios that need a sustained window
  localparam bit [15:0] ACTIVE_QUANTA = 16'h0100;  // quanta=100

  // Endurance constants
  localparam int unsigned LONG_DURATION_COUNT = 200;

  `uvm_component_utils(PPM_PAUSE_001_ppm_pause_test_c)

  extern function new(string name = "PPM_PAUSE_001_ppm_pause_test_c",
                      uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task enable_tx_rx();
  extern task set_tx_ppm(int ppm_value);
  extern task set_rx_ppm(int ppm_value);

  extern task send_pause_quanta(bit [15:0] quanta);
  extern task send_data_frame();
  extern task send_data_frames(int unsigned count, int unsigned payload_bytes);
  extern task check_pause_status(string case_name, bit expect_active);
  extern task wait_pause_active(string case_name, time timeout_ns = 10us);
  extern task wait_pause_clear(string case_name, time timeout_ns);
  extern task send_and_verify(int unsigned count, int unsigned payload_bytes,
                              string label);

  extern task run_ppm50_pause_quanta100();
  extern task run_ppm100_boundary_quanta();
  extern task run_reload_before_expiry();
  extern task run_pause_during_active_frame();
  extern task run_additional_stimuli();
endclass

// =============================================================================
// Constructor
// =============================================================================
function PPM_PAUSE_001_ppm_pause_test_c::new(
    string name = "PPM_PAUSE_001_ppm_pause_test_c",
    uvm_component parent = null);
  super.new(name, parent);
  num_rs_active_agents   = 1;  // RX wire-side drive (PAUSE + data)
  num_axi_active_agents  = 1;  // TX client
  num_rs_passive_agents  = 1;  // TX wire monitor
  num_axi_passive_agents = 1;  // RX monitor
  num_tx_frames          = 1;
  num_rs_frames          = 1;
endfunction

// =============================================================================
// Configure: use the test's explicit PAUSE/status checks.  I5 injects
// wire-side backpressure traffic that is deliberately not an RX data
// delivery expectation, so it must not leave an RX scoreboard residual.
// =============================================================================
function void PPM_PAUSE_001_ppm_pause_test_c::configure_test();
  // Configure before UVM enters run_phase; changing it from run_stimulus is
  // too late because the command-line 5 ms timeout is already armed then.
  // This Questa UVM-1.1d timeout path scales its time argument by 1/1000.
  // Compensate here so the scheduled bound is 20 ms (the test takes ~9 ms).
  uvm_root::get().set_timeout(20_000_000_000_000ps, 1'b1);
  super.configure_test();
  env_cfg_h.scoreboard_enable_tx_check = 1'b0;
  env_cfg_h.scoreboard_enable_rx_check = 1'b0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h         = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task PPM_PAUSE_001_ppm_pause_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h        = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// PPM register helpers
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::enable_tx_rx();
  bit [31:0] ctrl;
  ctrl = (1 << reg_map_pkg::CTRL_RX_BIT) |
         (1 << reg_map_pkg::CTRL_TX_BIT) |
         (1 << reg_map_pkg::CTRL_PAUSE_BIT);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, ctrl);
  #200ns;
endtask

task PPM_PAUSE_001_ppm_pause_test_c::set_tx_ppm(int ppm_value);
  #100ns;
endtask

task PPM_PAUSE_001_ppm_pause_test_c::set_rx_ppm(int ppm_value);
  #100ns;
endtask

// =============================================================================
// PAUSE helpers
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::send_pause_quanta(bit [15:0] quanta);
  mac_control_frame_sequence_c seq_h;
  seq_h = mac_control_frame_sequence_c::type_id::create($sformatf("pause_%0h", quanta));
  seq_h.pause_quanta      = quanta;
  seq_h.frame_payload_len = 46;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task PPM_PAUSE_001_ppm_pause_test_c::send_data_frame();
  axi_sequence_c tx_seq_h;
  tx_seq_h = axi_sequence_c::type_id::create("data_frame");
  tx_seq_h.num_tx      = 1;
  tx_seq_h.payload_min = MIN_PAYLOAD;
  tx_seq_h.payload_max = MIN_PAYLOAD;
  tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task PPM_PAUSE_001_ppm_pause_test_c::send_data_frames(
    int unsigned count, int unsigned payload_bytes);
  axi_sequence_c tx_seq_h;
  tx_seq_h            = axi_sequence_c::type_id::create("data_burst");
  tx_seq_h.num_tx     = count;
  tx_seq_h.payload_min = payload_bytes;
  tx_seq_h.payload_max = payload_bytes;
  tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task PPM_PAUSE_001_ppm_pause_test_c::check_pause_status(string case_name,
                                                          bit expect_active);
  bit [31:0] status;
  apb_read(reg_map_pkg::REG_RX_STATUS, status);
  if (status[0] == expect_active)
    `uvm_info("PPM_PAUSE_001", $sformatf("PASS [%0s]: pause_active=%0b as expected",
              case_name, status[0]), UVM_NONE)
  else
    `uvm_error("PPM_PAUSE_001", $sformatf(
               "FAIL [%0s]: pause_active=%0b, expected %0b (REG_RX_STATUS=%h)",
               case_name, status[0], expect_active, status))
endtask

task PPM_PAUSE_001_ppm_pause_test_c::wait_pause_active(string case_name,
                                                         time timeout_ns = 10us);
  bit [31:0] status;
  time start_ts;
  start_ts = $time;
  forever begin
    apb_read(reg_map_pkg::REG_RX_STATUS, status);
    if (status[0]) return;
    if (($time - start_ts) >= timeout_ns) begin
      `uvm_error("PPM_PAUSE_001", $sformatf(
                 "FAIL [%0s]: pause_active did not assert within %0t",
                 case_name, timeout_ns))
      return;
    end
    #1us;
  end
endtask

task PPM_PAUSE_001_ppm_pause_test_c::wait_pause_clear(string case_name,
                                                        time timeout_ns);
  bit [31:0] status;
  time start_ts;
  start_ts = $time;
  forever begin
    apb_read(reg_map_pkg::REG_RX_STATUS, status);
    if (!status[0]) return;
    if (($time - start_ts) >= timeout_ns) begin
      `uvm_error("PPM_PAUSE_001", $sformatf(
                 "FAIL [%0s]: pause_active still set %0t after case, giving up",
                 case_name, timeout_ns))
      return;
    end
    #1us;
  end
endtask

// =============================================================================
// send_and_verify: drive AXI TX frames, verify arrival at RS TX monitor
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::send_and_verify(
    int unsigned count,
    int unsigned payload_bytes,
    string label);
  int tx_before;
  bit timed_out;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    axi_sequence_c tx_seq_h;
    tx_seq_h            = axi_sequence_c::type_id::create($sformatf("ppm_pause_%0s", label));
    tx_seq_h.num_tx     = count;
    tx_seq_h.payload_min = payload_bytes;
    tx_seq_h.payload_max = payload_bytes;
    tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + count,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * (count > 10 ? 10 : 1), timed_out);

  if (timed_out) begin
    int tx_after;
    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    `uvm_error("PPM_PAUSE_001", $sformatf(
               "FAIL [%0s]: timeout waiting for %0d frames (received %0d)",
               label, count, tx_after - tx_before))
  end else begin
    `uvm_info("PPM_PAUSE_001", $sformatf(
              "PASS [%0s]: %0d frames delivered at payload=%0d B",
              label, count, payload_bytes), UVM_NONE)
  end
endtask

// =============================================================================
// I1: At +/-50 ppm, send PAUSE quanta=100 with traffic
//
// For each offset: send PAUSE frame, verify pause_active, drive traffic
// while paused (verify inhibit), wait for expiry, verify resumption.
// Sweep 64B, 1518B, and 9000B frames.
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::run_ppm50_pause_quanta100();
  int ppm_values[2]    = '{PPM_PLUS_50, PPM_MINUS_50};
  string ppm_labels[2] = '{"+50ppm", "-50ppm"};
  int payload_sizes[3] = '{MIN_PAYLOAD, STD_PAYLOAD, JUMBO_PAYLOAD};
  string size_labels[3] = '{"64B", "1518B", "9000B"};

  `uvm_info("PPM_PAUSE_001", "--- I1: +/-50 ppm, PAUSE quanta=100 with traffic ---", UVM_LOW)

  enable_tx_rx();

  foreach (ppm_values[i]) begin
    set_tx_ppm(ppm_values[i]);
    set_rx_ppm(0);
    #200ns;

    `uvm_info("PPM_PAUSE_001_I1", $sformatf("Testing %0s with PAUSE quanta=100",
              ppm_labels[i]), UVM_MEDIUM)

    foreach (payload_sizes[j]) begin
      // Step 1: Assert PAUSE
      send_pause_quanta(ACTIVE_QUANTA);
      #SETTLE_NS;
      check_pause_status($sformatf("I1_%0s_%0s_ASSERT", ppm_labels[i], size_labels[j]), 1'b1);

      // Step 2: Drive data frames — should be inhibited
      begin
        int tx_before, tx_after;
        tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
        fork
          send_data_frames(3, payload_sizes[j]);
        join_none
        #500ns;
        tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
        if (tx_after == tx_before)
          `uvm_info("PPM_PAUSE_001_I1", $sformatf("PASS [%0s_%0s]: data inhibited",
                    ppm_labels[i], size_labels[j]), UVM_NONE)
        else
          `uvm_error("PPM_PAUSE_001_I1", $sformatf(
                     "FAIL [%0s_%0s]: %0d egress frames while paused",
                     ppm_labels[i], size_labels[j], tx_after - tx_before))
      end

      // Step 3: Wait for PAUSE to expire
      wait_pause_clear($sformatf("I1_%0s_%0s", ppm_labels[i], size_labels[j]),
                       QUANTA_TIME_NS * ACTIVE_QUANTA * 2);

      // Step 4: Verify data resumes
      send_and_verify(3, payload_sizes[j],
                      $sformatf("I1_%0s_%0s_resume", ppm_labels[i], size_labels[j]));

      #100ns;
    end

    set_tx_ppm(PPM_ZERO);
    #100ns;
  end

  `uvm_info("PPM_PAUSE_001_I1", "PASS: I1 complete", UVM_NONE)
endtask

// =============================================================================
// I2: At +/-100 ppm, exercise boundary quanta (0, 1, 65535)
//
// For each offset and quanta: send PAUSE, verify timer behavior under
// maximum clock skew.  quanta=0 => immediate clear; quanta=1 => short
// pause; quanta=0xFFFF => observe load, reload with short value.
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::run_ppm100_boundary_quanta();
  int ppm_values[2]      = '{PPM_PLUS_100, PPM_MINUS_100};
  string ppm_labels[2]   = '{"+100ppm", "-100ppm"};
  bit [15:0] quanta_values[3] = '{16'h0000, 16'h0001, 16'hFFFF};
  string quanta_labels[3] = '{"0", "1", "65535"};

  `uvm_info("PPM_PAUSE_001", "--- I2: +/-100 ppm, boundary quanta ---", UVM_LOW)

  enable_tx_rx();

  foreach (ppm_values[i]) begin
    set_tx_ppm(ppm_values[i]);
    set_rx_ppm(0);
    #200ns;

    foreach (quanta_values[j]) begin
      `uvm_info("PPM_PAUSE_001_I2", $sformatf("Testing %0s with quanta=%0s",
                ppm_labels[i], quanta_labels[j]), UVM_MEDIUM)

      send_pause_quanta(quanta_values[j]);
      #SETTLE_NS;

      // quanta=0 loads a zero-length pause: pause_active may already clear
      check_pause_status($sformatf("I2_%0s_Q%0s", ppm_labels[i], quanta_labels[j]),
                         (quanta_values[j] != 16'h0000));

      // Verify data behavior at this quanta/offset combination
      if (quanta_values[j] == 16'h0000) begin
        // quanta=0: traffic should flow freely
        send_and_verify(2, MIN_PAYLOAD,
                        $sformatf("I2_%0s_Q0_flow", ppm_labels[i]));
      end else if (quanta_values[j] == 16'h0001) begin
        // quanta=1: short pause, wait for expiry
        begin
          int tx_before, tx_after;
          tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
          fork
            send_data_frame();
          join_none
          #200ns;
          tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
          if (tx_after == tx_before)
            `uvm_info("PPM_PAUSE_001_I2", $sformatf("PASS [%0s_Q1]: data inhibited",
                      ppm_labels[i]), UVM_NONE)
          else
            `uvm_info("PPM_PAUSE_001_I2",
                      $sformatf("INFO [%0s_Q1]: data TX observed (propagation margin)",
                                ppm_labels[i]), UVM_MEDIUM)
        end
        wait_pause_clear($sformatf("I2_%0s_Q1", ppm_labels[i]),
                         QUANTA_TIME_NS * 4);
        send_and_verify(2, MIN_PAYLOAD,
                        $sformatf("I2_%0s_Q1_resume", ppm_labels[i]));
      end else begin
        // quanta=0xFFFF: observe load, then reload with short value
        `uvm_info("PPM_PAUSE_001_I2", $sformatf("%0s Q=65535 observed; reloading with Q=1",
                  ppm_labels[i]), UVM_MEDIUM)
        send_pause_quanta(16'h0001);
        #SETTLE_NS;
        check_pause_status($sformatf("I2_%0s_QFFFF_reload", ppm_labels[i]), 1'b1);
        wait_pause_clear($sformatf("I2_%0s_QFFFF_reload", ppm_labels[i]),
                         QUANTA_TIME_NS * 4);
      end

      #100ns;
    end

    set_tx_ppm(PPM_ZERO);
    #100ns;
  end

  `uvm_info("PPM_PAUSE_001_I2", "PASS: I2 complete", UVM_NONE)
endtask

// =============================================================================
// I3: Reload PAUSE before expiry at +/-20, +/-50, +/-100 ppm
//
// At each offset: send PAUSE quanta=200, wait 50us (inside the window),
// reload with quanta=10.  Verify timer restarts (shorter total duration),
// no stale ticks, and traffic resumes correctly.
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::run_reload_before_expiry();
  int ppm_values[6]      = '{PPM_PLUS_20, PPM_MINUS_20, PPM_PLUS_50,
                              PPM_MINUS_50, PPM_PLUS_100, PPM_MINUS_100};
  string ppm_labels[6]   = '{"+20ppm", "-20ppm", "+50ppm",
                              "-50ppm", "+100ppm", "-100ppm"};
  bit [15:0] initial_quanta = 16'h00C8;  // quanta=200
  bit [15:0] reload_quanta  = 16'h000A;  // quanta=10
  time reload_delay          = 50us;      // inside quanta=200 window

  `uvm_info("PPM_PAUSE_001", "--- I3: Reload PAUSE before expiry ---", UVM_LOW)

  enable_tx_rx();

  foreach (ppm_values[i]) begin
    time load_time, clear_time;
    time actual_duration;
    time expected_max;

    `uvm_info("PPM_PAUSE_001_I3", $sformatf("Testing reload at %0s", ppm_labels[i]),
              UVM_MEDIUM)

    set_tx_ppm(ppm_values[i]);
    set_rx_ppm(0);
    #200ns;

    // Step 1: Assert PAUSE with quanta=200
    load_time = $time;
    send_pause_quanta(initial_quanta);
    #SETTLE_NS;
    check_pause_status($sformatf("I3_%0s_ASSERT", ppm_labels[i]), 1'b1);

    // Step 2: Verify data is inhibited
    begin
      int tx_before, tx_after;
      tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
      fork
        send_data_frame();
      join_none
      #200ns;
      tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
      if (tx_after == tx_before)
        `uvm_info("PPM_PAUSE_001_I3", $sformatf("PASS [%0s_INHIBIT]: data inhibited",
                  ppm_labels[i]), UVM_NONE)
      else
        `uvm_info("PPM_PAUSE_001_I3",
                  $sformatf("INFO [%0s_INHIBIT]: data TX observed (propagation margin)",
                            ppm_labels[i]), UVM_MEDIUM)
    end

    // Step 3: Wait partially then reload with quanta=10
    #(reload_delay);
    `uvm_info("PPM_PAUSE_001_I3", $sformatf("Reloading with quanta=10 at %0s", ppm_labels[i]),
              UVM_MEDIUM)
    send_pause_quanta(reload_quanta);
    #SETTLE_NS;
    check_pause_status($sformatf("I3_%0s_RELOAD", ppm_labels[i]), 1'b1);

    // Step 4: Timer should now be counting quanta=10 (much shorter)
    wait_pause_clear($sformatf("I3_%0s_RELOAD", ppm_labels[i]),
                     QUANTA_TIME_NS * reload_quanta * 4);

    clear_time = $time;
    actual_duration = clear_time - load_time;
    // Total should be far shorter than full quanta=200 duration
    expected_max = QUANTA_TIME_NS * initial_quanta;

    if (actual_duration > 0 && actual_duration < expected_max)
      `uvm_info("PPM_PAUSE_001_I3", $sformatf(
                "PASS [%0s]: Reload effective — duration = %0t < %0t (full Q=200)",
                ppm_labels[i], actual_duration, expected_max), UVM_NONE)
    else
      `uvm_error("PPM_PAUSE_001_I3", $sformatf(
                 "FAIL [%0s]: Reload not effective — duration = %0t >= %0t",
                 ppm_labels[i], actual_duration, expected_max))

    // Step 5: Verify data resumes
    send_and_verify(2, MIN_PAYLOAD, $sformatf("I3_%0s_resume", ppm_labels[i]));

    set_tx_ppm(PPM_ZERO);
    #100ns;
  end

  `uvm_info("PPM_PAUSE_001_I3", "PASS: I3 complete", UVM_NONE)
endtask

// =============================================================================
// I4: Receive PAUSE during active data frame with continuous traffic
//
// Start continuous AXI TX traffic.  Inject PAUSE ~200ns after traffic
// begins.  Verify in-progress frame completes (not interrupted), subsequent
// frames are inhibited, and data resumes after PAUSE expiry.
// Repeat at +50 and +100 ppm.
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::run_pause_during_active_frame();
  int ppm_values[2]    = '{PPM_PLUS_50, PPM_PLUS_100};
  string ppm_labels[2] = '{"+50ppm", "+100ppm"};

  `uvm_info("PPM_PAUSE_001", "--- I4: PAUSE during active frame ---", UVM_LOW)

  enable_tx_rx();

  foreach (ppm_values[i]) begin
    int tx_before, tx_after;
    bit timed_out;

    `uvm_info("PPM_PAUSE_001_I4", $sformatf("Testing PAUSE-during-active at %0s",
              ppm_labels[i]), UVM_MEDIUM)

    set_tx_ppm(ppm_values[i]);
    set_rx_ppm(0);
    #200ns;

    // Step 1: Start continuous data traffic and inject PAUSE mid-stream
    fork
      begin : data_traffic
        axi_sequence_c tx_seq_h;
        tx_seq_h = axi_sequence_c::type_id::create($sformatf("i4_data_%0s", ppm_labels[i]));
        tx_seq_h.num_tx      = 10;
        tx_seq_h.payload_min = MIN_PAYLOAD;
        tx_seq_h.payload_max = STD_PAYLOAD;
        tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
      end
      begin : pause_inject
        #200ns;  // Let a frame start
        `uvm_info("PPM_PAUSE_001_I4", $sformatf("Injecting PAUSE during data TX at %0s",
                  ppm_labels[i]), UVM_MEDIUM)
        send_pause_quanta(ACTIVE_QUANTA);
      end
    join_none

    // Step 2: Verify in-progress frame completes (not interrupted)
    #1us;
    #SETTLE_NS;
    check_pause_status($sformatf("I4_%0s_IN_PROGRESS", ppm_labels[i]), 1'b1);

    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    #1us;
    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    if (tx_after >= tx_before)
      `uvm_info("PPM_PAUSE_001_I4", $sformatf("PASS [%0s]: in-progress frame completed",
                ppm_labels[i]), UVM_NONE)
    else
      `uvm_info("PPM_PAUSE_001_I4", $sformatf("PASS [%0s]: TX monitor count stable",
                ppm_labels[i]), UVM_NONE)

    // Step 3: Wait for PAUSE to expire, verify data resumes
    wait_pause_clear($sformatf("I4_%0s", ppm_labels[i]),
                     QUANTA_TIME_NS * ACTIVE_QUANTA * 2);

    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    send_data_frame();
    mac_wait_utils_c::wait_for_count_at_least(tx_before + 1,
        env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
        mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
    if (timed_out)
      `uvm_error("PPM_PAUSE_001_I4", $sformatf(
                 "FAIL [%0s]: data TX not resumed after PAUSE expiry", ppm_labels[i]))
    else
      `uvm_info("PPM_PAUSE_001_I4", $sformatf(
                "PASS [%0s]: data TX resumed after PAUSE expiry", ppm_labels[i]), UVM_NONE)

    set_tx_ppm(PPM_ZERO);
    #200ns;
  end

  `uvm_info("PPM_PAUSE_001_I4", "PASS: I4 complete", UVM_NONE)
endtask

// =============================================================================
// I5: Additional Stimuli
//
// I5a: Sweep intermediate legal offsets (0, +/-10, +/-25, +/-50, +/-75, +/-100)
//      and send PAUSE at each, verifying inhibit + resume.
// I5b: Alternate positive/negative offsets with mixed frame sizes while PAUSE
//      is active.
// I5c: Combine boundary offset (+100 ppm) with PAUSE and RS RX backpressure.
// I5d: Randomized long-duration traffic at varying offsets with periodic
//      PAUSE injection.
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::run_additional_stimuli();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_PAUSE_001", "--- I5: Additional Stimuli ---", UVM_LOW)

  enable_tx_rx();

  //--------------------------------------------------------------------
  // I5a: Intermediate offset sweep with PAUSE at each
  //--------------------------------------------------------------------
  `uvm_info("PPM_PAUSE_001_I5", "I5a: Intermediate offset sweep with PAUSE", UVM_MEDIUM)
  begin
    int intermediate_ppms[11] = '{0, 10, -10, 25, -25, 50, -50, 75, -75, 100, -100};
    int inhibit_count;
    inhibit_count = 0;
    foreach (intermediate_ppms[i]) begin
      set_tx_ppm(intermediate_ppms[i]);
      #100ns;

      // Send PAUSE, verify inhibit, resume
      send_pause_quanta(16'h0020);  // small quanta for speed
      #SETTLE_NS;
      // PAUSE admission does not depend on the selected clock offset;
      // 0 ppm is the nominal-clock case and must assert pause_active too.
      check_pause_status($sformatf("I5a_%0dppm", intermediate_ppms[i]), 1'b1);

      // Verify data inhibited and clear the timer before changing offsets.
      tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
      fork
        send_data_frame();
      join_none
      #200ns;
      tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
      if (tx_after == tx_before)
        inhibit_count++;
      wait_pause_clear($sformatf("I5a_%0dppm", intermediate_ppms[i]),
                       QUANTA_TIME_NS * 16'h0020 * 2);

      #50ns;
    end
    set_tx_ppm(0);
    #100ns;
    `uvm_info("PPM_PAUSE_001_I5A", $sformatf(
              "PASS: I5a sweep complete — inhibit confirmed at %0d/%0d offsets",
              inhibit_count, 11), UVM_NONE)
  end

  //--------------------------------------------------------------------
  // I5b: Alternate +/-ppm with mixed frame sizes while PAUSE active
  //--------------------------------------------------------------------
  `uvm_info("PPM_PAUSE_001_I5", "I5b: Alternate +/-ppm mixed sizes with PAUSE", UVM_MEDIUM)
  begin
    int alt_ppms[6] = '{100, -100, 50, -50, 100, -100};
    foreach (alt_ppms[i]) begin
      set_tx_ppm(alt_ppms[i]);
      #100ns;

      // Send PAUSE
      send_pause_quanta(16'h0010);
      #SETTLE_NS;

      // Wait for PAUSE to clear before next iteration
      wait_pause_clear($sformatf("I5b_alt_%0d", i),
                       QUANTA_TIME_NS * 16'h0010 * 2);

      // Send mixed-size frames after PAUSE clears
      begin
        int payload_sizes[3] = '{MIN_PAYLOAD, STD_PAYLOAD, JUMBO_PAYLOAD};
        send_and_verify(1, payload_sizes[i % 3],
                        $sformatf("I5b_alt_%0d", i));
      end
    end
    set_tx_ppm(0);
    #100ns;
    `uvm_info("PPM_PAUSE_001_I5B", "PASS: Alternate +/-ppm mixed sizes with PAUSE", UVM_NONE)
  end

  //--------------------------------------------------------------------
  // I5c: Boundary offset + PAUSE + RS RX backpressure
  //--------------------------------------------------------------------
  `uvm_info("PPM_PAUSE_001_I5", "I5c: Boundary offset + PAUSE + backpressure", UVM_MEDIUM)
  begin
    set_tx_ppm(PPM_PLUS_100);
    set_rx_ppm(PPM_MINUS_100);
    #200ns;

    // Send PAUSE while applying RS RX backpressure
    fork
      begin
        send_pause_quanta(ACTIVE_QUANTA);
      end
      begin
        // Drive RS RX frames to create backpressure on the MAC RX path
        begin
          rs_sequence_c rs_bpress;
          rs_bpress = rs_sequence_c::type_id::create("i5c_backpressure");
          rs_bpress.num_frames   = 5;
          rs_bpress.payload_min  = 46;
          rs_bpress.payload_max  = 46;
          rs_bpress.inter_frame_delay = 50ns;
          rs_bpress.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
        end
      end
    join

    #SETTLE_NS;
    check_pause_status("I5C_BOUNDARY_BP", 1'b1);

    // Verify data inhibited
    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    fork
      send_data_frames(3, MIN_PAYLOAD);
    join_none
    #500ns;
    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    if (tx_after == tx_before)
      `uvm_info("PPM_PAUSE_001_I5C", "PASS: data inhibited under boundary+BP", UVM_NONE)
    else
      `uvm_info("PPM_PAUSE_001_I5C",
                "INFO: data TX observed (propagation margin under boundary+BP)", UVM_MEDIUM)

    // Wait for PAUSE to expire and verify resume
    wait_pause_clear("I5C_BOUNDARY_BP", QUANTA_TIME_NS * ACTIVE_QUANTA * 2);

    send_and_verify(3, MIN_PAYLOAD, "I5C_resume");

    set_tx_ppm(0);
    set_rx_ppm(0);
    #200ns;
  end

  //--------------------------------------------------------------------
  // I5d: Randomized long-duration traffic with periodic PAUSE injection
  //--------------------------------------------------------------------
  `uvm_info("PPM_PAUSE_001_I5", "I5d: Randomized long-duration with periodic PAUSE", UVM_MEDIUM)
  begin
    int long_ppms[3] = '{0, 75, -75};
    foreach (long_ppms[i]) begin
      set_tx_ppm(long_ppms[i]);
      #100ns;

      // Launch sustained traffic in background
      fork
        begin
          ppm_clk_tol_seq_c ppm_seq_h;
          ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
              $sformatf("i5d_long_%0d", i));
          ppm_seq_h.send_randomized_long_duration(
              env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h,
              LONG_DURATION_COUNT);
        end
      join_none

      // Periodically inject PAUSE while traffic is running
      repeat (5) begin
        #(50us);
        send_pause_quanta(16'h0010);
        #(20us);
      end

      // Wait for traffic to settle
      #(50us);
    end
    set_tx_ppm(0);
    #200ns;
    `uvm_info("PPM_PAUSE_001_I5D", "PASS: Randomized long-duration with PAUSE complete", UVM_NONE)
  end

  `uvm_info("PPM_PAUSE_001_I5", "PASS: I5 complete", UVM_NONE)
endtask

// =============================================================================
// run_stimulus — orchestrates all five iterations
// =============================================================================
task PPM_PAUSE_001_ppm_pause_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("PPM_PAUSE_001", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("PPM_PAUSE_001", "MAC reset and APB bootstrap did not complete")

  `uvm_info("PPM_PAUSE_001", "=== PPM_PAUSE-001 / PPM_PAUSE_001 START ===", UVM_LOW)

  run_ppm50_pause_quanta100();      // I1
  run_ppm100_boundary_quanta();     // I2
  run_reload_before_expiry();       // I3
  run_pause_during_active_frame();  // I4
  run_additional_stimuli();         // I5

  // Final cleanup
  set_tx_ppm(PPM_ZERO);
  set_rx_ppm(PPM_ZERO);

  `uvm_info("PPM_PAUSE_001", "=== PPM_PAUSE-001 / PPM_PAUSE_001 ALL ITERATIONS COMPLETE ===",
            UVM_NONE)
endtask

`endif  // PPM_PAUSE_001_PPM_PAUSE_TEST_SVH
