`ifndef FF_002_RX_LEN_TEST_SVH
`define FF_002_RX_LEN_TEST_SVH

//------------------------------------------------------------------------------
// FF-002 -- RX_LEN_001 -- RX Length, Length/Type, and Alignment Validation
//
// Objective: Verify configured minimum/maximum length enforcement,
// declared-length consistency, reserved Length/Type handling, and
// malformed-frame rejection.
//
// Iterations:
//   I1  -- Size boundary sweep (payloads 46/47/64/1500/1501B, default limits)
//   I2  -- Dynamic max: APB write REG_MAX_FRAME_SIZE=1000, test 982/983/1500B
//   I3  -- Declared-length N=100: ether_type=100, payloads 46/100/101B
//   I4  -- Declared-length N=1500: ether_type=1500, payloads 1499/1500B
//   I5  -- Reserved Length/Type sweep: 1500/1501/1518/1535/1536
//   I6  -- Field patterns: ether_type 0x0000/0xFFFF/0xAAAA/0x5555/0x0001
//   I7  -- Interleaved boundaries: alternate valid/oversize
//   I8  -- Backpressure + errors: 4 oversize frames
//   I9  -- Mixed stream: 9 frames mixing all conditions
//
// Agent topology:
//   RS  RX active  -- drive frames into the MAC RX path
//   RS  TX passive -- monitor DUT-generated frames on TX wire
//   AXI RX passive -- monitor data delivery to client
//   APB  active    -- always present (from base test)
//------------------------------------------------------------------------------
class FF_002_rx_len_test_c extends mac_base_test_c;
  `uvm_component_utils(FF_002_rx_len_test_c)

  extern function new(string name = "FF_002_rx_len_test_c",
                       uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task send_rx_frame(int payload_bytes);
  extern task send_rx_custom_frame(int payload_bytes, bit [15:0] ether_type_v);
  extern task iteration_i1_size_sweep();
  extern task iteration_i2_dynamic_max();
  extern task iteration_i3_declared_len_46();
  extern task iteration_i4_declared_len_1500();
  extern task iteration_i5_reserved_lt();
  extern task iteration_i6_field_patterns();
  extern task iteration_i7_interleaved();
  extern task iteration_i8_backpressure_errors();
  extern task iteration_i9_mixed();
endclass

function FF_002_rx_len_test_c::new(string name = "FF_002_rx_len_test_c",
                                   uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 0;
  num_axi_passive_agents = 1;
  num_rs_active_agents   = 1;
  num_rs_passive_agents  = 1;
endfunction

function void FF_002_rx_len_test_c::configure_test();
  super.configure_test();
  env_cfg_h.max_payload_bytes = 1500;
  env_cfg_h.max_frame_octets  = 1518;
  env_cfg_h.scoreboard_enable_rx_check = 0;
  env_cfg_h.scoreboard_enable_tx_check = 0;
  env_cfg_h.scoreboard_check_error_flags = 0;
  env_cfg_h.has_protocol_checkers = 0;
endfunction

task FF_002_rx_len_test_c::apb_write(input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                                      input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task FF_002_rx_len_test_c::apb_read(input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                                     output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// Helpers
// =============================================================================
task FF_002_rx_len_test_c::send_rx_frame(int payload_bytes);
  // This test specifies frame-size boundaries including the four FCS octets.
  // rs_sequence_c leaves insert_fcs randomized, which can turn a nominal
  // 47-byte payload into a 61-byte undersize frame.  Use the deterministic
  // custom sequence here so each size has the intended on-wire length.
  rx_len_custom_frame_seq_c seq_h;
  seq_h = rx_len_custom_frame_seq_c::type_id::create("clean_drv");
  seq_h.payload_len    = payload_bytes;
  seq_h.ether_type_val = 16'h0800;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_002_rx_len_test_c::send_rx_custom_frame(int payload_bytes, bit [15:0] ether_type_v);
  rx_len_custom_frame_seq_c seq_h;
  seq_h = rx_len_custom_frame_seq_c::type_id::create("custom_drv");
  seq_h.payload_len    = payload_bytes;
  seq_h.ether_type_val = ether_type_v;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// =============================================================================
// I1 -- Size boundary sweep (default limits: min=64, max=1518)
//   Payloads: 46B(total=64), 47B(65), 64B(82), 1500B(1518), 1501B(1519)
//   Expected: 4 accepted, 1 rejected (oversize)
// =============================================================================
task FF_002_rx_len_test_c::iteration_i1_size_sweep();
  int axi_before;
  int axi_after;
  bit timed_out;

  `uvm_info("FF_002", "--- I1: Size boundary sweep ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_frame(46);     // total=64, min valid -> ACCEPT
  send_rx_frame(47);     // total=65, valid -> ACCEPT
  send_rx_frame(64);     // total=82, valid -> ACCEPT
  send_rx_frame(1500);   // total=1518, max valid -> ACCEPT
  send_rx_frame(1501);   // total=1519, oversize -> REJECT
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 4,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out)
    `uvm_error("FF_002_I1", $sformatf("FAIL: timed out (expected 4, got %0d)", axi_after - axi_before))
  else if (axi_after - axi_before != 4)
    `uvm_error("FF_002_I1", $sformatf("FAIL: expected 4 accepts, got %0d", axi_after - axi_before))
  else
    `uvm_info("FF_002_I1", $sformatf("PASS: %0d/5 frames accepted as expected", axi_after - axi_before), UVM_NONE)
endtask

// =============================================================================
// I2 -- Dynamic max_frame_size=1000
//   total = 14 + payload + 4 = payload + 18
//   982B payload -> total=1000 -> ACCEPT
//   983B payload -> total=1001 -> REJECT
//   1500B payload -> total=1518 -> REJECT
// =============================================================================
task FF_002_rx_len_test_c::iteration_i2_dynamic_max();
  int axi_before;
  int axi_after;
  bit timed_out;

  `uvm_info("FF_002", "--- I2: Dynamic max_frame_size ---", UVM_LOW)

  apb_write(16'h0044, 32'd1000);
  #1us;

  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_frame(982);    // total=1000 <= 1000 -> ACCEPT
  send_rx_frame(983);    // total=1001 > 1000 -> REJECT
  send_rx_frame(1500);   // total=1518 > 1000 -> REJECT
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  apb_write(16'h0044, 32'd1518);
  #1us;

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out)
    `uvm_error("FF_002_I2", $sformatf("FAIL: timed out (expected 1, got %0d)", axi_after - axi_before))
  else if (axi_after - axi_before != 1)
    `uvm_error("FF_002_I2", $sformatf("FAIL: expected 1 accept, got %0d", axi_after - axi_before))
  else
    `uvm_info("FF_002_I2", "PASS: 1/3 frames accepted with max=1000", UVM_NONE)
endtask

// =============================================================================
// I3 -- Declared-length N=100
//   ether_type=100 (length-encoded), payloads 46/100/101
//   Expected: 46 rejected (invalid_length), 100 accepted, 101 accepted
// =============================================================================
task FF_002_rx_len_test_c::iteration_i3_declared_len_46();
  int axi_before;
  int axi_after;
  bit timed_out;

  `uvm_info("FF_002", "--- I3: Declared-length N=100 ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_custom_frame(46,  16'd100);  // 46 < 100 -> REJECT
  send_rx_custom_frame(100, 16'd100);  // 100 >= 100 -> ACCEPT
  send_rx_custom_frame(101, 16'd100);  // 101 >= 100 -> ACCEPT
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 2,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out)
    `uvm_error("FF_002_I3", $sformatf("FAIL: timed out (expected 2, got %0d)", axi_after - axi_before))
  else if (axi_after - axi_before != 2)
    `uvm_error("FF_002_I3", $sformatf("FAIL: expected 2 accepts, got %0d", axi_after - axi_before))
  else
    `uvm_info("FF_002_I3", "PASS: 2/3 frames accepted for N=100", UVM_NONE)
endtask

// =============================================================================
// I4 -- Declared-length N=1500
//   ether_type=1500 (length-encoded), payloads 1499/1500
//   Expected: 1499 rejected (invalid_length), 1500 accepted
// =============================================================================
task FF_002_rx_len_test_c::iteration_i4_declared_len_1500();
  int axi_before;
  int axi_after;
  bit timed_out;

  `uvm_info("FF_002", "--- I4: Declared-length N=1500 ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_custom_frame(1499, 16'd1500);  // 1499 < 1500 -> REJECT
  send_rx_custom_frame(1500, 16'd1500);  // 1500 >= 1500 -> ACCEPT
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out)
    `uvm_error("FF_002_I4", $sformatf("FAIL: timed out (expected 1, got %0d)", axi_after - axi_before))
  else if (axi_after - axi_before != 1)
    `uvm_error("FF_002_I4", $sformatf("FAIL: expected 1 accept, got %0d", axi_after - axi_before))
  else
    `uvm_info("FF_002_I4", "PASS: 1/2 frames accepted for N=1500", UVM_NONE)
endtask

// =============================================================================
// I5 -- Reserved Length/Type sweep
//   1500 (length, 46<1500 -> REJECT), 1501-1535 (reserved, REJECT), 1536 (type, ACCEPT)
//   Expected: 1 accepted
// =============================================================================
task FF_002_rx_len_test_c::iteration_i5_reserved_lt();
  int axi_before;
  int axi_after;
  bit timed_out;

  `uvm_info("FF_002", "--- I5: Reserved Length/Type sweep ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_custom_frame(46, 16'd1500);   // length, ACCEPT
  send_rx_custom_frame(46, 16'd1501);   // reserved, REJECT
  send_rx_custom_frame(46, 16'd1518);   // reserved, REJECT
  send_rx_custom_frame(46, 16'd1535);   // reserved, REJECT
  send_rx_custom_frame(46, 16'd1536);   // type, ACCEPT
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out)
    `uvm_error("FF_002_I5", $sformatf("FAIL: timed out (expected 1, got %0d)", axi_after - axi_before))
  else if (axi_after - axi_before != 1)
    `uvm_error("FF_002_I5", $sformatf("FAIL: expected 1 accepts, got %0d", axi_after - axi_before))
  else
    `uvm_info("FF_002_I5", "PASS: 1/5 frames accepted for L/T sweep", UVM_NONE)
endtask

// =============================================================================
// I6 -- Field patterns
//   0x0000 (len=0, payload=46>=0 -> ACCEPT), 0xFFFF (type -> ACCEPT),
//   0xAAAA (type -> ACCEPT), 0x5555 (type -> ACCEPT), 0x0001 (len=1, 46>=1 -> ACCEPT)
//   Expected: all 5 accepted
// =============================================================================
task FF_002_rx_len_test_c::iteration_i6_field_patterns();
  int axi_before;
  int axi_after;
  bit timed_out;

  `uvm_info("FF_002", "--- I6: Field patterns ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_custom_frame(46, 16'h0000);
  send_rx_custom_frame(46, 16'hFFFF);
  send_rx_custom_frame(46, 16'hAAAA);
  send_rx_custom_frame(46, 16'h5555);
  send_rx_custom_frame(46, 16'h0001);
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 5,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out)
    `uvm_error("FF_002_I6", $sformatf("FAIL: timed out (expected 5, got %0d)", axi_after - axi_before))
  else if (axi_after - axi_before != 5)
    `uvm_error("FF_002_I6", $sformatf("FAIL: expected 5 accepts, got %0d", axi_after - axi_before))
  else
    `uvm_info("FF_002_I6", "PASS: 5/5 field-pattern frames accepted", UVM_NONE)
endtask

// =============================================================================
// I7 -- Interleaved boundaries
//   Alternate: valid(46B), oversize(1501B) x3 cycles
//   Expected: 3 accepted, 3 rejected
// =============================================================================
task FF_002_rx_len_test_c::iteration_i7_interleaved();
  int axi_before;
  int axi_after;
  bit timed_out;

  `uvm_info("FF_002", "--- I7: Interleaved boundaries ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_frame(46);     // ACCEPT
  send_rx_frame(1501);   // REJECT
  send_rx_frame(64);     // ACCEPT
  send_rx_frame(1501);   // REJECT
  send_rx_frame(1500);   // ACCEPT
  send_rx_frame(1501);   // REJECT
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 3,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out)
    `uvm_error("FF_002_I7", $sformatf("FAIL: timed out (expected 3, got %0d)", axi_after - axi_before))
  else if (axi_after - axi_before != 3)
    `uvm_error("FF_002_I7", $sformatf("FAIL: expected 3 accepts, got %0d", axi_after - axi_before))
  else
    `uvm_info("FF_002_I7", $sformatf("PASS: %0d/6 interleaved frames accepted", axi_after - axi_before), UVM_NONE)
endtask

// =============================================================================
// I8 -- Backpressure + errors (oversize frames)
//   4 oversize frames (1501B payload). All rejected.
// =============================================================================
task FF_002_rx_len_test_c::iteration_i8_backpressure_errors();
  int axi_before;
  int axi_after;

  `uvm_info("FF_002", "--- I8: Backpressure + errors ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_frame(1501);
  send_rx_frame(1501);
  send_rx_frame(1501);
  send_rx_frame(1501);
  #2us;

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (axi_after == axi_before)
    `uvm_info("FF_002_I8", "PASS: 0/4 oversize frames accepted (all dropped)", UVM_NONE)
  else
    `uvm_error("FF_002_I8", $sformatf("FAIL: expected 0 accepts, got %0d", axi_after - axi_before))
endtask

// =============================================================================
// I9 -- Mixed stream
//   9 frames: valid, oversize, invalid_length, reserved L/T, valid, valid,
//             valid, oversize, valid
//   Expected: 5 accepted (DUT delivers 5 of 9)
// =============================================================================
task FF_002_rx_len_test_c::iteration_i9_mixed();
  int axi_before;
  int axi_after;
  bit timed_out;

  `uvm_info("FF_002", "--- I9: Mixed stream ---", UVM_LOW)
  #5us;
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_frame(46);                    // valid -> ACCEPT
  send_rx_frame(1501);                  // oversize -> REJECT
  send_rx_custom_frame(46, 16'd100);    // invalid_length (46<100) -> REJECT
  send_rx_custom_frame(46, 16'd1501);   // reserved L/T -> REJECT
  send_rx_frame(1500);                  // valid -> ACCEPT
  send_rx_frame(64);                    // valid -> ACCEPT
  send_rx_frame(1501);                  // oversize -> REJECT
  send_rx_frame(47);                    // valid -> ACCEPT
  send_rx_custom_frame(46, 16'd1536);   // type -> ACCEPT
  #3us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 5,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out)
    `uvm_error("FF_002_I9", $sformatf("FAIL: timed out (expected 5, got %0d)", axi_after - axi_before))
  else if (axi_after - axi_before != 5)
    `uvm_error("FF_002_I9", $sformatf("FAIL: expected 5 accepts, got %0d", axi_after - axi_before))
  else
    `uvm_info("FF_002_I9", $sformatf("PASS: %0d/9 mixed frames accepted", axi_after - axi_before), UVM_NONE)
endtask

// =============================================================================
// run_stimulus
// =============================================================================
task FF_002_rx_len_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("FF_002", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("FF_002", "MAC reset and APB bootstrap did not complete")

  `uvm_info("FF_002", "=== FF-002 / RX_LEN_001 START ===", UVM_LOW)

  apb_write(16'h0004, (1 << 0) | (1 << 2));
  apb_write(16'h0044, 32'd1518);
  apb_write(16'h0048, 32'd64);
  #1us;

  iteration_i1_size_sweep();
  iteration_i2_dynamic_max();
  iteration_i3_declared_len_46();
  iteration_i4_declared_len_1500();
  iteration_i5_reserved_lt();
  iteration_i6_field_patterns();
  iteration_i7_interleaved();
  iteration_i8_backpressure_errors();
  iteration_i9_mixed();

  `uvm_info("FF_002", "=== FF-002 / RX_LEN_001 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // FF_002_RX_LEN_TEST_SVH
