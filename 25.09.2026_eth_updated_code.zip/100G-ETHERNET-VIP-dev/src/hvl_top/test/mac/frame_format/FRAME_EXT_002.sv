`ifndef FF_006_FRAME_EXT_002_TEST_SVH
`define FF_006_FRAME_EXT_002_TEST_SVH

//------------------------------------------------------------------------------
// FF-006 -- FRAME_EXT_002 -- Wire Bit Order and Extended Client-Data Formats
//
// Objective: Verify serial bit order and supported basic, Q-tagged, and
// envelope frame formats.
//
// Scenarios / iterations:
//   TX Bit-Order & Format (I1-I4):
//     I1  -- TX bit-distinct basic 1500B: unique DA/SA/ET/incrementing payload
//     I2  -- TX bit-distinct Q-tagged 1504B: ET=0x8810, TCI+Inner-ET in payload
//     I3  -- TX bit-distinct envelope 1982B: large frame byte order
//     I4  -- TX bit-distinct with client FCS: verify FCS is LSB-first
//
//   RX Format Delivery (I5-I7):
//     I5  -- RX basic 1500B: delivered to AXI client
//     I6  -- RX Q-tagged 1504B: delivered to AXI client
//     I7  -- RX envelope 1982B: delivered to AXI client
//
//   Boundary Sizes (I8-I10):
//     I8  -- TX just-below/at/above 1500B: 1499, 1500, 1501
//     I9  -- TX just-below/at/above 1504B: 1503, 1504, 1505
//     I10 -- TX just-below/at/above 1982B: 1981, 1982, 1983
//
//   Payload Patterns (I11-I12):
//     I11 -- TX basic 1500B with all 8 payload patterns
//     I12 -- TX Q-tagged 1504B with all 8 payload patterns
//
//   Mixed Streams (I13-I14):
//     I13 -- TX mixed: 4 basic + 3 Q-tagged + 2 envelope frames
//     I14 -- RX mixed: 4 basic + 3 Q-tagged + 2 envelope frames
//
//   Additional (I15-I16):
//     I15 -- TX minimum 64B basic frame
//     I16 -- TX large random payload (64-9000 bytes, random pattern)
//
// Verification:
//   Bit-distinct DA/SA/ET/payload values verify big-endian byte order on wire.
//   Client FCS frames verify FCS transmitted LSB-first.
//   Basic/Q-tagged/envelope formats accepted without truncation.
//   Boundary sizes just-below/at/above each maximum accepted.
//   All 8 payload patterns accepted for each format.
//   Mixed streams deliver all valid frames.
//
// Agent topology:
//   AXI TX active  -- drives MA_DATA.request frames into MAC
//   AXI RX passive -- monitors MA_DATA.indication delivery to client
//   RS  RX active  -- drives frames into MAC RX path
//   RS  TX passive -- monitors DUT TX wire
//   APB  active    -- station address and config
//------------------------------------------------------------------------------
class FF_006_frame_ext_002_test_c extends mac_base_test_c;
  `uvm_component_utils(FF_006_frame_ext_002_test_c)

  extern function new(string name = "FF_006_frame_ext_002_test_c",
                       uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task send_tx_basic(int payload_bytes,
                            mac_hvl_utils_c::payload_pattern_e pat =
                                mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                            bit fcs_on = 0);
  extern task send_tx_qtag(int payload_bytes,
                           mac_hvl_utils_c::payload_pattern_e pat =
                               mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                           bit fcs_on = 0);
  extern task send_tx_envelope(int payload_bytes,
                               mac_hvl_utils_c::payload_pattern_e pat =
                                   mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                               bit fcs_on = 0);
  extern task send_rx_frame_to_dut(int payload_bytes,
                                   bit [47:0] da,
                                   bit [15:0] et = 16'h0800,
                                   mac_hvl_utils_c::payload_pattern_e pat =
                                       mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  extern task check_tx(string label, int tx_before, int expected, bit timed_out);

  extern task iteration_i1_tx_bit_distinct_basic();
  extern task iteration_i2_tx_bit_distinct_qtag();
  extern task iteration_i3_tx_bit_distinct_envelope();
  extern task iteration_i4_tx_bit_distinct_fcs();
  extern task iteration_i5_rx_basic_1500();
  extern task iteration_i6_rx_qtag_1504();
  extern task iteration_i7_rx_envelope_1982();
  extern task iteration_i8_boundary_1500();
  extern task iteration_i9_boundary_1504();
  extern task iteration_i10_boundary_1982();
  extern task iteration_i11_patterns_basic();
  extern task iteration_i12_patterns_qtag();
  extern task iteration_i13_tx_mixed();
  extern task iteration_i14_rx_mixed();
  extern task iteration_i15_tx_minimum();
  extern task iteration_i16_tx_large_random();
endclass

function FF_006_frame_ext_002_test_c::new(
    string name = "FF_006_frame_ext_002_test_c",
    uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;
  num_axi_passive_agents = 1;
  num_rs_active_agents   = 1;
  num_rs_passive_agents  = 1;
endfunction

function void FF_006_frame_ext_002_test_c::configure_test();
  super.configure_test();
  env_cfg_h.max_payload_bytes = 9000;
  env_cfg_h.max_frame_octets  = 9026;
  env_cfg_h.scoreboard_enable_rx_check = 0;
  env_cfg_h.scoreboard_enable_tx_check = 0;
  env_cfg_h.scoreboard_check_error_flags = 0;
  env_cfg_h.has_protocol_checkers = 0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task FF_006_frame_ext_002_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task FF_006_frame_ext_002_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// Helpers
// =============================================================================
task FF_006_frame_ext_002_test_c::send_tx_basic(
    int payload_bytes,
    mac_hvl_utils_c::payload_pattern_e pat,
    bit fcs_on);
  axi_crc_seq_c seq_h;
  seq_h = axi_crc_seq_c::type_id::create("tx_basic");
  seq_h.dst_addr           = 48'h02_00_00_00_00_01;
  seq_h.src_addr           = 48'h02_00_00_00_00_02;
  seq_h.ether_type         = 16'h0800;
  seq_h.payload_length     = payload_bytes;
  seq_h.payload_pattern    = pat;
  seq_h.client_fcs_present = fcs_on;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_006_frame_ext_002_test_c::send_tx_qtag(
    int payload_bytes,
    mac_hvl_utils_c::payload_pattern_e pat,
    bit fcs_on);
  axi_qtag_seq_c seq_h;
  seq_h = axi_qtag_seq_c::type_id::create("tx_qtag");
  seq_h.dst_addr           = 48'h02_00_00_00_00_01;
  seq_h.src_addr           = 48'h02_00_00_00_00_02;
  seq_h.vlan_tci           = 16'h0001;
  seq_h.inner_ether_type   = 16'h0800;
  seq_h.payload_length     = payload_bytes;
  seq_h.payload_pattern    = pat;
  seq_h.client_fcs_present = fcs_on;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_006_frame_ext_002_test_c::send_tx_envelope(
    int payload_bytes,
    mac_hvl_utils_c::payload_pattern_e pat,
    bit fcs_on);
  axi_crc_seq_c seq_h;
  seq_h = axi_crc_seq_c::type_id::create("tx_env");
  seq_h.dst_addr           = 48'h02_00_00_00_00_01;
  seq_h.src_addr           = 48'h02_00_00_00_00_02;
  seq_h.ether_type         = 16'h0800;
  seq_h.payload_length     = payload_bytes;
  seq_h.payload_pattern    = pat;
  seq_h.client_fcs_present = fcs_on;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_006_frame_ext_002_test_c::send_rx_frame_to_dut(
    int payload_bytes,
    bit [47:0] da,
    bit [15:0] et,
    mac_hvl_utils_c::payload_pattern_e pat);
  rx_frame_field_seq_c seq_h;
  seq_h = rx_frame_field_seq_c::type_id::create("rx_drv");
  seq_h.num_frames_to_send = 1;
  seq_h.payload_length     = payload_bytes;
  seq_h.dst_addr           = da;
  seq_h.src_addr           = 48'h02_00_00_00_00_01;
  seq_h.ether_type_val     = et;
  seq_h.payload_pattern    = pat;
  seq_h.crc_error          = 0;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_006_frame_ext_002_test_c::check_tx(
    string label, int tx_before, int expected, bit timed_out);
  if (timed_out)
    `uvm_error("FF_006", $sformatf("FAIL %s: timed out (before=%0d expected_delta=%0d)",
               label, tx_before, expected))
  else
    `uvm_info("FF_006", $sformatf("PASS %s", label), UVM_NONE)
endtask

// =============================================================================
// I1 -- TX bit-distinct basic 1500B
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i1_tx_bit_distinct_basic();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I1: TX bit-distinct basic 1500B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_basic(1500, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I1: bit-distinct basic 1500B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I2 -- TX bit-distinct Q-tagged 1504B
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i2_tx_bit_distinct_qtag();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I2: TX bit-distinct Q-tagged 1504B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_qtag(1500, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I2: bit-distinct Q-tagged 1504B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I3 -- TX bit-distinct envelope 1982B
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i3_tx_bit_distinct_envelope();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I3: TX bit-distinct envelope 1982B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_envelope(1982, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I3: bit-distinct envelope 1982B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I4 -- TX bit-distinct with client FCS (verify LSB-first)
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i4_tx_bit_distinct_fcs();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I4: TX bit-distinct with client FCS ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_basic(1500, mac_hvl_utils_c::PAYLOAD_INCREMENTING, 1);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I4: bit-distinct FCS LSB-first on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I5 -- RX basic 1500B
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i5_rx_basic_1500();
  int axi_before; bit timed_out;

  `uvm_info("FF_006", "--- I5: RX basic 1500B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(1500, 48'h02_00_00_00_AA_05, 16'h0800);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I5: RX basic 1500B delivered", axi_before, 1, timed_out);
endtask

// =============================================================================
// I6 -- RX Q-tagged 1504B
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i6_rx_qtag_1504();
  int axi_before; bit timed_out;

  `uvm_info("FF_006", "--- I6: RX Q-tagged 1504B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(1504, 48'h02_00_00_00_AA_05, 16'h8810);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I6: RX Q-tagged 1504B delivered", axi_before, 1, timed_out);
endtask

// =============================================================================
// I7 -- RX envelope 1982B
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i7_rx_envelope_1982();
  int axi_before; bit timed_out;

  `uvm_info("FF_006", "--- I7: RX envelope 1982B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(1982, 48'h02_00_00_00_AA_05, 16'h0800);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I7: RX envelope 1982B delivered", axi_before, 1, timed_out);
endtask

// =============================================================================
// I8 -- TX boundary 1499 / 1500 / 1501
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i8_boundary_1500();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I8: TX boundary 1499/1500/1501 ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_tx_basic(1499);
  #500ns;
  send_tx_basic(1500);
  #500ns;
  send_tx_basic(1501);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 3,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I8: boundary 1499/1500/1501 on wire", tx_before, 3, timed_out);
endtask

// =============================================================================
// I9 -- TX boundary 1503 / 1504 / 1505
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i9_boundary_1504();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I9: TX boundary 1503/1504/1505 ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_tx_qtag(1503);
  #500ns;
  send_tx_qtag(1504);
  #500ns;
  send_tx_qtag(1505);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 3,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I9: boundary 1503/1504/1505 on wire", tx_before, 3, timed_out);
endtask

// =============================================================================
// I10 -- TX boundary 1981 / 1982 / 1983
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i10_boundary_1982();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I10: TX boundary 1981/1982/1983 ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_tx_envelope(1981);
  #500ns;
  send_tx_envelope(1982);
  #500ns;
  send_tx_envelope(1983);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 3,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I10: boundary 1981/1982/1983 on wire", tx_before, 3, timed_out);
endtask

// =============================================================================
// I11 -- TX basic 1500B with all 8 payload patterns
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i11_patterns_basic();
  int tx_before; bit timed_out;
  mac_hvl_utils_c::payload_pattern_e patterns[];

  `uvm_info("FF_006", "--- I11: TX basic 1500B all patterns ---", UVM_LOW)
  patterns = '{
      mac_hvl_utils_c::PAYLOAD_ZERO,
      mac_hvl_utils_c::PAYLOAD_ONES,
      mac_hvl_utils_c::PAYLOAD_ALT_55_AA,
      mac_hvl_utils_c::PAYLOAD_ALT_AA_55,
      mac_hvl_utils_c::PAYLOAD_INCREMENTING,
      mac_hvl_utils_c::PAYLOAD_DECREMENTING,
      mac_hvl_utils_c::PAYLOAD_KNOWN_CRC,
      mac_hvl_utils_c::PAYLOAD_RANDOM
  };

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  foreach (patterns[i]) begin
    send_tx_basic(1500, patterns[i]);
    #500ns;
  end
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 8,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I11: basic 1500B all 8 patterns on wire", tx_before, 8, timed_out);
endtask

// =============================================================================
// I12 -- TX Q-tagged 1504B with all 8 payload patterns
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i12_patterns_qtag();
  int tx_before; bit timed_out;
  mac_hvl_utils_c::payload_pattern_e patterns[];

  `uvm_info("FF_006", "--- I12: TX Q-tagged 1504B all patterns ---", UVM_LOW)
  patterns = '{
      mac_hvl_utils_c::PAYLOAD_ZERO,
      mac_hvl_utils_c::PAYLOAD_ONES,
      mac_hvl_utils_c::PAYLOAD_ALT_55_AA,
      mac_hvl_utils_c::PAYLOAD_ALT_AA_55,
      mac_hvl_utils_c::PAYLOAD_INCREMENTING,
      mac_hvl_utils_c::PAYLOAD_DECREMENTING,
      mac_hvl_utils_c::PAYLOAD_KNOWN_CRC,
      mac_hvl_utils_c::PAYLOAD_RANDOM
  };

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  foreach (patterns[i]) begin
    send_tx_qtag(1500, patterns[i]);
    #500ns;
  end
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 8,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I12: Q-tagged 1504B all 8 patterns on wire", tx_before, 8, timed_out);
endtask

// =============================================================================
// I13 -- TX mixed stream: 4 basic + 3 Q-tagged + 2 envelope
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i13_tx_mixed();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I13: TX mixed stream (9 frames) ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_tx_basic(100,  mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #200ns;
  send_tx_qtag(1500, mac_hvl_utils_c::PAYLOAD_ONES);
  #200ns;
  send_tx_envelope(1982, mac_hvl_utils_c::PAYLOAD_ZERO);
  #200ns;
  send_tx_basic(500,  mac_hvl_utils_c::PAYLOAD_RANDOM);
  #200ns;
  send_tx_qtag(200,  mac_hvl_utils_c::PAYLOAD_ALT_55_AA);
  #200ns;
  send_tx_basic(1500, mac_hvl_utils_c::PAYLOAD_DECREMENTING);
  #200ns;
  send_tx_envelope(1000, mac_hvl_utils_c::PAYLOAD_KNOWN_CRC);
  #200ns;
  send_tx_qtag(1500, mac_hvl_utils_c::PAYLOAD_ALT_AA_55);
  #200ns;
  send_tx_basic(64,   mac_hvl_utils_c::PAYLOAD_ZERO);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 9,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I13: TX mixed 9 frames on wire", tx_before, 9, timed_out);
endtask

// =============================================================================
// I14 -- RX mixed stream: 4 basic + 3 Q-tagged + 2 envelope
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i14_rx_mixed();
  int axi_before; bit timed_out;

  `uvm_info("FF_006", "--- I14: RX mixed stream (9 frames) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_rx_frame_to_dut(100,  48'h02_00_00_00_AA_05, 16'h0800);
  #200ns;
  send_rx_frame_to_dut(1500, 48'h02_00_00_00_AA_05, 16'h8810);
  #200ns;
  send_rx_frame_to_dut(1982, 48'h02_00_00_00_AA_05, 16'h0800);
  #200ns;
  send_rx_frame_to_dut(500,  48'h02_00_00_00_AA_05, 16'h0800);
  #200ns;
  send_rx_frame_to_dut(200,  48'h02_00_00_00_AA_05, 16'h8810);
  #200ns;
  send_rx_frame_to_dut(1500, 48'h02_00_00_00_AA_05, 16'h0800);
  #200ns;
  send_rx_frame_to_dut(1000, 48'h02_00_00_00_AA_05, 16'h0800);
  #200ns;
  send_rx_frame_to_dut(1500, 48'h02_00_00_00_AA_05, 16'h8810);
  #200ns;
  send_rx_frame_to_dut(64,   48'h02_00_00_00_AA_05, 16'h0800);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 9,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I14: RX mixed 9 frames delivered", axi_before, 9, timed_out);
endtask

// =============================================================================
// I15 -- TX minimum 64B basic frame
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i15_tx_minimum();
  int tx_before; bit timed_out;

  `uvm_info("FF_006", "--- I15: TX minimum 64B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_basic(64, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx("I15: minimum 64B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I16 -- TX large random payload (64-9000 bytes, random pattern)
// =============================================================================
task FF_006_frame_ext_002_test_c::iteration_i16_tx_large_random();
  int tx_before; bit timed_out;
  int payload_bytes;

  `uvm_info("FF_006", "--- I16: TX large random payload ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  payload_bytes = 64 + $urandom_range(0, 8936);
  `uvm_info("FF_006", $sformatf("  Random payload = %0d bytes", payload_bytes), UVM_LOW)
  send_tx_basic(payload_bytes, mac_hvl_utils_c::PAYLOAD_RANDOM);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx($sformatf("I16: large random %0dB on wire", payload_bytes), tx_before, 1, timed_out);
endtask

// =============================================================================
// run_stimulus
// =============================================================================
task FF_006_frame_ext_002_test_c::run_stimulus(uvm_phase phase);
  bit [31:0] rdata;

  if (env_h == null || env_h.apb3_agent_top_h == null ||
      env_h.virtual_sequencer_h == null || env_cfg_h.ral_h == null)
    `uvm_fatal("FF_006", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("FF_006", "MAC reset and APB bootstrap did not complete")

  `uvm_info("FF_006", "=== FF-006 / FRAME_EXT_002 START ===", UVM_LOW)

  apb_write(reg_map_pkg::REG_MAC_ADDR_LOW,  32'h00_00_AA_05);
  apb_write(reg_map_pkg::REG_MAC_ADDR_HIGH, 32'h00_00_02_00);
  apb_write(reg_map_pkg::group_low_addr(0),  32'h5E00_AA05);
  apb_write(reg_map_pkg::group_high_addr(0), 32'h0001_0100);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0015);
  apb_write(reg_map_pkg::REG_MAX_FRAME_SIZE, 32'h0000_2346);

  apb_read(reg_map_pkg::REG_MAC_ADDR_LOW, rdata);
  `uvm_info("FF_006", $sformatf("Station addr LOW = 0x%h", rdata), UVM_LOW)
  apb_read(reg_map_pkg::REG_MAC_ADDR_HIGH, rdata);
  `uvm_info("FF_006", $sformatf("Station addr HIGH = 0x%h", rdata), UVM_LOW)

  // TX Bit-Order & Format (I1-I4)
  iteration_i1_tx_bit_distinct_basic();
  iteration_i2_tx_bit_distinct_qtag();
  iteration_i3_tx_bit_distinct_envelope();
  iteration_i4_tx_bit_distinct_fcs();

  // RX Format Delivery (I5-I7)
  iteration_i5_rx_basic_1500();
  iteration_i6_rx_qtag_1504();
  iteration_i7_rx_envelope_1982();

  // Boundary Sizes (I8-I10)
  iteration_i8_boundary_1500();
  iteration_i9_boundary_1504();
  iteration_i10_boundary_1982();

  // Payload Patterns (I11-I12)
  iteration_i11_patterns_basic();
  iteration_i12_patterns_qtag();

  // Mixed Streams (I13-I14)
  iteration_i13_tx_mixed();
  iteration_i14_rx_mixed();

  // Additional (I15-I16)
  iteration_i15_tx_minimum();
  iteration_i16_tx_large_random();

  `uvm_info("FF_006", "=== FF-006 / FRAME_EXT_002 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // FF_006_FRAME_EXT_002_TEST_SVH
