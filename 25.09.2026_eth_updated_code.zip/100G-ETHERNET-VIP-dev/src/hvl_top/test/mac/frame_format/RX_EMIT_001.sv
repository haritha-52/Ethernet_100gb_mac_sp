`ifndef FF_001_RX_EMIT_TEST_SVH
`define FF_001_RX_EMIT_TEST_SVH

//------------------------------------------------------------------------------
// FF-001 -- RX_EMIT_001 -- RX Frame Emission and Client Backpressure
//
// Objective: Verify rx_frame_emit module behavior: valid frames emit
// complete ordered client transactions, backpressure (client_ready low)
// stalls emission without data loss, and invalid/error frames produce
// no valid delivery.
//
// Iterations:
//   I1 -- Valid 64B frame (minimum size)
//   I2 -- Valid 1518B frame (standard MTU)
//   I3 -- Valid 9000B jumbo frame
//   I4 -- Ready-low early (3 consecutive frames)
//   I5 -- Ready-low middle (2 large frames)
//   I6 -- Ready-low late (back-to-back varying sizes)
//   I7 -- CRC error frame (frame_drop, no AXI delivery)
//   I8 -- Mixed valid + error rapid succession
//
// Agent topology:
//   RS  RX active  -- drive frames into the MAC RX path
//   RS  TX passive -- monitor DUT-generated frames on TX wire
//   AXI RX passive -- monitor data delivery to client
//   APB  active    -- always present (from base test)
//------------------------------------------------------------------------------
class FF_001_rx_emit_test_c extends mac_base_test_c;
  `uvm_component_utils(FF_001_rx_emit_test_c)

  extern function new(string name = "FF_001_rx_emit_test_c",
                       uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task send_rx_frame(int payload_bytes);
  extern task send_rx_error_frame(int payload_bytes);
  extern task iteration_i1_min_64b();
  extern task iteration_i2_std_1518b();
  extern task iteration_i3_jumbo_9000b();
  extern task iteration_i4_ready_early();
  extern task iteration_i5_ready_middle();
  extern task iteration_i6_ready_late();
  extern task iteration_i7_crc_error();
  extern task iteration_i8_mixed();
endclass

function FF_001_rx_emit_test_c::new(string name = "FF_001_rx_emit_test_c",
                                    uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 0;
  num_axi_passive_agents = 1;
  num_rs_active_agents   = 1;
  num_rs_passive_agents  = 1;
endfunction

function void FF_001_rx_emit_test_c::configure_test();
  super.configure_test();
  env_cfg_h.max_payload_bytes = 9000;
  env_cfg_h.max_frame_octets  = 9026;
  env_cfg_h.scoreboard_enable_rx_check = 0;
  env_cfg_h.scoreboard_enable_tx_check = 0;
  env_cfg_h.scoreboard_check_error_flags = 0;
  env_cfg_h.has_protocol_checkers = 1;
endfunction

task FF_001_rx_emit_test_c::apb_write(input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                                       input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task FF_001_rx_emit_test_c::apb_read(input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                                      output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// Helpers — use existing sequences, zero custom sequence classes
// =============================================================================
task FF_001_rx_emit_test_c::send_rx_frame(int payload_bytes);
  rs_sequence_c seq_h;
  seq_h = rs_sequence_c::type_id::create("clean_drv");
  seq_h.num_frames      = 1;
  seq_h.payload_min     = payload_bytes;
  seq_h.payload_max     = payload_bytes;
  seq_h.error_injection = 0;
  seq_h.broadcast_da    = 1;
  seq_h.inter_frame_delay = 0;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_001_rx_emit_test_c::send_rx_error_frame(int payload_bytes);
  rx_emit_error_frame_seq_c seq_h;
  seq_h = rx_emit_error_frame_seq_c::type_id::create("err_drv");
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// =============================================================================
// I1 -- Valid 64B frame
// =============================================================================
task FF_001_rx_emit_test_c::iteration_i1_min_64b();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_001", "--- I1: Valid 64B frame ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame(46);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_001_I1", "FAIL: timed out waiting for 64B frame delivery")
  else
    `uvm_info("FF_001_I1", "PASS: 64B frame emitted to client", UVM_NONE)
endtask

// =============================================================================
// I2 -- Valid 1518B frame
// =============================================================================
task FF_001_rx_emit_test_c::iteration_i2_std_1518b();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_001", "--- I2: Valid 1518B frame ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame(1500);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_001_I2", "FAIL: timed out waiting for 1518B frame delivery")
  else
    `uvm_info("FF_001_I2", "PASS: 1518B frame emitted to client", UVM_NONE)
endtask

// =============================================================================
// I3 -- Valid 9000B jumbo frame
// =============================================================================
task FF_001_rx_emit_test_c::iteration_i3_jumbo_9000b();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_001", "--- I3: Valid 9000B jumbo frame ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame(8986);
  #50us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_001_I3", "FAIL: timed out waiting for 9000B frame delivery")
  else
    `uvm_info("FF_001_I3", "PASS: 9000B jumbo frame emitted to client", UVM_NONE)
endtask

// =============================================================================
// I4 -- Ready-low early (3 consecutive frames)
// =============================================================================
task FF_001_rx_emit_test_c::iteration_i4_ready_early();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_001", "--- I4: Ready-low early ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame(200);
  send_rx_frame(200);
  send_rx_frame(200);
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 3,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_001_I4", "FAIL: timed out waiting for 3 frames")
  else
    `uvm_info("FF_001_I4", "PASS: 3 frames emitted after early backpressure", UVM_NONE)
endtask

// =============================================================================
// I5 -- Ready-low middle (2 large frames)
// =============================================================================
task FF_001_rx_emit_test_c::iteration_i5_ready_middle();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_001", "--- I5: Ready-low middle ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame(1500);
  send_rx_frame(1500);
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 2,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_001_I5", "FAIL: timed out waiting for 2 frames")
  else
    `uvm_info("FF_001_I5", "PASS: 2 frames emitted after mid backpressure", UVM_NONE)
endtask

// =============================================================================
// I6 -- Ready-low late (back-to-back varying sizes)
// =============================================================================
task FF_001_rx_emit_test_c::iteration_i6_ready_late();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_001", "--- I6: Ready-low late ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame(46);
  send_rx_frame(500);
  send_rx_frame(1500);
  send_rx_frame(46);
  #2us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 4,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_001_I6", "FAIL: timed out waiting for 4 frames")
  else
    `uvm_info("FF_001_I6", "PASS: 4 frames emitted after late backpressure", UVM_NONE)
endtask

// =============================================================================
// I7 -- CRC error frame (frame_drop, no AXI delivery)
// =============================================================================
task FF_001_rx_emit_test_c::iteration_i7_crc_error();
  int axi_before;
  int axi_after;

  `uvm_info("FF_001", "--- I7: CRC error frame ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_error_frame(46);
  #2us;

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (axi_after == axi_before)
    `uvm_info("FF_001_I7", "PASS: CRC error frame dropped (no AXI delivery)", UVM_NONE)
  else
    `uvm_error("FF_001_I7", $sformatf(
               "FAIL: CRC error frame was delivered (before=%0d after=%0d)",
               axi_before, axi_after))
endtask

// =============================================================================
// I8 -- Mixed valid + error rapid succession
// =============================================================================
task FF_001_rx_emit_test_c::iteration_i8_mixed();
  int axi_before;
  int valid_sent;
  int i;
  bit timed_out;

  `uvm_info("FF_001", "--- I8: Mixed valid + error ---", UVM_LOW)
  axi_before  = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  valid_sent = 0;

  for (i = 0; i < 8; i++) begin
    if (i % 2 == 0) begin
      send_rx_frame($urandom_range(46, 500));
      valid_sent++;
    end else begin
      send_rx_error_frame(64);
    end
  end
  #3us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + valid_sent,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_001_I8", $sformatf("FAIL: timed out waiting for %0d valid frames", valid_sent))
  else
    `uvm_info("FF_001_I8", $sformatf(
              "PASS: %0d valid frames delivered, error frames dropped", valid_sent), UVM_NONE)
endtask

// =============================================================================
// run_stimulus
// =============================================================================
task FF_001_rx_emit_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("FF_001", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("FF_001", "MAC reset and APB bootstrap did not complete")

  `uvm_info("FF_001", "=== FF-001 / RX_EMIT_001 START ===", UVM_LOW)

  apb_write(reg_map_pkg::REG_MAC_ADDR_LOW,  32'h00_00_00_01);
  apb_write(reg_map_pkg::REG_MAC_ADDR_HIGH, 32'h00_00_02_00);
  apb_write(reg_map_pkg::group_low_addr(0),  32'h5E00_AA05);
  apb_write(reg_map_pkg::group_high_addr(0), 32'h0001_0100);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0015);
  apb_write(reg_map_pkg::REG_MAX_FRAME_SIZE, 32'd9026);
  #1us;

  iteration_i1_min_64b();
  iteration_i2_std_1518b();
  iteration_i3_jumbo_9000b();
  iteration_i4_ready_early();
  iteration_i5_ready_middle();
  iteration_i6_ready_late();
  iteration_i7_crc_error();
  iteration_i8_mixed();

  `uvm_info("FF_001", "=== FF-001 / RX_EMIT_001 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // FF_001_RX_EMIT_TEST_SVH
