`ifndef FF_008_TX_PAYLOAD_003_TEST_SVH
`define FF_008_TX_PAYLOAD_003_TEST_SVH

//------------------------------------------------------------------------------
// FF-008 -- TX_PAYLOAD_003 -- TX Payload and Field Integrity
//
// Objective: Verify every requested field and payload byte appears once,
// in order, unmodified in the transmitted frame.
//
// Uses scoreboard-enabled byte-by-byte TX comparison.
//
// Scenarios / iterations:
//   Payload patterns (I1-I8): all 46B payloads
//     I1  -- PAYLOAD_ZERO (all 0x00)
//     I2  -- PAYLOAD_ONES (all 0xFF)
//     I3  -- PAYLOAD_ALT_55_AA (even=0x55, odd=0xAA)
//     I4  -- PAYLOAD_ALT_AA_55 (even=0xAA, odd=0x55)
//     I5  -- PAYLOAD_INCREMENTING (i & 0xFF)
//     I6  -- PAYLOAD_DECREMENTING (0xFF - i & 0xFF)
//     I7  -- PAYLOAD_KNOWN_CRC ({01,23,45,67,89,AB,CD,EF} cycle)
//     I8  -- PAYLOAD_RANDOM (seeded LCG)
//
//   DA/SA variations (I9-I10): 100B payload
//     I9  -- Broadcast DA (FF:FF:FF:FF:FF:FF) + standard SA
//     I10 -- Multicast DA (01:00:5E:00:00:01) + unicast SA
//
//   Length/Type variations (I11-I12): 100B payload
//     I11 -- ET=0x0800 (IPv4 Type) then ET=0x8810 (Q-tag Type)
//     I12 -- ET=1500 (Length field) then ET=1536 (first valid Type)
//
//   Boundary sizes (I13-I14): incrementing payload
//     I13 -- Minimum 46B payload (64B frame)
//     I14 -- Maximum 1500B payload (1518B frame)
//
//   Mixed streams (I15-I16): back-to-back
//     I15 -- 8 frames: different patterns, same size (200B each)
//     I16 -- 8 frames: varying DA/SA/ET/pattern/size (64-1500B)
//
// Verification:
//   Scoreboard TX check enabled with byte-by-byte payload comparison.
//   Scoreboard compares expected wire frame (from reference model) against
//   actual wire frame (from RS passive monitor) for: DA, SA, ET, payload
//   (byte-by-byte), and FCS.
//
// Agent topology:
//   AXI TX active  -- drives MA_DATA.request frames into MAC
//   RS  TX passive -- monitors DUT TX wire output
//   APB  active    -- station address and config
//------------------------------------------------------------------------------
class FF_008_tx_payload_003_test_c extends mac_base_test_c;
  `uvm_component_utils(FF_008_tx_payload_003_test_c)

  extern function new(string name = "FF_008_tx_payload_003_test_c",
                       uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task send_tx_frame(int payload_bytes,
                            mac_hvl_utils_c::payload_pattern_e pat =
                                mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                            bit [47:0] da = 48'hFF_FF_FF_FF_FF_FF,
                            bit [47:0] sa = 48'h02_00_00_00_00_01,
                            bit [15:0] et = 16'h0800);
  extern task send_tx_frame_directed(int payload_bytes,
                                     mac_hvl_utils_c::payload_pattern_e pat,
                                     bit [47:0] da,
                                     bit [47:0] sa,
                                     bit [15:0] et);
  extern task check_tx_on_wire(string label, int tx_before, int expected, bit timed_out);

  extern task iteration_i1_zero();
  extern task iteration_i2_ones();
  extern task iteration_i3_alt_55_aa();
  extern task iteration_i4_alt_aa_55();
  extern task iteration_i5_incr();
  extern task iteration_i6_decr();
  extern task iteration_i7_known_crc();
  extern task iteration_i8_random();
  extern task iteration_i9_broadcast_da();
  extern task iteration_i10_multicast_da();
  extern task iteration_i11_et_variations();
  extern task iteration_i12_length_type();
  extern task iteration_i13_min_payload();
  extern task iteration_i14_max_payload();
  extern task iteration_i15_mixed_patterns();
  extern task iteration_i16_mixed_fields();
endclass

function FF_008_tx_payload_003_test_c::new(
    string name = "FF_008_tx_payload_003_test_c",
    uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;
  num_axi_passive_agents = 0;
  num_rs_active_agents   = 0;
  num_rs_passive_agents  = 1;
endfunction

function void FF_008_tx_payload_003_test_c::configure_test();
  super.configure_test();
  env_cfg_h.max_payload_bytes = 9000;
  env_cfg_h.max_frame_octets  = 9026;
  env_cfg_h.scoreboard_enable_rx_check = 0;
  env_cfg_h.scoreboard_enable_tx_check = 1;
  env_cfg_h.scoreboard_check_addresses = 1;
  env_cfg_h.scoreboard_check_ether_type = 1;
  env_cfg_h.scoreboard_check_payload = 1;
  env_cfg_h.scoreboard_check_fcs = 1;
  env_cfg_h.scoreboard_check_error_flags = 0;
  env_cfg_h.has_protocol_checkers = 1;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task FF_008_tx_payload_003_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task FF_008_tx_payload_003_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// Helpers
// =============================================================================
task FF_008_tx_payload_003_test_c::send_tx_frame(
    int payload_bytes,
    mac_hvl_utils_c::payload_pattern_e pat,
    bit [47:0] da,
    bit [47:0] sa,
    bit [15:0] et);
  axi_crc_seq_c seq_h;
  seq_h = axi_crc_seq_c::type_id::create("tx_drv");
  seq_h.dst_addr           = da;
  seq_h.src_addr           = sa;
  seq_h.ether_type         = et;
  seq_h.payload_length     = payload_bytes;
  seq_h.payload_pattern    = pat;
  seq_h.client_fcs_present = 0;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_008_tx_payload_003_test_c::send_tx_frame_directed(
    int payload_bytes,
    mac_hvl_utils_c::payload_pattern_e pat,
    bit [47:0] da,
    bit [47:0] sa,
    bit [15:0] et);
  send_tx_frame(payload_bytes, pat, da, sa, et);
endtask

task FF_008_tx_payload_003_test_c::check_tx_on_wire(
    string label, int tx_before, int expected, bit timed_out);
  if (timed_out)
    `uvm_error("FF_008", $sformatf("FAIL %s: timed out (before=%0d expected_delta=%0d)",
               label, tx_before, expected))
  else
    `uvm_info("FF_008", $sformatf("PASS %s", label), UVM_NONE)
endtask

// =============================================================================
// I1 -- PAYLOAD_ZERO (all 0x00, 46B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i1_zero();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I1: PAYLOAD_ZERO 46B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_ZERO);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I1: PAYLOAD_ZERO 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I2 -- PAYLOAD_ONES (all 0xFF, 46B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i2_ones();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I2: PAYLOAD_ONES 46B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_ONES);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I2: PAYLOAD_ONES 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I3 -- PAYLOAD_ALT_55_AA (46B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i3_alt_55_aa();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I3: PAYLOAD_ALT_55_AA 46B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_ALT_55_AA);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I3: PAYLOAD_ALT_55_AA 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I4 -- PAYLOAD_ALT_AA_55 (46B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i4_alt_aa_55();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I4: PAYLOAD_ALT_AA_55 46B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_ALT_AA_55);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I4: PAYLOAD_ALT_AA_55 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I5 -- PAYLOAD_INCREMENTING (46B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i5_incr();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I5: PAYLOAD_INCREMENTING 46B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I5: PAYLOAD_INCREMENTING 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I6 -- PAYLOAD_DECREMENTING (46B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i6_decr();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I6: PAYLOAD_DECREMENTING 46B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_DECREMENTING);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I6: PAYLOAD_DECREMENTING 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I7 -- PAYLOAD_KNOWN_CRC (46B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i7_known_crc();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I7: PAYLOAD_KNOWN_CRC 46B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_KNOWN_CRC);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I7: PAYLOAD_KNOWN_CRC 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I8 -- PAYLOAD_RANDOM (46B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i8_random();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I8: PAYLOAD_RANDOM 46B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_RANDOM);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I8: PAYLOAD_RANDOM 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I9 -- Broadcast DA + standard SA (100B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i9_broadcast_da();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I9: Broadcast DA, 100B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 16'h0800);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I9: Broadcast DA 100B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I10 -- Multicast DA + unicast SA (100B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i10_multicast_da();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I10: Multicast DA, 100B ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                48'h01_00_5E_00_00_01, 48'h00_11_22_33_44_55, 16'h0800);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I10: Multicast DA 100B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I11 -- ET variations: 0x0800 then 0x8810 (100B each)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i11_et_variations();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I11: ET variations ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 16'h0800);
  #500ns;
  send_tx_frame(100, mac_hvl_utils_c::PAYLOAD_ONES,
                48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 16'h8810);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 2,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I11: ET 0x0800 + 0x8810 on wire", tx_before, 2, timed_out);
endtask

// =============================================================================
// I12 -- Length/Type: ET=1500 then ET=1536 (100B each)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i12_length_type();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I12: Length/Type variations ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 16'd1500);
  #500ns;
  send_tx_frame(100, mac_hvl_utils_c::PAYLOAD_ONES,
                48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 16'd1536);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 2,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I12: Length=1500 + Type=1536 on wire", tx_before, 2, timed_out);
endtask

// =============================================================================
// I13 -- Minimum 46B payload (64B frame)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i13_min_payload();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I13: Minimum 46B payload ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(46, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I13: Minimum 46B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I14 -- Maximum 1500B payload (1518B frame)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i14_max_payload();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I14: Maximum 1500B payload ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(1500, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #1us;
  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I14: Maximum 1500B on wire", tx_before, 1, timed_out);
endtask

// =============================================================================
// I15 -- Back-to-back 8 frames: different patterns, same size (200B)
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i15_mixed_patterns();
  int tx_before; bit timed_out;
  mac_hvl_utils_c::payload_pattern_e patterns[];

  `uvm_info("FF_008", "--- I15: Mixed patterns, 200B each ---", UVM_LOW)
  patterns = '{
      mac_hvl_utils_c::PAYLOAD_ZERO,
      mac_hvl_utils_c::PAYLOAD_ONES,
      mac_hvl_utils_c::PAYLOAD_ALT_55_AA,
      mac_hvl_utils_c::PAYLOAD_ALT_AA_55,
      mac_hvl_utils_c::PAYLOAD_INCREMENTING,
      mac_hvl_utils_c::PAYLOAD_DECREMENTING,
      mac_hvl_utils_c::PAYLOAD_KNOWN_CRC,
      mac_hvl_utils_c::PAYLOAD_RANDOM
  };

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  foreach (patterns[i]) begin
    send_tx_frame(200, patterns[i]);
    #200ns;
  end
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 8,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I15: 8 mixed patterns 200B on wire", tx_before, 8, timed_out);
endtask

// =============================================================================
// I16 -- Back-to-back 8 frames: varying DA/SA/ET/pattern/size
// =============================================================================
task FF_008_tx_payload_003_test_c::iteration_i16_mixed_fields();
  int tx_before; bit timed_out;

  `uvm_info("FF_008", "--- I16: Mixed fields 8 frames ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_tx_frame(64,   mac_hvl_utils_c::PAYLOAD_ZERO,
                48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 16'h0800);
  #200ns;
  send_tx_frame(1500, mac_hvl_utils_c::PAYLOAD_ONES,
                48'h01_00_5E_00_00_01, 48'h00_11_22_33_44_55, 16'h0800);
  #200ns;
  send_tx_frame(200,  mac_hvl_utils_c::PAYLOAD_ALT_55_AA,
                48'h02_00_00_00_00_01, 48'h02_00_00_00_00_02, 16'h8810);
  #200ns;
  send_tx_frame(500,  mac_hvl_utils_c::PAYLOAD_DECREMENTING,
                48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 16'd1500);
  #200ns;
  send_tx_frame(100,  mac_hvl_utils_c::PAYLOAD_KNOWN_CRC,
                48'h01_00_5E_00_00_01, 48'h02_00_00_00_00_01, 16'h0800);
  #200ns;
  send_tx_frame(1500, mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                48'h02_00_00_00_00_99, 48'h02_00_00_00_00_02, 16'h8810);
  #200ns;
  send_tx_frame(46,   mac_hvl_utils_c::PAYLOAD_RANDOM,
                48'hFF_FF_FF_FF_FF_FF, 48'h00_11_22_33_44_55, 16'd1536);
  #200ns;
  send_tx_frame(1000, mac_hvl_utils_c::PAYLOAD_ALT_AA_55,
                48'h02_00_00_00_00_01, 48'h02_00_00_00_00_01, 16'h0800);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 8,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_tx_on_wire("I16: 8 mixed fields on wire", tx_before, 8, timed_out);
endtask

// =============================================================================
// run_stimulus
// =============================================================================
task FF_008_tx_payload_003_test_c::run_stimulus(uvm_phase phase);
  bit [31:0] rdata;

  if (env_h == null || env_h.apb3_agent_top_h == null ||
      env_h.virtual_sequencer_h == null || env_cfg_h.ral_h == null)
    `uvm_fatal("FF_008", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("FF_008", "MAC reset and APB bootstrap did not complete")

  `uvm_info("FF_008", "=== FF-008 / TX_PAYLOAD_003 START ===", UVM_LOW)

  apb_write(reg_map_pkg::REG_MAC_ADDR_LOW,  32'h00_00_AA_05);
  apb_write(reg_map_pkg::REG_MAC_ADDR_HIGH, 32'h00_00_02_00);
  apb_write(reg_map_pkg::group_low_addr(0),  32'h5E00_AA05);
  apb_write(reg_map_pkg::group_high_addr(0), 32'h0001_0100);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0015);
  apb_write(reg_map_pkg::REG_MAX_FRAME_SIZE, 32'h0000_2346);

  apb_read(reg_map_pkg::REG_MAC_ADDR_LOW, rdata);
  `uvm_info("FF_008", $sformatf("Station addr LOW = 0x%h", rdata), UVM_LOW)
  apb_read(reg_map_pkg::REG_MAC_ADDR_HIGH, rdata);
  `uvm_info("FF_008", $sformatf("Station addr HIGH = 0x%h", rdata), UVM_LOW)

  // Payload patterns (I1-I8)
  iteration_i1_zero();
  iteration_i2_ones();
  iteration_i3_alt_55_aa();
  iteration_i4_alt_aa_55();
  iteration_i5_incr();
  iteration_i6_decr();
  iteration_i7_known_crc();
  iteration_i8_random();

  // DA/SA variations (I9-I10)
  iteration_i9_broadcast_da();
  iteration_i10_multicast_da();

  // ET variations (I11-I12)
  iteration_i11_et_variations();
  iteration_i12_length_type();

  // Boundary sizes (I13-I14)
  iteration_i13_min_payload();
  iteration_i14_max_payload();

  // Mixed streams (I15-I16)
  iteration_i15_mixed_patterns();
  iteration_i16_mixed_fields();

  `uvm_info("FF_008", "=== FF-008 / TX_PAYLOAD_003 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // FF_008_TX_PAYLOAD_003_TEST_SVH
