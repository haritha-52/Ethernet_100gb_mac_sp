`ifndef FF_005_MAC_SERVICE_002_TEST_SVH
`define FF_005_MAC_SERVICE_002_TEST_SVH

//------------------------------------------------------------------------------
// FF-005 -- MAC_SERVICE_002 -- MA_DATA Service Primitive Semantics
//
// Objective: Verify standard MA_DATA request/indication parameters and
// client-visible delivery rules.
//
// Scenarios / iterations:
//   TX Path (MA_DATA.request) -- I1-I6:
//     I1  -- Explicit SA + broadcast DA + client FCS
//     I2  -- Station addr as SA + broadcast DA + client FCS
//     I3  -- Individual (unicast) DA + explicit SA + client FCS
//     I4  -- Group (multicast) DA + explicit SA + client FCS
//     I5  -- Broadcast DA + client FCS present + zero payload
//     I6  -- Broadcast DA + client FCS omitted + ones payload
//
//   RX Path (MA_DATA.indication) -- I7-I12:
//     I7  -- Local unicast frame (DA = station_addr)
//     I8  -- Broadcast frame
//     I9  -- Group frame (DA = group_addr)
//     I10 -- Local unicast + zero payload pattern
//     I11 -- Local unicast + ones payload pattern
//     I12 -- Local unicast + alternating 0x55/0xAA payload pattern
//
//   Negative (No Indication) -- I13-I15:
//     I13 -- PAUSE frame (MAC Control) -- consumed, not delivered
//     I14 -- CRC error frame -- rejected, not delivered
//     I15 -- Non-matching unicast (filtered) -- not delivered
//
//   Mixed Stream -- I16:
//     I16 -- 13 frames: 8 valid + 2 PAUSE + 2 CRC error + 1 filtered
//
// Verification:
//   An omitted source address is replaced by the local address;
//   supplied/omitted FCS follows configured service semantics.
//   Indications contain correct parameters only for valid frames
//   addressed to the local client; MAC Control and invalid frames
//   are not delivered as normal MA_DATA indications.
//
// Agent topology:
//   AXI TX active  -- drives MA_DATA.request frames into MAC
//   AXI RX passive -- monitors MA_DATA.indication delivery to client
//   RS  RX active  -- drives frames into MAC RX path
//   RS  TX passive -- monitors DUT TX wire
//   APB  active    -- station address and config
//------------------------------------------------------------------------------
class FF_005_mac_service_002_test_c extends mac_base_test_c;
  `uvm_component_utils(FF_005_mac_service_002_test_c)

  extern function new(string name = "FF_005_mac_service_002_test_c",
                       uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task send_tx_frame(int payload_bytes,
                            bit [47:0] da, bit [47:0] sa,
                            bit fcs_on,
                            mac_hvl_utils_c::payload_pattern_e pat =
                                mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  extern task send_rx_frame_to_dut(int payload_bytes,
                                   bit [47:0] da,
                                   bit [47:0] sa = 48'h02_00_00_00_00_01,
                                   mac_hvl_utils_c::payload_pattern_e pat =
                                       mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  extern task send_rx_error_frame_to_dut(int payload_bytes);
  extern task send_pause_frame_to_dut();

  extern task iteration_i1_tx_explicit_sa();
  extern task iteration_i2_tx_station_sa();
  extern task iteration_i3_tx_unicast_da();
  extern task iteration_i4_tx_multicast_da();
  extern task iteration_i5_tx_fcs_present_zero();
  extern task iteration_i6_tx_fcs_omitted_ones();
  extern task iteration_i7_rx_local_unicast();
  extern task iteration_i8_rx_broadcast();
  extern task iteration_i9_rx_group();
  extern task iteration_i10_rx_zero_payload();
  extern task iteration_i11_rx_ones_payload();
  extern task iteration_i12_rx_alt_payload();
  extern task iteration_i13_pause_no_indication();
  extern task iteration_i14_crc_error_no_indication();
  extern task iteration_i15_filtered_no_indication();
  extern task iteration_i16_mixed_stream();
endclass

function FF_005_mac_service_002_test_c::new(
    string name = "FF_005_mac_service_002_test_c",
    uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;
  num_axi_passive_agents = 1;
  num_rs_active_agents   = 1;
  num_rs_passive_agents  = 1;
endfunction

function void FF_005_mac_service_002_test_c::configure_test();
  super.configure_test();
  env_cfg_h.max_payload_bytes = 9000;
  env_cfg_h.max_frame_octets  = 9026;
  env_cfg_h.scoreboard_enable_rx_check = 0;
  env_cfg_h.scoreboard_enable_tx_check = 0;
  env_cfg_h.scoreboard_check_error_flags = 0;
  env_cfg_h.has_protocol_checkers = 0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task FF_005_mac_service_002_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task FF_005_mac_service_002_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// Helpers
// =============================================================================

// TX path: drive frame via AXI active agent (MA_DATA.request)
task FF_005_mac_service_002_test_c::send_tx_frame(
    int payload_bytes,
    bit [47:0] da,
    bit [47:0] sa,
    bit fcs_on,
    mac_hvl_utils_c::payload_pattern_e pat);
  axi_crc_seq_c seq_h;
  seq_h = axi_crc_seq_c::type_id::create("tx_drv");
  seq_h.dst_addr           = da;
  seq_h.src_addr           = sa;
  seq_h.ether_type         = 16'h0800;
  seq_h.payload_length     = payload_bytes;
  seq_h.payload_pattern    = pat;
  seq_h.client_fcs_present = fcs_on;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// RX path: drive frame via RS active agent (toward MA_DATA.indication)
task FF_005_mac_service_002_test_c::send_rx_frame_to_dut(
    int payload_bytes,
    bit [47:0] da,
    bit [47:0] sa,
    mac_hvl_utils_c::payload_pattern_e pat);
  rx_frame_field_seq_c seq_h;
  seq_h = rx_frame_field_seq_c::type_id::create("rx_drv");
  seq_h.num_frames_to_send = 1;
  seq_h.payload_length     = payload_bytes;
  seq_h.dst_addr           = da;
  seq_h.src_addr           = sa;
  seq_h.ether_type_val     = 16'h0800;
  seq_h.payload_pattern    = pat;
  seq_h.crc_error          = 0;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// RX path: CRC error frame
task FF_005_mac_service_002_test_c::send_rx_error_frame_to_dut(int payload_bytes);
  rx_frame_field_seq_c seq_h;
  seq_h = rx_frame_field_seq_c::type_id::create("rx_err_drv");
  seq_h.num_frames_to_send = 1;
  seq_h.payload_length     = payload_bytes;
  seq_h.dst_addr           = 48'hFF_FF_FF_FF_FF_FF;
  seq_h.src_addr           = 48'h02_00_00_00_00_01;
  seq_h.ether_type_val     = 16'h0800;
  seq_h.payload_pattern    = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
  seq_h.crc_error          = 1;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// RX path: PAUSE frame (MAC Control, consumed by DUT)
task FF_005_mac_service_002_test_c::send_pause_frame_to_dut();
  mac_control_frame_sequence_c seq_h;
  seq_h = mac_control_frame_sequence_c::type_id::create("pause_drv");
  seq_h.mode        = mac_control_frame_sequence_c::MODE_GENERIC;
  seq_h.ctrl_da     = 48'h01_80_C2_00_00_01;
  seq_h.ctrl_sa     = 48'h02_00_00_00_00_01;
  seq_h.pause_quanta = 16'h0100;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// =============================================================================
// I1 -- TX: Explicit SA + broadcast DA + client FCS
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i1_tx_explicit_sa();
  int tx_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I1: TX explicit SA + broadcast DA + client FCS ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, 48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 1);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I1", "FAIL: TX frame not observed on wire")
  else
    `uvm_info("FF_005_I1", "PASS: TX explicit SA frame on wire", UVM_NONE)
endtask

// =============================================================================
// I2 -- TX: Station addr as SA + broadcast DA + client FCS
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i2_tx_station_sa();
  int tx_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I2: TX station addr as SA ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, 48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_AA_05, 1);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I2", "FAIL: TX frame not observed on wire")
  else
    `uvm_info("FF_005_I2", "PASS: TX station-addr SA frame on wire", UVM_NONE)
endtask

// =============================================================================
// I3 -- TX: Individual (unicast) DA + explicit SA + client FCS
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i3_tx_unicast_da();
  int tx_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I3: TX unicast DA ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, 48'h02_00_00_00_00_99, 48'h02_00_00_00_00_01, 1);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I3", "FAIL: TX unicast frame not observed on wire")
  else
    `uvm_info("FF_005_I3", "PASS: TX unicast DA frame on wire", UVM_NONE)
endtask

// =============================================================================
// I4 -- TX: Group (multicast) DA + explicit SA + client FCS
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i4_tx_multicast_da();
  int tx_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I4: TX multicast DA ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, 48'h01_00_5E_00_00_01, 48'h02_00_00_00_00_01, 1);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I4", "FAIL: TX multicast frame not observed on wire")
  else
    `uvm_info("FF_005_I4", "PASS: TX multicast DA frame on wire", UVM_NONE)
endtask

// =============================================================================
// I5 -- TX: Broadcast DA + client FCS present + zero payload
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i5_tx_fcs_present_zero();
  int tx_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I5: TX FCS present + zero payload ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, 48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 1,
                mac_hvl_utils_c::PAYLOAD_ZERO);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I5", "FAIL: TX zero-payload frame not observed on wire")
  else
    `uvm_info("FF_005_I5", "PASS: TX FCS-present zero-payload frame on wire", UVM_NONE)
endtask

// =============================================================================
// I6 -- TX: Broadcast DA + client FCS omitted + ones payload
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i6_tx_fcs_omitted_ones();
  int tx_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I6: TX FCS omitted + ones payload ---", UVM_LOW)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_tx_frame(100, 48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01, 0,
                mac_hvl_utils_c::PAYLOAD_ONES);
  #1us;

  mac_wait_utils_c::wait_for_count_at_least(
      tx_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I6", "FAIL: TX FCS-omitted frame not observed on wire")
  else
    `uvm_info("FF_005_I6", "PASS: TX FCS-omitted ones-payload frame on wire", UVM_NONE)
endtask

// =============================================================================
// I7 -- RX: Local unicast frame (DA = station_addr) -- delivered
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i7_rx_local_unicast();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I7: RX local unicast ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(100, 48'h02_00_00_00_AA_05);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I7", "FAIL: local unicast frame not delivered")
  else
    `uvm_info("FF_005_I7", "PASS: local unicast MA_DATA.indication delivered", UVM_NONE)
endtask

// =============================================================================
// I8 -- RX: Broadcast frame -- delivered
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i8_rx_broadcast();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I8: RX broadcast ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(100, 48'hFF_FF_FF_FF_FF_FF);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I8", "FAIL: broadcast frame not delivered")
  else
    `uvm_info("FF_005_I8", "PASS: broadcast MA_DATA.indication delivered", UVM_NONE)
endtask

// =============================================================================
// I9 -- RX: Group frame (DA = group_addr) -- delivered
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i9_rx_group();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I9: RX group ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(100, 48'h01_00_5E_00_AA_05);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I9", "FAIL: group frame not delivered")
  else
    `uvm_info("FF_005_I9", "PASS: group MA_DATA.indication delivered", UVM_NONE)
endtask

// =============================================================================
// I10 -- RX: Local unicast + zero payload pattern
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i10_rx_zero_payload();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I10: RX local unicast + zero payload ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(100, 48'h02_00_00_00_AA_05, 48'h02_00_00_00_00_01,
                       mac_hvl_utils_c::PAYLOAD_ZERO);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I10", "FAIL: zero-payload local frame not delivered")
  else
    `uvm_info("FF_005_I10", "PASS: zero-payload local MA_DATA.indication delivered", UVM_NONE)
endtask

// =============================================================================
// I11 -- RX: Local unicast + ones payload pattern
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i11_rx_ones_payload();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I11: RX local unicast + ones payload ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(100, 48'h02_00_00_00_AA_05, 48'h02_00_00_00_00_01,
                       mac_hvl_utils_c::PAYLOAD_ONES);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I11", "FAIL: ones-payload local frame not delivered")
  else
    `uvm_info("FF_005_I11", "PASS: ones-payload local MA_DATA.indication delivered", UVM_NONE)
endtask

// =============================================================================
// I12 -- RX: Local unicast + alternating 0x55/0xAA payload pattern
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i12_rx_alt_payload();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I12: RX local unicast + alt payload ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(100, 48'h02_00_00_00_AA_05, 48'h02_00_00_00_00_01,
                       mac_hvl_utils_c::PAYLOAD_ALT_55_AA);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I12", "FAIL: alt-payload local frame not delivered")
  else
    `uvm_info("FF_005_I12", "PASS: alt-payload local MA_DATA.indication delivered", UVM_NONE)
endtask

// =============================================================================
// I13 -- PAUSE frame (MAC Control) -- consumed, not delivered
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i13_pause_no_indication();
  int axi_before;
  int axi_after;

  `uvm_info("FF_005", "--- I13: PAUSE frame (no indication) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_pause_frame_to_dut();
  #2us;

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (axi_after == axi_before)
    `uvm_info("FF_005_I13", "PASS: PAUSE frame consumed (no MA_DATA.indication)", UVM_NONE)
  else
    `uvm_error("FF_005_I13", $sformatf(
               "FAIL: PAUSE frame was delivered (before=%0d after=%0d)",
               axi_before, axi_after))
endtask

// =============================================================================
// I14 -- CRC error frame -- rejected, not delivered
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i14_crc_error_no_indication();
  int axi_before;
  int axi_after;

  `uvm_info("FF_005", "--- I14: CRC error frame (no indication) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_error_frame_to_dut(100);
  #2us;

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (axi_after == axi_before)
    `uvm_info("FF_005_I14", "PASS: CRC error frame rejected (no MA_DATA.indication)", UVM_NONE)
  else
    `uvm_error("FF_005_I14", $sformatf(
               "FAIL: CRC error frame was delivered (before=%0d after=%0d)",
               axi_before, axi_after))
endtask

// =============================================================================
// I15 -- Non-matching unicast (filtered) -- not delivered
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i15_filtered_no_indication();
  int axi_before;
  int axi_after;

  `uvm_info("FF_005", "--- I15: Non-matching unicast (filtered) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_frame_to_dut(100, 48'hAA_BB_CC_DD_EE_FF, 48'h02_00_00_00_00_01);
  #2us;

  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (axi_after == axi_before)
    `uvm_info("FF_005_I15", "PASS: non-matching unicast filtered (no MA_DATA.indication)", UVM_NONE)
  else
    `uvm_error("FF_005_I15", $sformatf(
               "FAIL: non-matching unicast was delivered (before=%0d after=%0d)",
               axi_before, axi_after))
endtask

// =============================================================================
// I16 -- Mixed stream: 8 valid + 2 PAUSE + 2 CRC error + 1 filtered = 8 delivered
// =============================================================================
task FF_005_mac_service_002_test_c::iteration_i16_mixed_stream();
  int axi_before;
  bit timed_out;

  `uvm_info("FF_005", "--- I16: Mixed stream (13 frames) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  // Valid 1: local unicast
  send_rx_frame_to_dut(100, 48'h02_00_00_00_AA_05);
  // Valid 2: broadcast
  send_rx_frame_to_dut(200, 48'hFF_FF_FF_FF_FF_FF);
  // PAUSE 1: consumed
  send_pause_frame_to_dut();
  // Valid 3: group
  send_rx_frame_to_dut(100, 48'h01_00_5E_00_AA_05);
  // CRC error 1: rejected
  send_rx_error_frame_to_dut(64);
  // Valid 4: local unicast + zero payload
  send_rx_frame_to_dut(100, 48'h02_00_00_00_AA_05, 48'h02_00_00_00_00_01,
                       mac_hvl_utils_c::PAYLOAD_ZERO);
  // Valid 5: broadcast + ones payload
  send_rx_frame_to_dut(100, 48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01,
                       mac_hvl_utils_c::PAYLOAD_ONES);
  // PAUSE 2: consumed
  send_pause_frame_to_dut();
  // Valid 6: local unicast + alt payload
  send_rx_frame_to_dut(100, 48'h02_00_00_00_AA_05, 48'h02_00_00_00_00_01,
                       mac_hvl_utils_c::PAYLOAD_ALT_55_AA);
  // CRC error 2: rejected
  send_rx_error_frame_to_dut(64);
  // Filtered: non-matching unicast
  send_rx_frame_to_dut(100, 48'hAA_BB_CC_DD_EE_FF, 48'h02_00_00_00_00_01);
  // Valid 7: broadcast + incr payload
  send_rx_frame_to_dut(500, 48'hFF_FF_FF_FF_FF_FF);
  // Valid 8: local unicast + incr payload
  send_rx_frame_to_dut(100, 48'h02_00_00_00_AA_05, 48'h02_00_00_00_00_01,
                       mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  #3us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 8,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_005_I16", $sformatf(
               "FAIL: timed out waiting for 8 valid frames (got %0d)",
               env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt - axi_before))
  else
    `uvm_info("FF_005_I16",
              $sformatf("PASS: 8 valid delivered, 2 PAUSE consumed, 2 CRC rejected, 1 filtered"),
              UVM_NONE)
endtask

// =============================================================================
// run_stimulus
// =============================================================================
task FF_005_mac_service_002_test_c::run_stimulus(uvm_phase phase);
  bit [31:0] rdata;

  if (env_h == null || env_h.apb3_agent_top_h == null ||
      env_h.virtual_sequencer_h == null || env_cfg_h.ral_h == null)
    `uvm_fatal("FF_005", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("FF_005", "MAC reset and APB bootstrap did not complete")

  `uvm_info("FF_005", "=== FF-005 / MAC_SERVICE_002 START ===", UVM_LOW)

  // Configure station address: 02:00:00:00:AA:05
  apb_write(reg_map_pkg::REG_MAC_ADDR_LOW,  32'h00_00_AA_05);
  apb_write(reg_map_pkg::REG_MAC_ADDR_HIGH, 32'h00_00_02_00);

  // Configure group address 0: 01:00:5E:00:AA:05 (valid bit = 16 of high reg)
  apb_write(reg_map_pkg::group_low_addr(0),  32'h5E00_AA05);
  apb_write(reg_map_pkg::group_high_addr(0), 32'h0001_0100);

  // Enable RX + TX + PAUSE (bits 0,2,4 = 0x15)
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0015);

  // Set max frame size for jumbo support
  apb_write(reg_map_pkg::REG_MAX_FRAME_SIZE, 32'h0000_2346);

  // Verify station address readback
  apb_read(reg_map_pkg::REG_MAC_ADDR_LOW, rdata);
  `uvm_info("FF_005", $sformatf("Station addr LOW = 0x%h", rdata), UVM_LOW)
  apb_read(reg_map_pkg::REG_MAC_ADDR_HIGH, rdata);
  `uvm_info("FF_005", $sformatf("Station addr HIGH = 0x%h", rdata), UVM_LOW)

  // TX Path -- MA_DATA.request (I1-I6)
  iteration_i1_tx_explicit_sa();
  iteration_i2_tx_station_sa();
  iteration_i3_tx_unicast_da();
  iteration_i4_tx_multicast_da();
  iteration_i5_tx_fcs_present_zero();
  iteration_i6_tx_fcs_omitted_ones();

  // RX Path -- MA_DATA.indication (I7-I12)
  iteration_i7_rx_local_unicast();
  iteration_i8_rx_broadcast();
  iteration_i9_rx_group();
  iteration_i10_rx_zero_payload();
  iteration_i11_rx_ones_payload();
  iteration_i12_rx_alt_payload();

  // Negative -- No Indication (I13-I15)
  iteration_i13_pause_no_indication();
  iteration_i14_crc_error_no_indication();
  iteration_i15_filtered_no_indication();

  // Mixed Stream (I16)
  iteration_i16_mixed_stream();

  `uvm_info("FF_005", "=== FF-005 / MAC_SERVICE_002 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // FF_005_MAC_SERVICE_002_TEST_SVH
