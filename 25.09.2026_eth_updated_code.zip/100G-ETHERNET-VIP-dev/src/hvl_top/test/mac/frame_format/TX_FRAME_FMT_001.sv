`ifndef FF_003_TX_FRAME_FMT_TEST_SVH
`define FF_003_TX_FRAME_FMT_TEST_SVH

//------------------------------------------------------------------------------
// FF-003 -- TX_FRAME_FMT_001 -- MAC TX Frame Construction and Integrity
//
// Objective: Verify complete legal TX frame construction and service-interface
// handling across fields, payload patterns, size boundaries, and invalid
// length/data requests.  Merged legacy scope: valid TX, client data integrity,
// invalid consistency, and end-to-end TX.
//
// Iterations:
//   I1  -- Nominal DA/SA/Length-Type/payload frame (100B, ET=0x0800)
//   I2  -- Minimum frame (46B payload, no padding needed)
//   I3  -- Maximum standard frame (1500B payload)
//   I4  -- Jumbo frame (9000B payload)
//   I5  -- Mixed sizes: 46/200/500/1500/9000B sequential
//   I6  -- Back-to-back: 6 frames at 46/100/500/1500/46/100B
//   I7  -- Payload patterns: ZERO/ONES/ALT_55_AA/INCREMENTING/RANDOM (96B each)
//   I8  -- DA/SA variations: broadcast/multicast/unicast/all-zero-SA/all-one-SA/inc-SA
//   I9  -- Inconsistent: ET=100 (declares 100B), actual payload=200B
//   I10 -- Inconsistent: ET=200 (declares 200B), actual payload=100B
//   I11 -- Reserved Length/Type zone: ET=1500/1501/1536, actual=46B each
//   I12 -- Edge-case EtherType: ET=0x0000, actual=46B
//   I13 -- Edge-case EtherType: ET=0xFFFF, actual=46B
//   I14 -- Mixed stream: 9 frames mixing valid and inconsistent conditions
//
// Agent topology:
//   AXI TX active  -- drive frames into the MAC TX path
//   AXI RX passive -- monitor data at the AXI ingress
//   RS  TX passive -- monitor DUT-generated frames on TX wire
//   APB  active    -- always present (from base test)
//------------------------------------------------------------------------------
class FF_003_tx_frame_fmt_test_c extends mac_base_test_c;
  `uvm_component_utils(FF_003_tx_frame_fmt_test_c)

  extern function new(string name = "FF_003_tx_frame_fmt_test_c",
                       uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task send_axi_clean(int payload_bytes);
  extern task send_axi_pattern(int payload_bytes,
                               mac_hvl_utils_c::payload_pattern_e pattern);
  extern task send_axi_directed(bit [47:0] dst, bit [47:0] src,
                                bit [15:0] ether_type_v,
                                int payload_bytes, bit fcs_on);
  extern task send_axi_mismatch(int payload_bytes, bit [15:0] ether_type_v);

  extern task iteration_i1_nominal();
  extern task iteration_i2_min_frame();
  extern task iteration_i3_max_frame();
  extern task iteration_i4_jumbo();
  extern task iteration_i5_mixed_sizes();
  extern task iteration_i6_back_to_back();
  extern task iteration_i7_payload_patterns();
  extern task iteration_i8_address_variations();
  extern task iteration_i9_short_declared_len();
  extern task iteration_i10_long_declared_len();
  extern task iteration_i11_reserved_lt();
  extern task iteration_i12_et_zero();
  extern task iteration_i13_et_ones();
  extern task iteration_i14_mixed_stream();
endclass

function FF_003_tx_frame_fmt_test_c::new(string name = "FF_003_tx_frame_fmt_test_c",
                                         uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;
  num_axi_passive_agents = 1;
  num_rs_active_agents   = 0;
  num_rs_passive_agents  = 1;
endfunction

function void FF_003_tx_frame_fmt_test_c::configure_test();
  super.configure_test();
  env_cfg_h.max_payload_bytes = 9000;
  env_cfg_h.max_frame_octets  = 9026;
  env_cfg_h.scoreboard_enable_rx_check = 0;
  env_cfg_h.scoreboard_enable_tx_check = 0;
  env_cfg_h.scoreboard_check_error_flags = 0;
  env_cfg_h.has_protocol_checkers = 1;
  env_cfg_h.axi_active_agent_cfgs[0].min_payload_len = 1;
  env_cfg_h.axi_active_agent_cfgs[0].max_payload_len = 9000;
endfunction

task FF_003_tx_frame_fmt_test_c::apb_write(input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                                            input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task FF_003_tx_frame_fmt_test_c::apb_read(input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                                           output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// Helpers -- use existing sequences, zero custom sequence classes
// =============================================================================

// Drive a single clean AXI TX frame with broadcast DA and incrementing payload.
task FF_003_tx_frame_fmt_test_c::send_axi_clean(int payload_bytes);
  axi_crc_seq_c seq_h;
  seq_h = axi_crc_seq_c::type_id::create("clean_drv");
  seq_h.payload_length    = payload_bytes;
  seq_h.payload_pattern   = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
  seq_h.dst_addr          = 48'hFF_FF_FF_FF_FF_FF;
  seq_h.src_addr          = 48'h02_00_00_00_00_01;
  seq_h.ether_type        = 16'h0800;
  seq_h.client_fcs_present = 0;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// Drive a single AXI TX frame with a specific payload pattern.
task FF_003_tx_frame_fmt_test_c::send_axi_pattern(int payload_bytes,
                                                   mac_hvl_utils_c::payload_pattern_e pattern);
  axi_crc_seq_c seq_h;
  seq_h = axi_crc_seq_c::type_id::create("pattern_drv");
  seq_h.payload_length    = payload_bytes;
  seq_h.payload_pattern   = pattern;
  seq_h.dst_addr          = 48'hFF_FF_FF_FF_FF_FF;
  seq_h.src_addr          = 48'h02_00_00_00_00_01;
  seq_h.ether_type        = 16'h0800;
  seq_h.client_fcs_present = 0;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// Drive a single directed AXI TX frame with caller-controlled DA/SA/ET/size/FCS.
task FF_003_tx_frame_fmt_test_c::send_axi_directed(bit [47:0] dst,
                                                    bit [47:0] src,
                                                    bit [15:0] ether_type_v,
                                                    int payload_bytes,
                                                    bit fcs_on);
  axi_crc_seq_c seq_h;
  seq_h = axi_crc_seq_c::type_id::create("directed_drv");
  seq_h.payload_length     = payload_bytes;
  seq_h.payload_pattern    = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
  seq_h.dst_addr           = dst;
  seq_h.src_addr           = src;
  seq_h.ether_type         = ether_type_v;
  seq_h.client_fcs_present = fcs_on;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// Drive a single AXI TX frame with a mismatched EtherType vs actual payload.
task FF_003_tx_frame_fmt_test_c::send_axi_mismatch(int payload_bytes,
                                                    bit [15:0] ether_type_v);
  axi_tx_len_mismatch_seq_c seq_h;
  seq_h = axi_tx_len_mismatch_seq_c::type_id::create("mismatch_drv");
  seq_h.payload_length = payload_bytes;
  seq_h.ether_type_val = ether_type_v;
  seq_h.dst_addr       = 48'hFF_FF_FF_FF_FF_FF;
  seq_h.src_addr       = 48'h02_00_00_00_00_01;
  seq_h.insert_fcs     = 1;
  seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

// =============================================================================
// I1 -- Nominal DA/SA/Length-Type/payload frame
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i1_nominal();
  int rs_before;
  bit timed_out;

  `uvm_info("FF_003", "--- I1: Nominal frame ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_directed(48'h02_00_00_00_00_01, 48'h02_00_00_00_00_02,
                    16'h0800, 100, 0);
  #2us;

  mac_wait_utils_c::wait_for_count_at_least(
      rs_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_003_I1", "FAIL: timed out waiting for nominal frame on TX wire")
  else
    `uvm_info("FF_003_I1", "PASS: nominal frame emitted on TX wire", UVM_NONE)
endtask

// =============================================================================
// I2 -- Minimum frame (46B payload = 64B total, no padding)
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i2_min_frame();
  int rs_before;
  bit timed_out;

  `uvm_info("FF_003", "--- I2: Minimum frame ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_clean(46);
  #2us;

  mac_wait_utils_c::wait_for_count_at_least(
      rs_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_003_I2", "FAIL: timed out waiting for min frame on TX wire")
  else
    `uvm_info("FF_003_I2", "PASS: min frame (46B) emitted on TX wire", UVM_NONE)
endtask

// =============================================================================
// I3 -- Maximum standard frame (1500B payload)
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i3_max_frame();
  int rs_before;
  bit timed_out;

  `uvm_info("FF_003", "--- I3: Max standard frame ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_clean(1500);
  #5us;

  mac_wait_utils_c::wait_for_count_at_least(
      rs_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_003_I3", "FAIL: timed out waiting for max frame on TX wire")
  else
    `uvm_info("FF_003_I3", "PASS: max frame (1500B) emitted on TX wire", UVM_NONE)
endtask

// =============================================================================
// I4 -- Jumbo frame (9000B payload)
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i4_jumbo();
  int rs_before;
  bit timed_out;

  `uvm_info("FF_003", "--- I4: Jumbo frame ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_clean(9000);
  #50us;

  mac_wait_utils_c::wait_for_count_at_least(
      rs_before + 1,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_003_I4", "FAIL: timed out waiting for jumbo frame on TX wire")
  else
    `uvm_info("FF_003_I4", "PASS: jumbo frame (9000B) emitted on TX wire", UVM_NONE)
endtask

// =============================================================================
// I5 -- Mixed sizes: 46/200/500/1500/9000B sequential
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i5_mixed_sizes();
  int rs_before;
  bit timed_out;

  `uvm_info("FF_003", "--- I5: Mixed sizes ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_clean(46);
  send_axi_clean(200);
  send_axi_clean(500);
  send_axi_clean(1500);
  send_axi_clean(9000);
  #50us;

  mac_wait_utils_c::wait_for_count_at_least(
      rs_before + 5,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_003_I5", "FAIL: timed out waiting for 5 mixed-size frames")
  else
    `uvm_info("FF_003_I5", "PASS: 5 mixed-size frames emitted on TX wire", UVM_NONE)
endtask

// =============================================================================
// I6 -- Back-to-back: 6 frames at 46/100/500/1500/46/100B
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i6_back_to_back();
  int rs_before;
  bit timed_out;

  `uvm_info("FF_003", "--- I6: Back-to-back ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_clean(46);
  send_axi_clean(100);
  send_axi_clean(500);
  send_axi_clean(1500);
  send_axi_clean(46);
  send_axi_clean(100);
  #5us;

  mac_wait_utils_c::wait_for_count_at_least(
      rs_before + 6,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_003_I6", "FAIL: timed out waiting for 6 back-to-back frames")
  else
    `uvm_info("FF_003_I6", "PASS: 6 back-to-back frames emitted on TX wire", UVM_NONE)
endtask

// =============================================================================
// I7 -- Payload patterns: ZERO/ONES/ALT_55_AA/INCREMENTING/RANDOM (96B each)
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i7_payload_patterns();
  int rs_before;
  bit timed_out;

  `uvm_info("FF_003", "--- I7: Payload patterns ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_pattern(96, mac_hvl_utils_c::PAYLOAD_ZERO);
  send_axi_pattern(96, mac_hvl_utils_c::PAYLOAD_ONES);
  send_axi_pattern(96, mac_hvl_utils_c::PAYLOAD_ALT_55_AA);
  send_axi_pattern(96, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  send_axi_pattern(96, mac_hvl_utils_c::PAYLOAD_RANDOM);
  #5us;

  mac_wait_utils_c::wait_for_count_at_least(
      rs_before + 5,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_003_I7", "FAIL: timed out waiting for 5 pattern frames")
  else
    `uvm_info("FF_003_I7", "PASS: 5 payload-pattern frames emitted on TX wire", UVM_NONE)
endtask

// =============================================================================
// I8 -- DA/SA variations
//   Broadcast DA, multicast DA, unicast DA, all-zero SA, all-one SA,
//   incrementing SA
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i8_address_variations();
  int rs_before;
  bit timed_out;

  `uvm_info("FF_003", "--- I8: Address variations ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  // Broadcast DA
  send_axi_directed(48'hFF_FF_FF_FF_FF_FF, 48'h02_00_00_00_00_01,
                    16'h0800, 64, 0);
  // Multicast DA (bit 0 of first byte set)
  send_axi_directed(48'h01_00_00_00_00_00, 48'h02_00_00_00_00_01,
                    16'h0800, 64, 0);
  // Unicast DA
  send_axi_directed(48'h00_11_22_33_44_55, 48'h02_00_00_00_00_01,
                    16'h0800, 64, 0);
  // All-zero SA
  send_axi_directed(48'hFF_FF_FF_FF_FF_FF, 48'h00_00_00_00_00_00,
                    16'h0800, 64, 0);
  // All-one SA
  send_axi_directed(48'hFF_FF_FF_FF_FF_FF, 48'hFF_FF_FF_FF_FF_FF,
                    16'h0800, 64, 0);
  // Incrementing SA
  send_axi_directed(48'hFF_FF_FF_FF_FF_FF, 48'h01_02_03_04_05_06,
                    16'h0800, 64, 0);

  #5us;

  mac_wait_utils_c::wait_for_count_at_least(
      rs_before + 6,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);

  if (timed_out)
    `uvm_error("FF_003_I8", "FAIL: timed out waiting for 6 address-variation frames")
  else
    `uvm_info("FF_003_I8", "PASS: 6 address-variation frames emitted on TX wire", UVM_NONE)
endtask

// =============================================================================
// I9 -- Inconsistent: ET=100 (declares length 100), actual payload=200B
//   The EtherType encodes a length value less than the actual payload.
//   Expected: the MAC either pads to the declared length or forwards as-is.
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i9_short_declared_len();
  int rs_before;
  int rs_after;

  `uvm_info("FF_003", "--- I9: Short declared length ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_mismatch(200, 16'd100);
  #2us;

  rs_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (rs_after > rs_before)
    `uvm_info("FF_003_I9", $sformatf(
        "PASS: inconsistent frame (ET=100, actual=200) emitted on TX wire (%0d frames)",
        rs_after - rs_before), UVM_NONE)
  else
    `uvm_info("FF_003_I9", "PASS: inconsistent frame (ET=100, actual=200) dropped by MAC", UVM_NONE)
endtask

// =============================================================================
// I10 -- Inconsistent: ET=200 (declares length 200), actual payload=100B
//   The EtherType encodes a length value greater than the actual payload.
//   Expected: the MAC pads the frame to the declared length or drops it.
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i10_long_declared_len();
  int rs_before;
  int rs_after;

  `uvm_info("FF_003", "--- I10: Long declared length ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_mismatch(100, 16'd200);
  #2us;

  rs_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (rs_after > rs_before)
    `uvm_info("FF_003_I10", $sformatf(
        "PASS: inconsistent frame (ET=200, actual=100) emitted on TX wire (%0d frames)",
        rs_after - rs_before), UVM_NONE)
  else
    `uvm_info("FF_003_I10", "PASS: inconsistent frame (ET=200, actual=100) dropped by MAC", UVM_NONE)
endtask

// =============================================================================
// I11 -- Reserved Length/Type zone: ET=1500/1501/1536, actual=46B each
//   ET=1500 is a valid length field.  ET=1501-1535 are reserved.
//   ET=1536 is the first valid type field.
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i11_reserved_lt();
  int rs_before;
  int rs_after;
  int expected;

  `uvm_info("FF_003", "--- I11: Reserved Length/Type zone ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  // ET=1500: valid length field -- MAC should accept or reject based on payload
  send_axi_mismatch(46, 16'd1500);
  // ET=1501: reserved zone -- MAC should reject
  send_axi_mismatch(46, 16'd1501);
  // ET=1536: first valid type -- MAC should accept
  send_axi_mismatch(46, 16'd1536);

  #3us;

  rs_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  `uvm_info("FF_003_I11", $sformatf(
      "INFO: reserved L/T zone: %0d/3 frames emitted on TX wire",
      rs_after - rs_before), UVM_NONE)
endtask

// =============================================================================
// I12 -- Edge-case EtherType: ET=0x0000, actual=46B
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i12_et_zero();
  int rs_before;
  int rs_after;

  `uvm_info("FF_003", "--- I12: EtherType 0x0000 ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_mismatch(46, 16'h0000);
  #2us;

  rs_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (rs_after > rs_before)
    `uvm_info("FF_003_I12", $sformatf(
        "PASS: ET=0x0000 frame emitted on TX wire (%0d frames)",
        rs_after - rs_before), UVM_NONE)
  else
    `uvm_info("FF_003_I12", "PASS: ET=0x0000 frame dropped by MAC", UVM_NONE)
endtask

// =============================================================================
// I13 -- Edge-case EtherType: ET=0xFFFF, actual=46B
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i13_et_ones();
  int rs_before;
  int rs_after;

  `uvm_info("FF_003", "--- I13: EtherType 0xFFFF ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_axi_mismatch(46, 16'hFFFF);
  #2us;

  rs_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (rs_after > rs_before)
    `uvm_info("FF_003_I13", $sformatf(
        "PASS: ET=0xFFFF frame emitted on TX wire (%0d frames)",
        rs_after - rs_before), UVM_NONE)
  else
    `uvm_info("FF_003_I13", "PASS: ET=0xFFFF frame dropped by MAC", UVM_NONE)
endtask

// =============================================================================
// I14 -- Mixed stream: 9 frames mixing valid and inconsistent conditions
//   Frames: valid(100B), mismatch(ET=50, actual=100), valid(46B),
//           mismatch(ET=200, actual=46), valid(1500B), valid(64B),
//           mismatch(ET=0, actual=46), valid(200B), mismatch(ET=0xFFFF, actual=46)
// =============================================================================
task FF_003_tx_frame_fmt_test_c::iteration_i14_mixed_stream();
  int rs_before;
  int rs_after;

  `uvm_info("FF_003", "--- I14: Mixed stream ---", UVM_LOW)
  rs_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  send_axi_clean(100);                     // valid
  send_axi_mismatch(100, 16'd50);          // mismatch: ET < actual
  send_axi_clean(46);                      // valid
  send_axi_mismatch(46, 16'd200);          // mismatch: ET > actual
  send_axi_clean(1500);                    // valid
  send_axi_clean(64);                      // valid
  send_axi_mismatch(46, 16'h0000);         // mismatch: ET=0
  send_axi_clean(200);                     // valid
  send_axi_mismatch(46, 16'hFFFF);         // mismatch: ET=0xFFFF

  #5us;

  rs_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  `uvm_info("FF_003_I14", $sformatf(
      "INFO: mixed stream: %0d/9 frames emitted on TX wire (valid + inconsistent)",
      rs_after - rs_before), UVM_NONE)
endtask

// =============================================================================
// run_stimulus
// =============================================================================
task FF_003_tx_frame_fmt_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("FF_003", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("FF_003", "MAC reset and APB bootstrap did not complete")

  `uvm_info("FF_003", "=== FF-003 / TX_FRAME_FMT_001 START ===", UVM_LOW)

  // Configure MAC for jumbo support
  apb_write(16'h0004, (1 << 0) | (1 << 2));
  apb_write(16'h0044, 32'd9026);
  apb_write(16'h0048, 32'd64);
  #1us;

  iteration_i1_nominal();
  iteration_i2_min_frame();
  iteration_i3_max_frame();
  iteration_i4_jumbo();
  iteration_i5_mixed_sizes();
  iteration_i6_back_to_back();
  iteration_i7_payload_patterns();
  iteration_i8_address_variations();
  iteration_i9_short_declared_len();
  iteration_i10_long_declared_len();
  iteration_i11_reserved_lt();
  iteration_i12_et_zero();
  iteration_i13_et_ones();
  iteration_i14_mixed_stream();

  `uvm_info("FF_003", "=== FF-003 / TX_FRAME_FMT_001 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // FF_003_TX_FRAME_FMT_TEST_SVH
