`ifndef FF_007_RX_DECAP_002_TEST_SVH
`define FF_007_RX_DECAP_002_TEST_SVH

//------------------------------------------------------------------------------
// FF-007 -- RX_DECAP_002 -- Receive Pad Removal and FCS-Pass Mode
//
// Objective: Verify receive decapsulation for Length-formatted frames,
// including pad removal and passReceiveFCSMode behavior.
//
// NOTE: passReceiveFCSMode is NOT implemented in the current RTL.
// client_fcs_present is hardcoded to 1'b0 in rx_frame_emit.v.
// All iterations test normal mode only (pad removed, FCS stripped).
//
// Scenarios / iterations:
//   Length-formatted pad removal (I1-I5):
//     I1  -- Length=100, actual payload=100 (exact match)
//     I2  -- Length=100, actual payload=200 (extra padding stripped)
//     I3  -- Length=46,  actual payload=46  (minimum)
//     I4  -- Length=1500, actual payload=1500 (maximum basic)
//     I5  -- Length=1500, actual payload=2000 (extra padding at max)
//
//   Type-formatted frames (I6-I8):
//     I6  -- Type=0x0800, payload=100 (all payload delivered)
//     I7  -- Type=0x0800, payload=1500
//     I8  -- Type=0x0800, payload=46 (minimum)
//
//   Reserved-gap frames (I9-I10):
//     I9  -- Type=1501 (gap start) -- rejected
//     I10 -- Type=1535 (gap end)   -- rejected
//
//   Length mismatch (I11-I12):
//     I11 -- Length=200, actual payload=100 (payload < declared) -- rejected
//     I12 -- Length=1500, actual payload=100 (payload << declared) -- rejected
//
//   Pattern variations (I13-I14):
//     I13 -- Length=500 with all 8 payload patterns
//     I14 -- Type=0x0800 with all 8 payload patterns
//
//   Mixed stream (I15):
//     I15 -- 3 valid Length + 2 valid Type + 2 reserved gap + 2 mismatch
//            = 5 accepted, 4 rejected
//
//   Edge case (I16):
//     I16 -- Length=0 (zero-length payload)
//
// Verification:
//   Accepted frames: AXI monitor mon_rcvd_xtn_cnt increases by expected delta.
//   Rejected frames: AXI monitor count unchanged (no delivery).
//   Pad removal: implicitly verified by acceptance of Length-formatted frames
//   with extra padding (the DUT strips padding before delivery).
//
// Agent topology:
//   AXI passive -- monitors MA_DATA.indication delivery to client
//   RS  active  -- drives frames into MAC RX path
//   RS  passive -- monitors DUT TX wire
//   APB  active -- station address and config
//------------------------------------------------------------------------------
class FF_007_rx_decap_002_test_c extends mac_base_test_c;
  `uvm_component_utils(FF_007_rx_decap_002_test_c)

  extern function new(string name = "FF_007_rx_decap_002_test_c",
                       uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task send_rx_len_frame(int declared_length, int actual_payload,
                                mac_hvl_utils_c::payload_pattern_e pat =
                                    mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  extern task send_rx_type_frame(int actual_payload,
                                 mac_hvl_utils_c::payload_pattern_e pat =
                                     mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  extern task check_rx(string label, int axi_before, int expected_delta, bit timed_out);
  extern task check_rx_rejected(string label, int axi_before);

  extern task iteration_i1_len_exact();
  extern task iteration_i2_len_extra_pad();
  extern task iteration_i3_len_minimum();
  extern task iteration_i4_len_maximum();
  extern task iteration_i5_len_extra_max();
  extern task iteration_i6_type_100();
  extern task iteration_i7_type_1500();
  extern task iteration_i8_type_minimum();
  extern task iteration_i9_reserved_gap_start();
  extern task iteration_i10_reserved_gap_end();
  extern task iteration_i11_mismatch_short();
  extern task iteration_i12_mismatch_large();
  extern task iteration_i13_len_patterns();
  extern task iteration_i14_type_patterns();
  extern task iteration_i15_mixed_stream();
  extern task iteration_i16_len_zero();
endclass

function FF_007_rx_decap_002_test_c::new(
    string name = "FF_007_rx_decap_002_test_c",
    uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 0;
  num_axi_passive_agents = 1;
  num_rs_active_agents   = 1;
  num_rs_passive_agents  = 1;
endfunction

function void FF_007_rx_decap_002_test_c::configure_test();
  super.configure_test();
  env_cfg_h.max_payload_bytes = 9000;
  env_cfg_h.max_frame_octets  = 9026;
  env_cfg_h.scoreboard_enable_rx_check = 0;
  env_cfg_h.scoreboard_enable_tx_check = 0;
  env_cfg_h.scoreboard_check_error_flags = 0;
  env_cfg_h.has_protocol_checkers = 0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task FF_007_rx_decap_002_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task FF_007_rx_decap_002_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// Helpers
// =============================================================================
task FF_007_rx_decap_002_test_c::send_rx_len_frame(
    int declared_length,
    int actual_payload,
    mac_hvl_utils_c::payload_pattern_e pat);
  rx_frame_field_seq_c seq_h;
  seq_h = rx_frame_field_seq_c::type_id::create("rx_len_drv");
  seq_h.num_frames_to_send = 1;
  seq_h.payload_length     = actual_payload;
  seq_h.dst_addr           = 48'h02_00_00_00_AA_05;
  seq_h.src_addr           = 48'h02_00_00_00_00_01;
  seq_h.ether_type_val     = declared_length;
  seq_h.payload_pattern    = pat;
  seq_h.crc_error          = 0;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_007_rx_decap_002_test_c::send_rx_type_frame(
    int actual_payload,
    mac_hvl_utils_c::payload_pattern_e pat);
  rx_frame_field_seq_c seq_h;
  seq_h = rx_frame_field_seq_c::type_id::create("rx_type_drv");
  seq_h.num_frames_to_send = 1;
  seq_h.payload_length     = actual_payload;
  seq_h.dst_addr           = 48'h02_00_00_00_AA_05;
  seq_h.src_addr           = 48'h02_00_00_00_00_01;
  seq_h.ether_type_val     = 16'h0800;
  seq_h.payload_pattern    = pat;
  seq_h.crc_error          = 0;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_007_rx_decap_002_test_c::check_rx(
    string label, int axi_before, int expected_delta, bit timed_out);
  if (timed_out)
    `uvm_error("FF_007", $sformatf("FAIL %s: timed out (before=%0d expected_delta=%0d)",
               label, axi_before, expected_delta))
  else
    `uvm_info("FF_007", $sformatf("PASS %s", label), UVM_NONE)
endtask

task FF_007_rx_decap_002_test_c::check_rx_rejected(
    string label, int axi_before);
  int axi_after;
  axi_after = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (axi_after == axi_before)
    `uvm_info("FF_007", $sformatf("PASS %s (rejected, no delivery)", label), UVM_NONE)
  else
    `uvm_error("FF_007", $sformatf("FAIL %s: frame was delivered (before=%0d after=%0d)",
               label, axi_before, axi_after))
endtask

// =============================================================================
// I1 -- Length=100, actual payload=100 (exact match)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i1_len_exact();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I1: Length=100, payload=100 (exact) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_len_frame(100, 100);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I1: Length exact match accepted", axi_before, 1, timed_out);
endtask

// =============================================================================
// I2 -- Length=100, actual payload=200 (extra padding stripped)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i2_len_extra_pad();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I2: Length=100, payload=200 (pad stripped) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_len_frame(100, 200);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I2: Length extra-pad accepted (pad stripped)", axi_before, 1, timed_out);
endtask

// =============================================================================
// I3 -- Length=46, actual payload=46 (minimum)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i3_len_minimum();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I3: Length=46, payload=46 (minimum) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_len_frame(46, 46);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I3: Length minimum accepted", axi_before, 1, timed_out);
endtask

// =============================================================================
// I4 -- Length=1500, actual payload=1500 (maximum basic)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i4_len_maximum();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I4: Length=1500, payload=1500 (max basic) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_len_frame(1500, 1500);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I4: Length max basic accepted", axi_before, 1, timed_out);
endtask

// =============================================================================
// I5 -- Length=1500, actual payload=2000 (extra padding at max)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i5_len_extra_max();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I5: Length=1500, payload=2000 (extra at max) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_len_frame(1500, 2000);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I5: Length extra-pad at max accepted", axi_before, 1, timed_out);
endtask

// =============================================================================
// I6 -- Type=0x0800, payload=100
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i6_type_100();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I6: Type=0x0800, payload=100 ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_type_frame(100);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I6: Type 100B accepted", axi_before, 1, timed_out);
endtask

// =============================================================================
// I7 -- Type=0x0800, payload=1500
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i7_type_1500();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I7: Type=0x0800, payload=1500 ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_type_frame(1500);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I7: Type 1500B accepted", axi_before, 1, timed_out);
endtask

// =============================================================================
// I8 -- Type=0x0800, payload=46 (minimum)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i8_type_minimum();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I8: Type=0x0800, payload=46 (min) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_type_frame(46);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I8: Type minimum accepted", axi_before, 1, timed_out);
endtask

// =============================================================================
// I9 -- Reserved gap start: Type=1501 (rejected)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i9_reserved_gap_start();
  int axi_before;

  `uvm_info("FF_007", "--- I9: Reserved gap Type=1501 (rejected) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  begin
    rx_frame_field_seq_c seq_h;
    seq_h = rx_frame_field_seq_c::type_id::create("rx_gap_drv");
    seq_h.num_frames_to_send = 1;
    seq_h.payload_length     = 100;
    seq_h.dst_addr           = 48'h02_00_00_00_AA_05;
    seq_h.src_addr           = 48'h02_00_00_00_00_01;
    seq_h.ether_type_val     = 16'd1501;
    seq_h.payload_pattern    = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
    seq_h.crc_error          = 0;
    seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
  end
  #2us;
  check_rx_rejected("I9: reserved gap 1501 rejected", axi_before);
endtask

// =============================================================================
// I10 -- Reserved gap end: Type=1535 (rejected)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i10_reserved_gap_end();
  int axi_before;

  `uvm_info("FF_007", "--- I10: Reserved gap Type=1535 (rejected) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  begin
    rx_frame_field_seq_c seq_h;
    seq_h = rx_frame_field_seq_c::type_id::create("rx_gap_drv");
    seq_h.num_frames_to_send = 1;
    seq_h.payload_length     = 100;
    seq_h.dst_addr           = 48'h02_00_00_00_AA_05;
    seq_h.src_addr           = 48'h02_00_00_00_00_01;
    seq_h.ether_type_val     = 16'd1535;
    seq_h.payload_pattern    = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
    seq_h.crc_error          = 0;
    seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
  end
  #2us;
  check_rx_rejected("I10: reserved gap 1535 rejected", axi_before);
endtask

// =============================================================================
// I11 -- Length mismatch: Length=200, payload=100 (rejected)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i11_mismatch_short();
  int axi_before;

  `uvm_info("FF_007", "--- I11: Length=200, payload=100 (mismatch) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_len_frame(200, 100);
  #2us;
  check_rx_rejected("I11: length mismatch short rejected", axi_before);
endtask

// =============================================================================
// I12 -- Length mismatch: Length=1500, payload=100 (rejected)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i12_mismatch_large();
  int axi_before;

  `uvm_info("FF_007", "--- I12: Length=1500, payload=100 (large mismatch) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_len_frame(1500, 100);
  #2us;
  check_rx_rejected("I12: length mismatch large rejected", axi_before);
endtask

// =============================================================================
// I13 -- Length=500 with all 8 payload patterns
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i13_len_patterns();
  int axi_before; bit timed_out;
  mac_hvl_utils_c::payload_pattern_e patterns[];

  `uvm_info("FF_007", "--- I13: Length=500 all patterns ---", UVM_LOW)
  patterns = '{
      mac_hvl_utils_c::PAYLOAD_ZERO,
      mac_hvl_utils_c::PAYLOAD_ONES,
      mac_hvl_utils_c::PAYLOAD_ALT_55_AA,
      mac_hvl_utils_c::PAYLOAD_ALT_AA_55,
      mac_hvl_utils_c::PAYLOAD_INCREMENTING,
      mac_hvl_utils_c::PAYLOAD_DECREMENTING,
      mac_hvl_utils_c::PAYLOAD_KNOWN_CRC,
      mac_hvl_utils_c::PAYLOAD_RANDOM
  };

  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  foreach (patterns[i]) begin
    send_rx_len_frame(500, 500, patterns[i]);
    #500ns;
  end
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 8,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I13: Length 500B all 8 patterns accepted", axi_before, 8, timed_out);
endtask

// =============================================================================
// I14 -- Type=0x0800 with all 8 payload patterns
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i14_type_patterns();
  int axi_before; bit timed_out;
  mac_hvl_utils_c::payload_pattern_e patterns[];

  `uvm_info("FF_007", "--- I14: Type=0x0800 all patterns ---", UVM_LOW)
  patterns = '{
      mac_hvl_utils_c::PAYLOAD_ZERO,
      mac_hvl_utils_c::PAYLOAD_ONES,
      mac_hvl_utils_c::PAYLOAD_ALT_55_AA,
      mac_hvl_utils_c::PAYLOAD_ALT_AA_55,
      mac_hvl_utils_c::PAYLOAD_INCREMENTING,
      mac_hvl_utils_c::PAYLOAD_DECREMENTING,
      mac_hvl_utils_c::PAYLOAD_KNOWN_CRC,
      mac_hvl_utils_c::PAYLOAD_RANDOM
  };

  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  foreach (patterns[i]) begin
    send_rx_type_frame(500, patterns[i]);
    #500ns;
  end
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 8,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I14: Type 500B all 8 patterns accepted", axi_before, 8, timed_out);
endtask

// =============================================================================
// I15 -- Mixed stream: 3 valid Length + 2 valid Type + 2 reserved gap + 2 mismatch
//         = 5 accepted, 4 rejected
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i15_mixed_stream();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I15: Mixed stream (9 frames) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  // Valid Length 1: 100B exact
  send_rx_len_frame(100, 100);
  #200ns;
  // Valid Type 1: 1500B
  send_rx_type_frame(1500);
  #200ns;
  // Reserved gap 1: 1501 -- rejected
  begin
    rx_frame_field_seq_c seq_h;
    seq_h = rx_frame_field_seq_c::type_id::create("rx_mixed_drv1");
    seq_h.num_frames_to_send = 1;
    seq_h.payload_length     = 100;
    seq_h.dst_addr           = 48'h02_00_00_00_AA_05;
    seq_h.src_addr           = 48'h02_00_00_00_00_01;
    seq_h.ether_type_val     = 16'd1501;
    seq_h.payload_pattern    = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
    seq_h.crc_error          = 0;
    seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
  end
  #200ns;
  // Valid Length 2: 500B extra pad
  send_rx_len_frame(500, 800);
  #200ns;
  // Mismatch 1: Length=200, payload=50 -- rejected
  send_rx_len_frame(200, 50);
  #200ns;
  // Valid Type 2: 100B
  send_rx_type_frame(100);
  #200ns;
  // Reserved gap 2: 1535 -- rejected
  begin
    rx_frame_field_seq_c seq_h;
    seq_h = rx_frame_field_seq_c::type_id::create("rx_mixed_drv2");
    seq_h.num_frames_to_send = 1;
    seq_h.payload_length     = 100;
    seq_h.dst_addr           = 48'h02_00_00_00_AA_05;
    seq_h.src_addr           = 48'h02_00_00_00_00_01;
    seq_h.ether_type_val     = 16'd1535;
    seq_h.payload_pattern    = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
    seq_h.crc_error          = 0;
    seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
  end
  #200ns;
  // Valid Length 3: 46B minimum
  send_rx_len_frame(46, 46);
  #200ns;
  // Mismatch 2: Length=1500, payload=200 -- rejected
  send_rx_len_frame(1500, 200);
  #1us;

  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 5,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I15: mixed stream 5 accepted 4 rejected", axi_before, 5, timed_out);
endtask

// =============================================================================
// I16 -- Length=0 (zero-length payload edge case)
// =============================================================================
task FF_007_rx_decap_002_test_c::iteration_i16_len_zero();
  int axi_before; bit timed_out;

  `uvm_info("FF_007", "--- I16: Length=0 (zero-length) ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_len_frame(0, 46);
  #1us;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + 1,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  check_rx("I16: Length=0 zero-length accepted", axi_before, 1, timed_out);
endtask

// =============================================================================
// run_stimulus
// =============================================================================
task FF_007_rx_decap_002_test_c::run_stimulus(uvm_phase phase);
  bit [31:0] rdata;

  if (env_h == null || env_h.apb3_agent_top_h == null ||
      env_h.virtual_sequencer_h == null || env_cfg_h.ral_h == null)
    `uvm_fatal("FF_007", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("FF_007", "MAC reset and APB bootstrap did not complete")

  `uvm_info("FF_007", "=== FF-007 / RX_DECAP_002 START ===", UVM_LOW)

  apb_write(reg_map_pkg::REG_MAC_ADDR_LOW,  32'h00_00_AA_05);
  apb_write(reg_map_pkg::REG_MAC_ADDR_HIGH, 32'h00_00_02_00);
  apb_write(reg_map_pkg::group_low_addr(0),  32'h5E00_AA05);
  apb_write(reg_map_pkg::group_high_addr(0), 32'h0001_0100);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0015);
  apb_write(reg_map_pkg::REG_MAX_FRAME_SIZE, 32'h0000_2346);

  apb_read(reg_map_pkg::REG_MAC_ADDR_LOW, rdata);
  `uvm_info("FF_007", $sformatf("Station addr LOW = 0x%h", rdata), UVM_LOW)
  apb_read(reg_map_pkg::REG_MAC_ADDR_HIGH, rdata);
  `uvm_info("FF_007", $sformatf("Station addr HIGH = 0x%h", rdata), UVM_LOW)

  // Length-formatted pad removal (I1-I5)
  iteration_i1_len_exact();
  iteration_i2_len_extra_pad();
  iteration_i3_len_minimum();
  iteration_i4_len_maximum();
  iteration_i5_len_extra_max();

  // Type-formatted frames (I6-I8)
  iteration_i6_type_100();
  iteration_i7_type_1500();
  iteration_i8_type_minimum();

  // Reserved-gap frames (I9-I10)
  iteration_i9_reserved_gap_start();
  iteration_i10_reserved_gap_end();

  // Length mismatch (I11-I12)
  iteration_i11_mismatch_short();
  iteration_i12_mismatch_large();

  // Pattern variations (I13-I14)
  iteration_i13_len_patterns();
  iteration_i14_type_patterns();

  // Mixed stream (I15)
  iteration_i15_mixed_stream();

  // Edge case (I16)
  iteration_i16_len_zero();

  `uvm_info("FF_007", "=== FF-007 / RX_DECAP_002 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // FF_007_RX_DECAP_002_TEST_SVH
