`ifndef FF_009_RX_FLOW_003_TEST_SVH
`define FF_009_RX_FLOW_003_TEST_SVH

class FF_009_rx_flow_003_test_c extends mac_base_test_c;
  `uvm_component_utils(FF_009_rx_flow_003_test_c)

  extern function new(string name = "FF_009_rx_flow_003_test_c",
                       uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task send_rx(bit [47:0] da, int payload_bytes,
                      mac_hvl_utils_c::payload_pattern_e pat =
                          mac_hvl_utils_c::PAYLOAD_INCREMENTING,
                      bit [47:0] sa = 48'h02_00_00_00_00_02,
                      bit [15:0] et = 16'h0800);
  extern task send_rx_err(bit [47:0] da, int payload_bytes,
                          bit [47:0] sa = 48'h02_00_00_00_00_02,
                          bit [15:0] et = 16'h0800);

  extern task check_axi_plus(string label, int axi_before, int expected);
  extern task check_axi_unchanged(string label, int axi_before);

  extern task iter_i1();
  extern task iter_i2();
  extern task iter_i3();
  extern task iter_i4();
  extern task iter_i5();
  extern task iter_i6();
  extern task iter_i7();
  extern task iter_i8();
  extern task iter_i9();
  extern task iter_i10();
  extern task iter_i11();
  extern task iter_i12();
  extern task iter_i13();
  extern task iter_i14();
  extern task iter_i15();
  extern task iter_i16();
endclass

function FF_009_rx_flow_003_test_c::new(
    string name = "FF_009_rx_flow_003_test_c",
    uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 0;
  num_axi_passive_agents = 1;
  num_rs_active_agents   = 1;
  num_rs_passive_agents  = 0;
endfunction

function void FF_009_rx_flow_003_test_c::configure_test();
  super.configure_test();
  env_cfg_h.max_payload_bytes = 9000;
  env_cfg_h.max_frame_octets  = 9026;
  env_cfg_h.scoreboard_enable_rx_check = 0;
  env_cfg_h.scoreboard_enable_tx_check = 0;
  env_cfg_h.scoreboard_check_error_flags = 0;
  env_cfg_h.has_protocol_checkers = 1;
endfunction

task FF_009_rx_flow_003_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task FF_009_rx_flow_003_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

task FF_009_rx_flow_003_test_c::send_rx(
    bit [47:0] da, int payload_bytes,
    mac_hvl_utils_c::payload_pattern_e pat,
    bit [47:0] sa, bit [15:0] et);
  rx_frame_field_seq_c seq_h;
  seq_h = rx_frame_field_seq_c::type_id::create("rx_drv");
  seq_h.num_frames_to_send = 1;
  seq_h.payload_length     = payload_bytes;
  seq_h.dst_addr           = da;
  seq_h.src_addr           = sa;
  seq_h.ether_type_val     = et;
  seq_h.insert_fcs         = 1'b1;
  seq_h.crc_error          = 1'b0;
  seq_h.payload_pattern    = pat;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_009_rx_flow_003_test_c::send_rx_err(
    bit [47:0] da, int payload_bytes,
    bit [47:0] sa, bit [15:0] et);
  rx_frame_field_seq_c seq_h;
  seq_h = rx_frame_field_seq_c::type_id::create("rx_err");
  seq_h.num_frames_to_send = 1;
  seq_h.payload_length     = payload_bytes;
  seq_h.dst_addr           = da;
  seq_h.src_addr           = sa;
  seq_h.ether_type_val     = et;
  seq_h.insert_fcs         = 1'b1;
  seq_h.crc_error          = 1'b1;
  seq_h.payload_pattern    = mac_hvl_utils_c::PAYLOAD_INCREMENTING;
  seq_h.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
endtask

task FF_009_rx_flow_003_test_c::check_axi_plus(
    string label, int axi_before, int expected);
  bit timed_out;
  mac_wait_utils_c::wait_for_axi_count_at_least(
      axi_before + expected,
      env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      axi_rx_vif, MAC_COMPLETION_TIMEOUT_NS, timed_out);
  if (timed_out)
    `uvm_error("FF_009", $sformatf("FAIL %s: delivery timeout (before=%0d expected_delta=%0d)",
               label, axi_before, expected))
  else
    `uvm_info("FF_009", $sformatf("PASS %s: AXI count +%0d", label, expected), UVM_NONE)
endtask

task FF_009_rx_flow_003_test_c::check_axi_unchanged(
    string label, int axi_before);
  int current;
  #2us;
  current = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (current == axi_before)
    `uvm_info("FF_009", $sformatf("PASS %s: not delivered (correct)", label), UVM_NONE)
  else
    `uvm_error("FF_009", $sformatf("FAIL %s: delivered unexpectedly (before=%0d now=%0d)",
               label, axi_before, current))
endtask

task FF_009_rx_flow_003_test_c::iter_i1();
  int axi_before;
  `uvm_info("FF_009", "--- I1: Local DA, incrementing, 200B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 200, mac_hvl_utils_c::PAYLOAD_INCREMENTING);
  check_axi_plus("I1", axi_before, 1);
endtask

task FF_009_rx_flow_003_test_c::iter_i2();
  int axi_before;
  `uvm_info("FF_009", "--- I2: Broadcast DA, ones, 100B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'hFF_FF_FF_FF_FF_FF, 100, mac_hvl_utils_c::PAYLOAD_ONES);
  check_axi_plus("I2", axi_before, 1);
endtask

task FF_009_rx_flow_003_test_c::iter_i3();
  int axi_before;
  `uvm_info("FF_009", "--- I3: Multicast DA, alternating, 150B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h01_00_5E_00_AA_05, 150, mac_hvl_utils_c::PAYLOAD_ALT_55_AA);
  check_axi_plus("I3", axi_before, 1);
endtask

task FF_009_rx_flow_003_test_c::iter_i4();
  int axi_before;
  `uvm_info("FF_009", "--- I4: Local DA, random, 1500B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 1500, mac_hvl_utils_c::PAYLOAD_RANDOM);
  check_axi_plus("I4", axi_before, 1);
endtask

task FF_009_rx_flow_003_test_c::iter_i5();
  int axi_before;
  `uvm_info("FF_009", "--- I5: Local DA, zero, 46B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 46, mac_hvl_utils_c::PAYLOAD_ZERO);
  check_axi_plus("I5", axi_before, 1);
endtask

task FF_009_rx_flow_003_test_c::iter_i6();
  int axi_before;
  `uvm_info("FF_009", "--- I6: Local DA, ones, 200B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 200, mac_hvl_utils_c::PAYLOAD_ONES);
  check_axi_plus("I6", axi_before, 1);
endtask

task FF_009_rx_flow_003_test_c::iter_i7();
  int axi_before;
  `uvm_info("FF_009", "--- I7: Local DA, alt_55_aa, 200B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 200, mac_hvl_utils_c::PAYLOAD_ALT_55_AA);
  check_axi_plus("I7", axi_before, 1);
endtask

task FF_009_rx_flow_003_test_c::iter_i8();
  int axi_before;
  `uvm_info("FF_009", "--- I8: Local DA, random, 1000B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 1000, mac_hvl_utils_c::PAYLOAD_RANDOM);
  check_axi_plus("I8", axi_before, 1);
endtask

task FF_009_rx_flow_003_test_c::iter_i9();
  int axi_before;
  `uvm_info("FF_009", "--- I9: Local DA, CRC error, 200B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_err(48'h02_00_00_00_00_01, 200);
  check_axi_unchanged("I9", axi_before);
endtask

task FF_009_rx_flow_003_test_c::iter_i10();
  int axi_before;
  `uvm_info("FF_009", "--- I10: Broadcast DA, CRC error, 100B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx_err(48'hFF_FF_FF_FF_FF_FF, 100);
  check_axi_unchanged("I10", axi_before);
endtask

task FF_009_rx_flow_003_test_c::iter_i11();
  int axi_before;
  `uvm_info("FF_009", "--- I11: Unrelated unicast DA, 200B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'hDE_AD_BE_EF_00_01, 200);
  check_axi_unchanged("I11", axi_before);
endtask

task FF_009_rx_flow_003_test_c::iter_i12();
  int axi_before;
  `uvm_info("FF_009", "--- I12: Near-miss DA, 200B ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_00, 200);
  check_axi_unchanged("I12", axi_before);
endtask

task FF_009_rx_flow_003_test_c::iter_i13();
  int axi_before;
  `uvm_info("FF_009", "--- I13: Back-to-back 8 mixed ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 200);  #200ns;
  send_rx(48'hFF_FF_FF_FF_FF_FF, 100);  #200ns;
  send_rx(48'h01_00_5E_00_AA_05, 150);  #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 100); #200ns;
  send_rx(48'hDE_AD_BE_EF_00_01, 200);  #200ns;
  send_rx(48'h02_00_00_00_00_01, 46);   #200ns;
  send_rx(48'hFF_FF_FF_FF_FF_FF, 1500); #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 200);
  check_axi_plus("I13", axi_before, 5);
endtask

task FF_009_rx_flow_003_test_c::iter_i14();
  int axi_before;
  `uvm_info("FF_009", "--- I14: 10 alternating valid/invalid ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 200);  #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 200); #200ns;
  send_rx(48'h02_00_00_00_00_01, 200);  #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 200); #200ns;
  send_rx(48'h02_00_00_00_00_01, 200);  #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 200); #200ns;
  send_rx(48'h02_00_00_00_00_01, 200);  #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 200); #200ns;
  send_rx(48'h02_00_00_00_00_01, 200);  #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 200);
  check_axi_plus("I14", axi_before, 5);
endtask

task FF_009_rx_flow_003_test_c::iter_i15();
  int axi_before;
  mac_hvl_utils_c::payload_pattern_e patterns[];
  `uvm_info("FF_009", "--- I15: 8 patterns, local DA ---", UVM_LOW)
  patterns = '{
      mac_hvl_utils_c::PAYLOAD_ZERO,
      mac_hvl_utils_c::PAYLOAD_ONES,
      mac_hvl_utils_c::PAYLOAD_ALT_55_AA,
      mac_hvl_utils_c::PAYLOAD_ALT_AA_55,
      mac_hvl_utils_c::PAYLOAD_INCREMENTING,
      mac_hvl_utils_c::PAYLOAD_DECREMENTING,
      mac_hvl_utils_c::PAYLOAD_KNOWN_CRC,
      mac_hvl_utils_c::PAYLOAD_RANDOM
  };
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  foreach (patterns[i]) begin
    send_rx(48'h02_00_00_00_00_01, 200, patterns[i]);
    #200ns;
  end
  check_axi_plus("I15", axi_before, 8);
endtask

task FF_009_rx_flow_003_test_c::iter_i16();
  int axi_before;
  `uvm_info("FF_009", "--- I16: Mixed DA/SA/ET/pattern/size ---", UVM_LOW)
  axi_before = env_h.axi4_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_rx(48'h02_00_00_00_00_01, 64,   mac_hvl_utils_c::PAYLOAD_ZERO,
          48'h02_00_00_00_00_02, 16'h0800); #200ns;
  send_rx(48'hFF_FF_FF_FF_FF_FF, 1500, mac_hvl_utils_c::PAYLOAD_ONES,
          48'h02_00_00_00_00_03, 16'h0800); #200ns;
  send_rx(48'h01_00_5E_00_AA_05, 200,  mac_hvl_utils_c::PAYLOAD_ALT_55_AA,
          48'h02_00_00_00_00_04, 16'h0800); #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 200,
              48'h02_00_00_00_00_05, 16'h0800); #200ns;
  send_rx(48'hDE_AD_BE_EF_00_01, 100,  mac_hvl_utils_c::PAYLOAD_INCREMENTING,
          48'h02_00_00_00_00_06, 16'h0800); #200ns;
  send_rx(48'h02_00_00_00_00_01, 46,   mac_hvl_utils_c::PAYLOAD_RANDOM,
          48'h02_00_00_00_00_07, 16'h0800); #200ns;
  send_rx(48'h02_00_00_00_00_01, 1000, mac_hvl_utils_c::PAYLOAD_DECREMENTING,
          48'h02_00_00_00_00_08, 16'h0800); #200ns;
  send_rx_err(48'h02_00_00_00_00_01, 100,
              48'h02_00_00_00_00_09, 16'h0800);
  check_axi_plus("I16", axi_before, 5);
endtask

task FF_009_rx_flow_003_test_c::run_stimulus(uvm_phase phase);
  bit [31:0] rdata;
  if (env_h == null || env_h.apb3_agent_top_h == null ||
      env_h.virtual_sequencer_h == null || env_cfg_h.ral_h == null)
    `uvm_fatal("FF_009", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("FF_009", "MAC reset and APB bootstrap did not complete")

  `uvm_info("FF_009", "=== FF-009 / RX_FLOW_003 START ===", UVM_LOW)

  apb_write(reg_map_pkg::REG_MAC_ADDR_LOW,  32'h00_00_00_01);
  apb_write(reg_map_pkg::REG_MAC_ADDR_HIGH, 32'h00_00_02_00);
  apb_write(reg_map_pkg::group_low_addr(0),  32'h5E00_AA05);
  apb_write(reg_map_pkg::group_high_addr(0), 32'h0001_0100);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, 32'h0000_0015);
  apb_write(reg_map_pkg::REG_MAX_FRAME_SIZE, 32'h0000_2346);

  apb_read(reg_map_pkg::REG_MAC_ADDR_LOW, rdata);
  `uvm_info("FF_009", $sformatf("Station addr LOW  = 0x%h", rdata), UVM_LOW)
  apb_read(reg_map_pkg::REG_MAC_ADDR_HIGH, rdata);
  `uvm_info("FF_009", $sformatf("Station addr HIGH = 0x%h", rdata), UVM_LOW)

  iter_i1();
  iter_i2();
  iter_i3();
  iter_i4();
  iter_i5();
  iter_i6();
  iter_i7();
  iter_i8();
  iter_i9();
  iter_i10();
  iter_i11();
  iter_i12();
  iter_i13();
  iter_i14();
  iter_i15();
  iter_i16();

  `uvm_info("FF_009", "=== FF-009 / RX_FLOW_003 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif
