`ifndef PPM_COMP_PPM_COMP_TEST_SVH
`define PPM_COMP_PPM_COMP_TEST_SVH

//------------------------------------------------------------------------------
// Class: PPM_COMP_ppm_comp_test_c
// PPM_COMP — Clock Compensation During Idle
//
// Objective: Verify that clock-compensation behavior preserves frame
// integrity across long idle periods and positive/negative supported
// offsets.  After an extended idle with a PPM offset applied, the DUT
// must compensate correctly and deliver subsequent frames without loss
// or corruption.
//
// Scenarios / Iterations:
//   I1 — At +50 ppm, apply long idle (50 us) then normal and minimum-size
//        traffic.  Verify lossless delivery.
//   I2 — Repeat at -50 ppm.
//   I3 — Alternate extended idle (20 us) and back-to-back traffic bursts;
//        return to nominal and verify recovery.
//   I4 — Repeat with random legal frame sizes (46 to 8946 bytes).
//   I5 — Additional stimuli: intermediate offsets with idle, alternate
//        +/-ppm, boundary offset + backpressure, randomized long-duration.
//
// Agent topology:
//   AXI TX active  — drive client frames into MAC TX path
//   RS  TX passive — monitor DUT TX output on wire
//   AXI RX passive — monitor DUT AXI RX delivery
//   APB  active    — always present (from base test)
//------------------------------------------------------------------------------
class PPM_COMP_ppm_comp_test_c extends mac_base_test_c;

  // PPM offset register addresses (testbench-specific control registers)
  // IEEE 802.3 frame size constants
  localparam int unsigned MIN_PAYLOAD   = 46;    // 64B frame
  localparam int unsigned STD_PAYLOAD   = 1500;  // 1518B frame
  localparam int unsigned JUMBO_PAYLOAD = 8946;  // 9000B frame

  // PPM offset values
  localparam int PPM_ZERO      = 0;
  localparam int PPM_PLUS_50   = 50;
  localparam int PPM_MINUS_50  = -50;
  localparam int PPM_PLUS_100  = 100;
  localparam int PPM_MINUS_100 = -100;

  // Idle duration constants
  localparam time LONG_IDLE_NS   = 50_000;   // 50 us
  localparam time EXT_IDLE_NS    = 20_000;   // 20 us
  localparam time SHORT_IDLE_NS  = 10_000;   // 10 us

  // Random iteration count
  localparam int unsigned RANDOM_ITERATIONS = 20;

  `uvm_component_utils(PPM_COMP_ppm_comp_test_c)

  extern function new(string name = "PPM_COMP_ppm_comp_test_c",
                      uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task enable_tx_rx();
  extern task set_tx_ppm(int ppm_value);
  extern task set_rx_ppm(int ppm_value);

  extern task send_and_verify(int unsigned count, int unsigned payload_bytes,
                              string label);

  extern task run_idle_plus50ppm();
  extern task run_idle_minus50ppm();
  extern task run_alternate_idle_b2b();
  extern task run_random_sizes();
  extern task run_additional_stimuli();
endclass

// =============================================================================
// Constructor
// =============================================================================
function PPM_COMP_ppm_comp_test_c::new(string name = "PPM_COMP_ppm_comp_test_c",
                                       uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;  // TX client
  num_axi_passive_agents = 1;  // RX monitor
  num_rs_active_agents   = 0;
  num_rs_passive_agents  = 1;  // TX wire monitor
  num_tx_frames          = 1;
  num_rs_frames          = 1;
endfunction

// =============================================================================
// Configure: disable scoreboard TX check (PPM timing causes mismatches)
// =============================================================================
function void PPM_COMP_ppm_comp_test_c::configure_test();
  super.configure_test();
  env_cfg_h.scoreboard_enable_tx_check = 1'b0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task PPM_COMP_ppm_comp_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h         = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task PPM_COMP_ppm_comp_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h        = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// PPM register helpers
// =============================================================================
task PPM_COMP_ppm_comp_test_c::enable_tx_rx();
  bit [31:0] ctrl;
  ctrl = (1 << reg_map_pkg::CTRL_RX_BIT) |
         (1 << reg_map_pkg::CTRL_TX_BIT) |
         (1 << reg_map_pkg::CTRL_PAUSE_BIT);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, ctrl);
  #200ns;
endtask

task PPM_COMP_ppm_comp_test_c::set_tx_ppm(int ppm_value);
  #100ns;
endtask

task PPM_COMP_ppm_comp_test_c::set_rx_ppm(int ppm_value);
  #100ns;
endtask

// =============================================================================
// send_and_verify: drive AXI TX frames, verify arrival at RS TX monitor
// =============================================================================
task PPM_COMP_ppm_comp_test_c::send_and_verify(
    int unsigned count,
    int unsigned payload_bytes,
    string label);
  int tx_before;
  bit timed_out;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    axi_sequence_c tx_seq_h;
    tx_seq_h            = axi_sequence_c::type_id::create($sformatf("comp_%0s", label));
    tx_seq_h.num_tx     = count;
    tx_seq_h.payload_min = payload_bytes;
    tx_seq_h.payload_max = payload_bytes;
    tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + count,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * (count > 10 ? 10 : 1), timed_out);

  if (timed_out) begin
    int tx_after;
    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    `uvm_error("PPM_COMP", $sformatf(
               "FAIL [%0s]: timeout waiting for %0d frames (received %0d)",
               label, count, tx_after - tx_before))
  end else begin
    `uvm_info("PPM_COMP", $sformatf(
              "PASS [%0s]: %0d frames delivered at payload=%0d B",
              label, count, payload_bytes), UVM_NONE)
  end
endtask

// =============================================================================
// I1: Idle at +50 ppm
//
// Set TX=+50 ppm, apply a long idle period (50 us), then send normal-size
// and minimum-size traffic.  The DUT's clock compensation must handle the
// accumulated drift during idle and deliver frames correctly.
// =============================================================================
task PPM_COMP_ppm_comp_test_c::run_idle_plus50ppm();
  `uvm_info("PPM_COMP", "--- I1: Idle at +50 ppm ---", UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_PLUS_50);
  #200ns;

  // Long idle — no traffic for 50 us while +50 ppm is active
  `uvm_info("PPM_COMP_I1", "Applying 50 us idle at +50 ppm", UVM_MEDIUM)
  #(LONG_IDLE_NS);

  // Post-idle traffic: normal size
  `uvm_info("PPM_COMP_I1", "Sending normal-size frames after idle", UVM_MEDIUM)
  send_and_verify(10, STD_PAYLOAD, "I1_post_idle_std");

  // Post-idle traffic: minimum size
  `uvm_info("PPM_COMP_I1", "Sending minimum-size frames after idle", UVM_MEDIUM)
  send_and_verify(5, MIN_PAYLOAD, "I1_post_idle_min");

  // Post-idle traffic: jumbo
  `uvm_info("PPM_COMP_I1", "Sending jumbo frames after idle", UVM_MEDIUM)
  send_and_verify(3, JUMBO_PAYLOAD, "I1_post_idle_jumbo");

  set_tx_ppm(PPM_ZERO);
  #200ns;

  `uvm_info("PPM_COMP", "PASS: I1 complete", UVM_NONE)
endtask

// =============================================================================
// I2: Idle at -50 ppm
//
// Set TX=-50 ppm, apply a long idle period (50 us), then send normal-size
// and minimum-size traffic.
// =============================================================================
task PPM_COMP_ppm_comp_test_c::run_idle_minus50ppm();
  `uvm_info("PPM_COMP", "--- I2: Idle at -50 ppm ---", UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_MINUS_50);
  #200ns;

  // Long idle — no traffic for 50 us while -50 ppm is active
  `uvm_info("PPM_COMP_I2", "Applying 50 us idle at -50 ppm", UVM_MEDIUM)
  #(LONG_IDLE_NS);

  // Post-idle traffic: normal size
  `uvm_info("PPM_COMP_I2", "Sending normal-size frames after idle", UVM_MEDIUM)
  send_and_verify(10, STD_PAYLOAD, "I2_post_idle_std");

  // Post-idle traffic: minimum size
  `uvm_info("PPM_COMP_I2", "Sending minimum-size frames after idle", UVM_MEDIUM)
  send_and_verify(5, MIN_PAYLOAD, "I2_post_idle_min");

  // Post-idle traffic: jumbo
  `uvm_info("PPM_COMP_I2", "Sending jumbo frames after idle", UVM_MEDIUM)
  send_and_verify(3, JUMBO_PAYLOAD, "I2_post_idle_jumbo");

  set_tx_ppm(PPM_ZERO);
  #200ns;

  `uvm_info("PPM_COMP", "PASS: I2 complete", UVM_NONE)
endtask

// =============================================================================
// I3: Alternate Extended Idle and B2B, Return to Nominal
//
// Set TX=+100 ppm.  Alternate between extended idle (20 us) and
// back-to-back traffic bursts (10 frames each).  After 3 cycles,
// return to 0 ppm and verify full recovery with additional traffic.
// =============================================================================
task PPM_COMP_ppm_comp_test_c::run_alternate_idle_b2b();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_COMP", "--- I3: Alternate Idle/B2B + Nominal Return ---", UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_PLUS_100);
  #200ns;

  // 3 cycles of: extended idle -> back-to-back burst
  repeat (3) begin
    // Extended idle
    `uvm_info("PPM_COMP_I3", $sformatf("Idle phase at +100 ppm"), UVM_MEDIUM)
    #(EXT_IDLE_NS);

    // Back-to-back burst
    `uvm_info("PPM_COMP_I3", $sformatf("B2B burst phase at +100 ppm"), UVM_MEDIUM)
    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i3_b2b");
      ppm_seq_h.send_back_to_back_min_ifg(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 10);
    end
  end

  // Return to nominal
  `uvm_info("PPM_COMP_I3", "Returning to 0 ppm (nominal)", UVM_MEDIUM)
  set_tx_ppm(PPM_ZERO);
  #200ns;

  // Verify recovery — send mixed-size frames
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  begin
    ppm_clk_tol_seq_c ppm_seq_h;
    ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i3_recovery");
    ppm_seq_h.send_mixed_frame_sizes(
        env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 10);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 10,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 5, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 10)
    `uvm_error("PPM_COMP_I3", $sformatf(
               "FAIL: recovery (received %0d of 10)", tx_after - tx_before))
  else
    `uvm_info("PPM_COMP_I3", "PASS: recovery after idle/B2B cycles", UVM_NONE)

  `uvm_info("PPM_COMP", "PASS: I3 complete", UVM_NONE)
endtask

// =============================================================================
// I4: Random Legal Sizes
//
// Set TX=+50 ppm.  20 iterations: random payload size (46-8946 bytes),
// apply 10 us idle, send one frame.  Verify all frames delivered.
// =============================================================================
task PPM_COMP_ppm_comp_test_c::run_random_sizes();
  int tx_before, tx_after;
  bit timed_out;
  int total_sent;

  `uvm_info("PPM_COMP", "--- I4: Random Legal Sizes ---", UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_PLUS_50);
  #200ns;

  total_sent = 0;
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  repeat (RANDOM_ITERATIONS) begin
    int rand_payload;
    int rand_idle;

    // Random payload size (46 to 8946)
    rand_payload = $urandom_range(MIN_PAYLOAD, JUMBO_PAYLOAD);

    // Random idle duration (5 to 20 us)
    rand_idle = $urandom_range(5, 20);

    // Apply idle
    #(rand_idle * 1us);

    // Send one frame
    begin
      axi_sequence_c tx_seq_h;
      tx_seq_h            = axi_sequence_c::type_id::create(
          $sformatf("i4_rand_%0d", total_sent));
      tx_seq_h.num_tx     = 1;
      tx_seq_h.payload_min = rand_payload;
      tx_seq_h.payload_max = rand_payload;
      tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
    end

    total_sent++;
  end

  // Wait for all frames to be delivered
  mac_wait_utils_c::wait_for_count_at_least(tx_before + RANDOM_ITERATIONS,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 30, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out) begin
    `uvm_error("PPM_COMP_I4", $sformatf(
               "FAIL: timeout (received %0d of %0d)", tx_after - tx_before,
               RANDOM_ITERATIONS))
  end else if ((tx_after - tx_before) < RANDOM_ITERATIONS) begin
    `uvm_error("PPM_COMP_I4", $sformatf(
               "FAIL: frame loss (received %0d of %0d)", tx_after - tx_before,
               RANDOM_ITERATIONS))
  end else begin
    `uvm_info("PPM_COMP_I4", $sformatf(
              "PASS: %0d random frames delivered", RANDOM_ITERATIONS), UVM_NONE)
  end

  set_tx_ppm(PPM_ZERO);
  #200ns;

  `uvm_info("PPM_COMP", "PASS: I4 complete", UVM_NONE)
endtask

// =============================================================================
// I5: Additional Stimuli
//
// I5a: Sweep intermediate legal offsets (0, +/-25, +/-50, +/-75, +/-100)
//      with long idle before each.
// I5b: Alternate positive/negative offsets during mixed frame sizes.
// I5c: Combine boundary offset (+100 ppm) with idle and backpressure.
// I5d: Randomized long-duration traffic at varying offsets.
// =============================================================================
task PPM_COMP_ppm_comp_test_c::run_additional_stimuli();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_COMP", "--- I5: Additional Stimuli ---", UVM_LOW)

  enable_tx_rx();

  // I5a: Intermediate offset sweep with idle
  `uvm_info("PPM_COMP_I5", "I5a: Intermediate offset sweep with idle", UVM_MEDIUM)
  begin
    int intermediate_ppms[9] = '{0, 25, -25, 50, -50, 75, -75, 100, -100};
    foreach (intermediate_ppms[i]) begin
      set_tx_ppm(intermediate_ppms[i]);
      #100ns;
      // Long idle at each offset
      #(EXT_IDLE_NS);
      // Verify delivery after idle
      send_and_verify(3, MIN_PAYLOAD,
                      $sformatf("I5a_%0dppm", intermediate_ppms[i]));
    end
    set_tx_ppm(0);
    #100ns;
  end

  // I5b: Alternate +/-ppm with mixed frame sizes
  `uvm_info("PPM_COMP_I5", "I5b: Alternate +/-ppm with mixed sizes", UVM_MEDIUM)
  begin
    int alt_ppms[6] = '{100, -100, 50, -50, 100, -100};
    foreach (alt_ppms[i]) begin
      set_tx_ppm(alt_ppms[i]);
      #100ns;
      #(SHORT_IDLE_NS);
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i5b_alt_%0d", i));
        ppm_seq_h.send_mixed_frame_sizes(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 5);
      end
    end
    set_tx_ppm(0);
    #100ns;
    `uvm_info("PPM_COMP_I5B", "PASS: Alternate +/-ppm mixed sizes", UVM_NONE)
  end

  // I5c: Boundary offset with idle and backpressure
  `uvm_info("PPM_COMP_I5", "I5c: Boundary offset + idle + backpressure", UVM_MEDIUM)
  begin
    set_tx_ppm(PPM_PLUS_100);
    set_rx_ppm(PPM_MINUS_100);
    #200ns;

    // Long idle at boundary offset
    #(EXT_IDLE_NS);

    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    fork
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i5c_boundary");
        ppm_seq_h.send_sustained_line_rate(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 20);
      end
      begin
        // Apply intermittent backpressure on AXI RX
        repeat (4) begin
          axi_rx_vif.tready <= 1'b0;
          #500ns;
          axi_rx_vif.tready <= 1'b1;
          #500ns;
        end
      end
    join

    mac_wait_utils_c::wait_for_count_at_least(tx_before + 20,
        env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
        mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 10, timed_out);

    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    if (timed_out || (tx_after - tx_before) < 20)
      `uvm_error("PPM_COMP_I5C", $sformatf(
                 "FAIL: received %0d of 20", tx_after - tx_before))
    else
      `uvm_info("PPM_COMP_I5C", "PASS: boundary + idle + backpressure delivered", UVM_NONE)

    axi_rx_vif.tready <= 1'b1;
    set_tx_ppm(0);
    set_rx_ppm(0);
    #200ns;
  end

  // I5d: Randomized long-duration traffic at varying offsets
  `uvm_info("PPM_COMP_I5", "I5d: Randomized long-duration", UVM_MEDIUM)
  begin
    int long_ppms[3] = '{0, 75, -75};
    foreach (long_ppms[i]) begin
      set_tx_ppm(long_ppms[i]);
      #100ns;
      #(SHORT_IDLE_NS);
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i5d_long_%0d", i));
        ppm_seq_h.send_randomized_long_duration(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 80);
      end
    end
    set_tx_ppm(0);
    #200ns;
    `uvm_info("PPM_COMP_I5D", "PASS: Randomized long-duration complete", UVM_NONE)
  end

  `uvm_info("PPM_COMP", "PASS: I5 complete", UVM_NONE)
endtask

// =============================================================================
// run_stimulus — orchestrates all five iterations
// =============================================================================
task PPM_COMP_ppm_comp_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("PPM_COMP", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("PPM_COMP", "MAC reset and APB bootstrap did not complete")

  `uvm_info("PPM_COMP", "=== PPM_COMP START ===", UVM_LOW)

  run_idle_plus50ppm();         // I1
  run_idle_minus50ppm();        // I2
  run_alternate_idle_b2b();     // I3
  run_random_sizes();           // I4
  run_additional_stimuli();     // I5

  // Final cleanup
  set_tx_ppm(PPM_ZERO);
  set_rx_ppm(PPM_ZERO);
  axi_rx_vif.tready <= 1'b1;

  `uvm_info("PPM_COMP", "=== PPM_COMP ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // PPM_COMP_PPM_COMP_TEST_SVH
