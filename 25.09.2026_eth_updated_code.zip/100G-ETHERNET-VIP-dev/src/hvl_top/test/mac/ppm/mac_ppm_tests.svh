`ifndef MAC_PPM_TESTS_SVH
`define MAC_PPM_TESTS_SVH

`include "PPM_001.sv"
`include "PPM_FIFO_001.sv"
`include "PPM_CFG_001.sv"
`include "PPM_COMP.sv"
`include "PPM_SOAK_002.sv"

`endif
