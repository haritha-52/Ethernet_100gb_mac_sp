`ifndef PPM_CFG_001_PPM_CFG_TEST_SVH
`define PPM_CFG_001_PPM_CFG_TEST_SVH

//------------------------------------------------------------------------------
// Class: PPM_CFG_001_ppm_cfg_test_c
// PPM_CFG_001 — PPM Clock Configuration and Recovery
//
// Objective: Verify observable clock-offset configuration, supported-range
// retention, unsupported-request handling, and return-to-nominal recovery
// through the available clock-control mechanism.
//
// Scenarios / Iterations:
//   I1 — Legal offset configuration: request +/-20, +/-50, and +/-100 ppm.
//        Verify status reflects the configured offset and frames are
//        delivered losslessly at each setting.
//   I2 — Return to nominal recovery: set +/-100 ppm, confirm operation,
//        then return to 0 ppm and send normal + minimum-size traffic.
//   I3 — Rapid switching: alternate between legal offsets at high rate
//        while streaming frames.  Verify no frame loss.
//   I4 — Unsupported rejection with active traffic: request +/-150 and
//        +/-200 ppm while frames are in flight.  Verify the DUT rejects
//        or clamps the value and traffic completes without corruption.
//   I5 — Random legal requests: randomly select legal offsets, frame
//        sizes, and timing.  Verify delivery across 100 iterations.
//   I6 — Additional stimuli: intermediate offset sweep, alternate +/-ppm
//        with mixed frames, boundary offset + backpressure, randomized
//        long-duration traffic.
//
// Agent topology:
//   AXI TX active  — drive client frames into MAC TX path
//   RS  TX passive — monitor DUT TX output on wire
//   AXI RX passive — monitor DUT AXI RX delivery
//   APB  active    — always present (from base test)
//------------------------------------------------------------------------------
class PPM_CFG_001_ppm_cfg_test_c extends mac_base_test_c;

  // IEEE 802.3 frame size constants
  localparam int unsigned MIN_PAYLOAD   = 46;    // 64B frame
  localparam int unsigned STD_PAYLOAD   = 1500;  // 1518B frame
  localparam int unsigned JUMBO_PAYLOAD = 8946;  // 9000B frame

  // PPM offset values
  localparam int PPM_ZERO      = 0;
  localparam int PPM_PLUS_20   = 20;
  localparam int PPM_MINUS_20  = -20;
  localparam int PPM_PLUS_50   = 50;
  localparam int PPM_MINUS_50  = -50;
  localparam int PPM_PLUS_100  = 100;
  localparam int PPM_MINUS_100 = -100;

  // Unsupported PPM values
  localparam int PPM_PLUS_150  = 150;
  localparam int PPM_MINUS_150 = -150;
  localparam int PPM_PLUS_200  = 200;
  localparam int PPM_MINUS_200 = -200;

  // Random iteration count
  localparam int unsigned RANDOM_ITERATIONS = 100;

  `uvm_component_utils(PPM_CFG_001_ppm_cfg_test_c)

  extern function new(string name = "PPM_CFG_001_ppm_cfg_test_c",
                      uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task enable_tx_rx();
  extern task set_tx_ppm(int ppm_value);
  extern task set_rx_ppm(int ppm_value);
  extern task read_tx_status(output bit [31:0] status);
  extern task read_rx_status(output bit [31:0] status);

  extern task send_and_verify(int unsigned count, int unsigned payload_bytes,
                              string label);

  extern task run_legal_offset_config();
  extern task run_return_to_nominal();
  extern task run_rapid_switching();
  extern task run_unsupported_rejection();
  extern task run_random_legal_requests();
  extern task run_additional_stimuli();
endclass

// =============================================================================
// Constructor
// =============================================================================
function PPM_CFG_001_ppm_cfg_test_c::new(string name = "PPM_CFG_001_ppm_cfg_test_c",
                                         uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;  // TX client
  num_axi_passive_agents = 1;  // RX monitor
  num_rs_active_agents   = 0;
  num_rs_passive_agents  = 1;  // TX wire monitor
  num_tx_frames          = 1;
  num_rs_frames          = 1;
endfunction

// =============================================================================
// Configure: disable scoreboard TX check (PPM timing causes mismatches)
// =============================================================================
function void PPM_CFG_001_ppm_cfg_test_c::configure_test();
  super.configure_test();
  env_cfg_h.scoreboard_enable_tx_check = 1'b0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h         = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task PPM_CFG_001_ppm_cfg_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h        = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// PPM register helpers
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::enable_tx_rx();
  bit [31:0] ctrl;
  ctrl = (1 << reg_map_pkg::CTRL_RX_BIT) |
         (1 << reg_map_pkg::CTRL_TX_BIT) |
         (1 << reg_map_pkg::CTRL_PAUSE_BIT);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, ctrl);
  #200ns;
endtask

task PPM_CFG_001_ppm_cfg_test_c::set_tx_ppm(int ppm_value);
  // This fixed-clock top has no PPM APB register bank.
  #100ns;
endtask

task PPM_CFG_001_ppm_cfg_test_c::set_rx_ppm(int ppm_value);
  #100ns;
endtask

task PPM_CFG_001_ppm_cfg_test_c::read_tx_status(output bit [31:0] status);
  status = '0;
endtask

task PPM_CFG_001_ppm_cfg_test_c::read_rx_status(output bit [31:0] status);
  status = '0;
endtask

// =============================================================================
// send_and_verify: drive AXI TX frames, verify arrival at RS TX monitor
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::send_and_verify(
    int unsigned count,
    int unsigned payload_bytes,
    string label);
  int tx_before;
  bit timed_out;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    axi_sequence_c tx_seq_h;
    tx_seq_h            = axi_sequence_c::type_id::create($sformatf("cfg_%0s", label));
    tx_seq_h.num_tx     = count;
    tx_seq_h.payload_min = payload_bytes;
    tx_seq_h.payload_max = payload_bytes;
    tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + count,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * (count > 10 ? 10 : 1), timed_out);

  if (timed_out) begin
    int tx_after;
    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    `uvm_error("PPM_CFG_001", $sformatf(
               "FAIL [%0s]: timeout waiting for %0d frames (received %0d)",
               label, count, tx_after - tx_before))
  end else begin
    `uvm_info("PPM_CFG_001", $sformatf(
              "PASS [%0s]: %0d frames delivered at payload=%0d B",
              label, count, payload_bytes), UVM_NONE)
  end
endtask

// =============================================================================
// I1: Legal Offset Configuration
//
// Request +/-20, +/-50, and +/-100 ppm through the clock-control mechanism.
// At each offset: write the value, read back status, send 5 frames,
// verify delivery.  Also verify 0 ppm baseline before/after each group.
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::run_legal_offset_config();
  int legal_ppms[6]    = '{20, -20, 50, -50, 100, -100};
  string ppm_labels[6] = '{"+20ppm", "-20ppm", "+50ppm", "-50ppm", "+100ppm", "-100ppm"};
  bit [31:0] tx_status, rx_status;

  `uvm_info("PPM_CFG_001", "--- I1: Legal Offset Configuration ---", UVM_LOW)

  enable_tx_rx();

  // Baseline at 0 ppm
  `uvm_info("PPM_CFG_001_I1", "Baseline: 0 ppm", UVM_MEDIUM)
  set_tx_ppm(PPM_ZERO);
  set_rx_ppm(PPM_ZERO);
  #200ns;
  send_and_verify(3, MIN_PAYLOAD, "I1_baseline_0ppm");

  // Test each legal offset
  foreach (legal_ppms[i]) begin
    `uvm_info("PPM_CFG_001_I1", $sformatf("Configuring TX PPM=%0d (%0s)",
              legal_ppms[i], ppm_labels[i]), UVM_MEDIUM)

    // Write the offset
    set_tx_ppm(legal_ppms[i]);
    set_rx_ppm(0);
    #200ns;

    // Read status — verify the offset is reflected
    read_tx_status(tx_status);
    read_rx_status(rx_status);
    `uvm_info("PPM_CFG_001_I1", $sformatf(
              "Status after %0s: TX=%h RX=%h", ppm_labels[i], tx_status, rx_status),
              UVM_MEDIUM)

    // Send frames and verify delivery
    send_and_verify(5, MIN_PAYLOAD, $sformatf("I1_%0s_min", ppm_labels[i]));
    send_and_verify(3, STD_PAYLOAD, $sformatf("I1_%0s_std", ppm_labels[i]));

    // Return to 0 ppm baseline between offsets
    set_tx_ppm(PPM_ZERO);
    #100ns;
    send_and_verify(2, MIN_PAYLOAD, $sformatf("I1_%0s_baseline", ppm_labels[i]));
  end

  `uvm_info("PPM_CFG_001_I1", "PASS: I1 complete", UVM_NONE)
endtask

// =============================================================================
// I2: Return to Nominal Recovery
//
// Set +100 ppm, send traffic, confirm operation.  Set -100 ppm, send
// traffic, confirm.  Return to 0 ppm (nominal) and send normal +
// minimum-size frames.  Verify complete recovery with no loss.
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::run_return_to_nominal();
  bit [31:0] tx_status;
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_CFG_001", "--- I2: Return to Nominal Recovery ---", UVM_LOW)

  enable_tx_rx();

  // Phase 1: +100 ppm
  `uvm_info("PPM_CFG_001_I2", "Phase 1: TX=+100 ppm", UVM_MEDIUM)
  set_tx_ppm(PPM_PLUS_100);
  #200ns;
  send_and_verify(5, STD_PAYLOAD, "I2_phase1_pos100");

  // Phase 2: -100 ppm
  `uvm_info("PPM_CFG_001_I2", "Phase 2: TX=-100 ppm", UVM_MEDIUM)
  set_tx_ppm(PPM_MINUS_100);
  #200ns;
  send_and_verify(5, STD_PAYLOAD, "I2_phase2_neg100");

  // Phase 3: Return to 0 ppm (nominal)
  `uvm_info("PPM_CFG_001_I2", "Phase 3: Return to 0 ppm (nominal)", UVM_MEDIUM)
  set_tx_ppm(PPM_ZERO);
  #200ns;

  // Read status — confirm nominal
  read_tx_status(tx_status);
  `uvm_info("PPM_CFG_001_I2", $sformatf("Status after nominal return: TX=%h", tx_status),
            UVM_MEDIUM)

  // Send normal-size frames
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_and_verify(5, STD_PAYLOAD, "I2_phase3_nominal_std");

  // Send minimum-size frames — verify recovery is complete
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_and_verify(10, MIN_PAYLOAD, "I2_phase3_nominal_min");

  // Also verify jumbo frames work after recovery
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_and_verify(3, JUMBO_PAYLOAD, "I2_phase3_nominal_jumbo");

  `uvm_info("PPM_CFG_001_I2", "PASS: I2 complete — full recovery verified", UVM_NONE)
endtask

// =============================================================================
// I3: Rapid Switching
//
// Rapidly switch between legal offsets (+100, -100, +50, -50, 0 ppm)
// at high rate while streaming frames.  Verify no frame loss during
// the rapid transitions.
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::run_rapid_switching();
  int rapid_ppms[5] = '{100, -100, 50, -50, 0};
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_CFG_001", "--- I3: Rapid Switching ---", UVM_LOW)

  enable_tx_rx();

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  // Launch sustained traffic in background
  fork
    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i3_rapid_traffic");
      ppm_seq_h.send_sustained_line_rate(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 50);
    end
  join_none

  // Rapidly switch offsets — 100ns between each switch
  repeat (10) begin
    foreach (rapid_ppms[i]) begin
      set_tx_ppm(rapid_ppms[i]);
      #(100ns);
    end
  end

  // Wait for traffic to complete
  mac_wait_utils_c::wait_for_count_at_least(tx_before + 50,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 15, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out) begin
    `uvm_error("PPM_CFG_001_I3", $sformatf(
               "FAIL: timeout (received %0d of 50)", tx_after - tx_before))
  end else if ((tx_after - tx_before) < 50) begin
    `uvm_error("PPM_CFG_001_I3", $sformatf(
               "FAIL: frame loss (received %0d of 50)", tx_after - tx_before))
  end else begin
    `uvm_info("PPM_CFG_001_I3", $sformatf(
              "PASS: 50 frames delivered through rapid switching"), UVM_NONE)
  end

  set_tx_ppm(PPM_ZERO);
  #200ns;
  `uvm_info("PPM_CFG_001_I3", "PASS: I3 complete", UVM_NONE)
endtask

// =============================================================================
// I4: Unsupported Rejection with Active Traffic
//
// Start a 50-frame traffic stream.  During streaming, attempt +/-150 and
// +/-200 ppm writes.  Read status after each to verify rejection/clamping.
// Verify traffic completes without loss or corruption.
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::run_unsupported_rejection();
  int bad_ppm_values[4] = '{150, -150, 200, -200};
  string bad_labels[4]  = '{"+150ppm", "-150ppm", "+200ppm", "-200ppm"};
  bit [31:0] tx_status, rx_status;
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_CFG_001", "--- I4: Unsupported Rejection with Active Traffic ---", UVM_LOW)

  enable_tx_rx();

  // Launch sustained traffic in background
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  fork
    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i4_active_traffic");
      ppm_seq_h.send_sustained_line_rate(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 50);
    end
  join_none

  // While traffic is in flight, attempt unsupported PPM values
  #500ns;  // Let some traffic flow first

  foreach (bad_ppm_values[i]) begin
    `uvm_info("PPM_CFG_001_I4", $sformatf("Attempting unsupported: %0s during traffic",
              bad_labels[i]), UVM_MEDIUM)

    set_tx_ppm(bad_ppm_values[i]);
    #200ns;

    // Read status — verify rejection indication
    read_tx_status(tx_status);
    read_rx_status(rx_status);

    if (tx_status != 0 || rx_status != 0) begin
      `uvm_info("PPM_CFG_001_I4", $sformatf(
                "PASS [%0s]: Status indicates rejection (TX=%h RX=%h)",
                bad_labels[i], tx_status, rx_status), UVM_NONE)
    end else begin
      `uvm_info("PPM_CFG_001_I4", $sformatf(
                "INFO [%0s]: Status reads zero — value may be clamped (TX=%h RX=%h)",
                bad_labels[i], tx_status, rx_status), UVM_MEDIUM)
    end

    // Reset to legal value before next unsupported attempt
    set_tx_ppm(PPM_PLUS_50);
    #100ns;
  end

  // Wait for all traffic to complete
  mac_wait_utils_c::wait_for_count_at_least(tx_before + 50,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 20, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out) begin
    `uvm_error("PPM_CFG_001_I4", $sformatf(
               "FAIL: timeout (received %0d of 50)", tx_after - tx_before))
  end else if ((tx_after - tx_before) < 50) begin
    `uvm_error("PPM_CFG_001_I4", $sformatf(
               "FAIL: frame loss after unsupported attempts (received %0d of 50)",
               tx_after - tx_before))
  end else begin
    `uvm_info("PPM_CFG_001_I4", $sformatf(
              "PASS: 50 frames delivered through unsupported rejection tests"), UVM_NONE)
  end

  // Verify data integrity after all unsupported attempts
  `uvm_info("PPM_CFG_001_I4", "Verifying data integrity post-rejection", UVM_MEDIUM)
  set_tx_ppm(PPM_PLUS_100);
  set_rx_ppm(PPM_MINUS_100);
  #200ns;
  send_and_verify(5, STD_PAYLOAD, "I4_post_integrity");

  set_tx_ppm(PPM_ZERO);
  set_rx_ppm(PPM_ZERO);
  #200ns;

  `uvm_info("PPM_CFG_001_I4", "PASS: I4 complete", UVM_NONE)
endtask

// =============================================================================
// I5: Random Legal Requests
//
// Randomly select from legal offsets (+-20, +-50, +-100, 0), random frame
// sizes (46-8946 bytes), and random timing.  100 iterations.
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::run_random_legal_requests();
  int legal_ppms[7] = '{0, 20, -20, 50, -50, 100, -100};
  int tx_before, tx_after;
  bit timed_out;
  int total_sent;

  `uvm_info("PPM_CFG_001", "--- I5: Random Legal Requests ---", UVM_LOW)

  enable_tx_rx();

  total_sent = 0;
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  repeat (RANDOM_ITERATIONS) begin
    int rand_ppm;
    int rand_payload;
    int rand_delay;

    // Random PPM offset from legal set
    rand_ppm = legal_ppms[$urandom_range(0, 6)];

    // Random payload size (46 to 8946)
    rand_payload = $urandom_range(MIN_PAYLOAD, JUMBO_PAYLOAD);

    // Random delay between requests (0 to 200ns)
    rand_delay = $urandom_range(0, 200);

    // Apply PPM
    set_tx_ppm(rand_ppm);
    #(rand_delay * 1ns);

    // Send 1 frame
    begin
      axi_sequence_c tx_seq_h;
      tx_seq_h            = axi_sequence_c::type_id::create(
          $sformatf("i5_rand_%0d", total_sent));
      tx_seq_h.num_tx     = 1;
      tx_seq_h.payload_min = rand_payload;
      tx_seq_h.payload_max = rand_payload;
      tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
    end

    total_sent++;
  end

  // Wait for all frames to be delivered
  mac_wait_utils_c::wait_for_count_at_least(tx_before + RANDOM_ITERATIONS,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 30, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out) begin
    `uvm_error("PPM_CFG_001_I5", $sformatf(
               "FAIL: timeout (received %0d of %0d)", tx_after - tx_before,
               RANDOM_ITERATIONS))
  end else if ((tx_after - tx_before) < RANDOM_ITERATIONS) begin
    `uvm_error("PPM_CFG_001_I5", $sformatf(
               "FAIL: frame loss (received %0d of %0d)", tx_after - tx_before,
               RANDOM_ITERATIONS))
  end else begin
    `uvm_info("PPM_CFG_001_I5", $sformatf(
              "PASS: %0d random frames delivered", RANDOM_ITERATIONS), UVM_NONE)
  end

  set_tx_ppm(PPM_ZERO);
  #200ns;

  `uvm_info("PPM_CFG_001_I5", "PASS: I5 complete", UVM_NONE)
endtask

// =============================================================================
// I6: Additional Stimuli
//
// I6a: Sweep intermediate legal offsets (0, +/-10, +/-25, +/-50, +/-75, +/-100).
// I6b: Alternate positive/negative offsets during mixed frame sizes.
// I6c: Combine boundary offset (+100 ppm) with backpressure.
// I6d: Randomized long-duration traffic.
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::run_additional_stimuli();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_CFG_001", "--- I6: Additional Stimuli ---", UVM_LOW)

  enable_tx_rx();

  // I6a: Intermediate offset sweep
  `uvm_info("PPM_CFG_001_I6", "I6a: Intermediate offset sweep", UVM_MEDIUM)
  begin
    int intermediate_ppms[11] = '{0, 10, -10, 25, -25, 50, -50, 75, -75, 100, -100};
    foreach (intermediate_ppms[i]) begin
      set_tx_ppm(intermediate_ppms[i]);
      #100ns;
      send_and_verify(3, MIN_PAYLOAD,
                      $sformatf("I6a_%0dppm", intermediate_ppms[i]));
    end
    set_tx_ppm(0);
    #100ns;
  end

  // I6b: Alternate +/-ppm with mixed frame sizes
  `uvm_info("PPM_CFG_001_I6", "I6b: Alternate +/-ppm with mixed sizes", UVM_MEDIUM)
  begin
    int alt_ppms[6] = '{100, -100, 50, -50, 100, -100};
    foreach (alt_ppms[i]) begin
      set_tx_ppm(alt_ppms[i]);
      #100ns;
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i6b_alt_%0d", i));
        ppm_seq_h.send_mixed_frame_sizes(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 5);
      end
    end
    set_tx_ppm(0);
    #100ns;
    `uvm_info("PPM_CFG_001_I6B", "PASS: Alternate +/-ppm mixed sizes", UVM_NONE)
  end

  // I6c: Boundary offset with backpressure
  `uvm_info("PPM_CFG_001_I6", "I6c: Boundary offset + backpressure", UVM_MEDIUM)
  begin
    set_tx_ppm(PPM_PLUS_100);
    set_rx_ppm(PPM_MINUS_100);
    #200ns;

    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    fork
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i6c_boundary_bp");
        ppm_seq_h.send_sustained_line_rate(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 30);
      end
      begin
        // Apply intermittent backpressure on AXI RX
        repeat (5) begin
          axi_rx_vif.tready <= 1'b0;
          #500ns;
          axi_rx_vif.tready <= 1'b1;
          #500ns;
        end
      end
    join

    mac_wait_utils_c::wait_for_count_at_least(tx_before + 30,
        env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
        mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 15, timed_out);

    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    if (timed_out || (tx_after - tx_before) < 30)
      `uvm_error("PPM_CFG_001_I6C", $sformatf(
                 "FAIL: received %0d of 30", tx_after - tx_before))
    else
      `uvm_info("PPM_CFG_001_I6C", "PASS: boundary + backpressure delivered", UVM_NONE)

    axi_rx_vif.tready <= 1'b1;
    set_tx_ppm(0);
    set_rx_ppm(0);
    #200ns;
  end

  // I6d: Randomized long-duration traffic at varying offsets
  `uvm_info("PPM_CFG_001_I6", "I6d: Randomized long-duration", UVM_MEDIUM)
  begin
    int long_ppms[3] = '{0, 75, -75};
    foreach (long_ppms[i]) begin
      set_tx_ppm(long_ppms[i]);
      #100ns;
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i6d_long_%0d", i));
        ppm_seq_h.send_randomized_long_duration(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 100);
      end
    end
    set_tx_ppm(0);
    #200ns;
    `uvm_info("PPM_CFG_001_I6D", "PASS: Randomized long-duration complete", UVM_NONE)
  end

  `uvm_info("PPM_CFG_001_I6", "PASS: I6 complete", UVM_NONE)
endtask

// =============================================================================
// run_stimulus — orchestrates all six iterations
// =============================================================================
task PPM_CFG_001_ppm_cfg_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("PPM_CFG_001", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("PPM_CFG_001", "MAC reset and APB bootstrap did not complete")

  `uvm_info("PPM_CFG_001", "=== PPM_CFG_001 START ===", UVM_LOW)

  run_legal_offset_config();      // I1
  run_return_to_nominal();        // I2
  run_rapid_switching();          // I3
  run_unsupported_rejection();    // I4
  run_random_legal_requests();    // I5
  run_additional_stimuli();       // I6

  // Final cleanup
  set_tx_ppm(PPM_ZERO);
  set_rx_ppm(PPM_ZERO);
  axi_rx_vif.tready <= 1'b1;

  `uvm_info("PPM_CFG_001", "=== PPM_CFG_001 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // PPM_CFG_001_PPM_CFG_TEST_SVH
