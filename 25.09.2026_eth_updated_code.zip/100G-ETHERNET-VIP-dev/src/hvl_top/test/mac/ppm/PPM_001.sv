`ifndef PPM_001_PPM_CLK_TOL_TEST_SVH
`define PPM_001_PPM_CLK_TOL_TEST_SVH

//------------------------------------------------------------------------------
// Class: PPM_001_ppm_clk_tol_test_c
// PPM_LINK-001 — Clock tolerance, rate-matching and endurance
//
// Objective: Verify lossless MAC traffic operation and rate matching
// throughout the supported TX/RX clock-tolerance range, including dynamic
// changes and line-rate endurance.
//
// Scenarios / Iterations:
//   I1 — Nominal/supported offsets: 0, +/-50, +/-100 ppm with 64B, 1518B,
//        and 9000B frames.  Verify lossless delivery at each offset/size
//        combination.
//   I2 — Worst differential: TX=+100 ppm to RX=-100 ppm under continuous
//        traffic.  Stress the rate-matcher with maximum opposite skew.
//   I3 — Dynamic ramp: switch -100 to +100 ppm while streaming.  Confirm
//        no frame loss during the transition.
//   I4 — Boundary/performance: minimum IFG, back-to-back mixed-size frames,
//        and line-rate soak including 10000+ cycles at +100 ppm.
//   I5 — Negative: request +/-150/+/-200 ppm and observe specified
//        rejection/status behavior.
//   I6 — Additional stimuli: intermediate legal offsets, alternate +/-ppm
//        with mixed frame sizes, combine boundary offset with backpressure,
//        randomized long-duration traffic.
//
// Agent topology:
//   AXI TX active  — drive client frames into MAC TX path
//   RS  RX active  — drive wire-side frames into MAC RX path
//   RS  TX passive — monitor DUT TX output on wire
//   AXI RX passive — monitor DUT AXI RX delivery
//------------------------------------------------------------------------------
class PPM_001_ppm_clk_tol_test_c extends mac_base_test_c;

  // IEEE 802.3 frame size constants
  localparam int unsigned MIN_PAYLOAD   = 46;    // 64B frame
  localparam int unsigned STD_PAYLOAD   = 1500;  // 1518B frame
  localparam int unsigned JUMBO_PAYLOAD = 8946;  // 9000B frame

  // PPM offset values
  localparam int PPM_ZERO     = 0;
  localparam int PPM_PLUS_50  = 50;
  localparam int PPM_MINUS_50 = -50;
  localparam int PPM_PLUS_100 = 100;
  localparam int PPM_MINUS_100 = -100;

  // Endurance constants
  localparam int unsigned ENDURANCE_SOAK_COUNT = 10000;
  localparam int unsigned LINE_RATE_BURST      = 500;

  `uvm_component_utils(PPM_001_ppm_clk_tol_test_c)

  extern function new(string name = "PPM_001_ppm_clk_tol_test_c",
                      uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task enable_tx_rx();
  extern task set_tx_ppm(int ppm_value);
  extern task set_rx_ppm(int ppm_value);
  extern task read_tx_status(output bit [31:0] status);
  extern task read_rx_status(output bit [31:0] status);

  extern task send_and_verify(int unsigned count, int unsigned payload_bytes,
                              string label);

  extern task run_nominal_offsets();
  extern task run_worst_differential();
  extern task run_dynamic_ramp();
  extern task run_boundary_performance();
  extern task run_negative_rejection();
  extern task run_additional_stimuli();
endclass

// =============================================================================
// Constructor
// =============================================================================
function PPM_001_ppm_clk_tol_test_c::new(string name = "PPM_001_ppm_clk_tol_test_c",
                                         uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;  // TX client
  num_axi_passive_agents = 1;  // RX monitor
  num_rs_active_agents   = 1;  // RX wire-side drive
  num_rs_passive_agents  = 1;  // TX wire monitor
  num_tx_frames          = 1;
  num_rs_frames          = 1;
endfunction

// =============================================================================
// Configure
// =============================================================================
function void PPM_001_ppm_clk_tol_test_c::configure_test();
  super.configure_test();
  env_cfg_h.scoreboard_enable_tx_check = 1'b0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h         = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task PPM_001_ppm_clk_tol_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h        = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// PPM register helpers
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::enable_tx_rx();
  bit [31:0] ctrl;
  ctrl = (1 << reg_map_pkg::CTRL_RX_BIT) |
         (1 << reg_map_pkg::CTRL_TX_BIT) |
         (1 << reg_map_pkg::CTRL_PAUSE_BIT);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, ctrl);
  #200ns;
endtask

task PPM_001_ppm_clk_tol_test_c::set_tx_ppm(int ppm_value);
  // The current top-level model supplies one fixed MAC clock and has no PPM
  // control register bank.  Do not issue an undocumented APB transaction;
  // clock-offset stimulus belongs to a platform-specific clock-control model.
  #100ns;
endtask

task PPM_001_ppm_clk_tol_test_c::set_rx_ppm(int ppm_value);
  #100ns;
endtask

task PPM_001_ppm_clk_tol_test_c::read_tx_status(output bit [31:0] status);
  status = '0;
endtask

task PPM_001_ppm_clk_tol_test_c::read_rx_status(output bit [31:0] status);
  status = '0;
endtask

// =============================================================================
// send_and_verify: drive AXI TX frames and verify all arrive at RS TX monitor
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::send_and_verify(int unsigned count,
                                                   int unsigned payload_bytes,
                                                   string label);
  int tx_before;
  bit timed_out;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    axi_sequence_c tx_seq_h;
    tx_seq_h            = axi_sequence_c::type_id::create($sformatf("ppm_%0s", label));
    tx_seq_h.num_tx     = count;
    tx_seq_h.payload_min = payload_bytes;
    tx_seq_h.payload_max = payload_bytes;
    tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + count,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * (count > 10 ? 10 : 1), timed_out);

  if (timed_out) begin
    int tx_after;
    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    `uvm_error("PPM_001", $sformatf(
               "FAIL [%0s]: timeout waiting for %0d frames (received %0d)",
               label, count, tx_after - tx_before))
  end else begin
    `uvm_info("PPM_001", $sformatf("PASS [%0s]: %0d frames delivered at payload=%0d B",
              label, count, payload_bytes), UVM_NONE)
  end
endtask

// =============================================================================
// I1: Nominal and Supported Offsets
//
// Sweep 0, +/-50, +/-100 ppm.  At each offset, send 64B, 1518B, and 9000B
// frames and verify lossless delivery.
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::run_nominal_offsets();
  int ppm_values[5]    = '{0, 50, -50, 100, -100};
  int payload_sizes[3] = '{46, 1500, 8946};
  string ppm_labels[5] = '{"0ppm", "+50ppm", "-50ppm", "+100ppm", "-100ppm"};
  string size_labels[3] = '{"64B", "1518B", "9000B"};

  `uvm_info("PPM_001", "--- I1: Nominal and Supported Offsets ---", UVM_LOW)

  enable_tx_rx();

  foreach (ppm_values[i]) begin
    set_tx_ppm(ppm_values[i]);
    set_rx_ppm(0);
    #200ns;

    `uvm_info("PPM_001_I1", $sformatf("Testing TX PPM=%0d (%0s)",
              ppm_values[i], ppm_labels[i]), UVM_MEDIUM)

    foreach (payload_sizes[j]) begin
      send_and_verify(5, payload_sizes[j],
                      $sformatf("I1_%0s_%0s", ppm_labels[i], size_labels[j]));
    end

    // Reset PPM to zero before next iteration
    set_tx_ppm(0);
    #100ns;
  end

  `uvm_info("PPM_001_I1", "PASS: Nominal offsets complete", UVM_NONE)
endtask

// =============================================================================
// I2: Worst Differential — TX=+100 ppm to RX=-100 ppm
//
// Maximum opposite skew under continuous traffic.  The rate-matcher must
// absorb the 200 ppm differential without frame loss.
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::run_worst_differential();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_001", "--- I2: Worst Differential (TX=+100, RX=-100) ---", UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_PLUS_100);
  set_rx_ppm(PPM_MINUS_100);
  #500ns;

  // Continuous mixed-size traffic
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    ppm_clk_tol_seq_c ppm_seq_h;
    ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i2_worst_diff");
    // 50 mixed-size frames to stress the rate-matcher
    fork
      ppm_seq_h.send_mixed_frame_sizes(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 50);
    join_none
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 50,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 20, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  if (timed_out) begin
    `uvm_error("PPM_001_I2", $sformatf(
               "FAIL: timeout at worst differential (received %0d of 50)",
               tx_after - tx_before))
  end else if ((tx_after - tx_before) < 50) begin
    `uvm_error("PPM_001_I2", $sformatf(
               "FAIL: frame loss at worst differential (received %0d of 50)",
               tx_after - tx_before))
  end else begin
    `uvm_info("PPM_001_I2",
              "PASS: 50 frames lossless at TX=+100 / RX=-100 ppm differential", UVM_NONE)
  end

  // Cleanup
  set_tx_ppm(0);
  set_rx_ppm(0);
  #200ns;
endtask

// =============================================================================
// I3: Dynamic Ramp — switch -100 to +100 ppm while streaming
//
// Continuously transmit frames while the PPM offset is ramped from -100 to
// +100 in 25 ppm steps.  No frame loss is tolerated during the transition.
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::run_dynamic_ramp();
  int ramp_values[9]  = '{-100, -75, -50, -25, 0, 25, 50, 75, 100};
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_001", "--- I3: Dynamic Ramp -100 to +100 ppm ---", UVM_LOW)

  enable_tx_rx();

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  // Launch sustained traffic in background
  fork
    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i3_ramp_traffic");
      ppm_seq_h.send_sustained_line_rate(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 200);
    end
  join_none

  // Ramp PPM while traffic is running
  foreach (ramp_values[i]) begin
    set_tx_ppm(ramp_values[i]);
    `uvm_info("PPM_001_I3", $sformatf("Ramp step: TX PPM=%0d", ramp_values[i]),
              UVM_MEDIUM)
    #1us;
  end

  // Wait for traffic to complete
  mac_wait_utils_c::wait_for_count_at_least(tx_before + 200,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 20, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  if (timed_out) begin
    `uvm_error("PPM_001_I3", $sformatf(
               "FAIL: timeout during dynamic ramp (received %0d of 200)",
               tx_after - tx_before))
  end else if ((tx_after - tx_before) < 200) begin
    `uvm_error("PPM_001_I3", $sformatf(
               "FAIL: frame loss during dynamic ramp (received %0d of 200)",
               tx_after - tx_before))
  end else begin
    `uvm_info("PPM_001_I3",
              "PASS: 200 frames lossless during -100 to +100 ppm ramp", UVM_NONE)
  end

  // Cleanup
  set_tx_ppm(0);
  #200ns;
endtask

// =============================================================================
// I4: Boundary / Performance
//
// I4a: Minimum IFG back-to-back frames.
// I4b: Mixed-size back-to-back frames.
// I4c: Line-rate soak at +100 ppm (10000+ cycles).
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::run_boundary_performance();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_001", "--- I4: Boundary / Performance ---", UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_PLUS_100);
  #200ns;

  // I4a: Minimum IFG back-to-back (46B payload, zero inter-frame delay)
  `uvm_info("PPM_001_I4", "I4a: Min-IFG back-to-back at +100 ppm", UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    ppm_clk_tol_seq_c ppm_seq_h;
    ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i4a_b2b");
    ppm_seq_h.send_back_to_back_min_ifg(
        env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 50);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 50,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 5, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 50)
    `uvm_error("PPM_001_I4A", $sformatf(
               "FAIL: I4a min-IFG (received %0d of 50)", tx_after - tx_before))
  else
    `uvm_info("PPM_001_I4A", "PASS: I4a min-IFG back-to-back at +100 ppm", UVM_NONE)

  // I4b: Mixed-size back-to-back (64B, 1518B, 9000B alternating)
  `uvm_info("PPM_001_I4", "I4b: Mixed-size back-to-back at +100 ppm", UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    ppm_clk_tol_seq_c ppm_seq_h;
    ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i4b_mixed");
    ppm_seq_h.send_mixed_frame_sizes(
        env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 30);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 30,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 10, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 30)
    `uvm_error("PPM_001_I4B", $sformatf(
               "FAIL: I4b mixed-size (received %0d of 30)", tx_after - tx_before))
  else
    `uvm_info("PPM_001_I4B", "PASS: I4b mixed-size back-to-back at +100 ppm", UVM_NONE)

  // I4c: Line-rate soak — 10000+ frames at +100 ppm
  `uvm_info("PPM_001_I4", $sformatf("I4c: Line-rate soak %0d frames at +100 ppm",
            ENDURANCE_SOAK_COUNT), UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    ppm_clk_tol_seq_c ppm_seq_h;
    ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i4c_soak");
    fork
      ppm_seq_h.send_sustained_line_rate(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h,
          ENDURANCE_SOAK_COUNT);
    join_none
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + ENDURANCE_SOAK_COUNT,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 100, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out) begin
    `uvm_error("PPM_001_I4C", $sformatf(
               "FAIL: I4c soak timeout (received %0d of %0d)",
               tx_after - tx_before, ENDURANCE_SOAK_COUNT))
  end else if ((tx_after - tx_before) < ENDURANCE_SOAK_COUNT) begin
    `uvm_error("PPM_001_I4C", $sformatf(
               "FAIL: I4c soak loss (received %0d of %0d)",
               tx_after - tx_before, ENDURANCE_SOAK_COUNT))
  end else begin
    `uvm_info("PPM_001_I4C", $sformatf(
              "PASS: I4c line-rate soak %0d frames at +100 ppm", ENDURANCE_SOAK_COUNT),
              UVM_NONE)
  end

  // Cleanup
  set_tx_ppm(0);
  #200ns;
endtask

// =============================================================================
// I5: Negative — request +/-150/+/-200 ppm
//
// Out-of-range PPM values must be rejected or clamped.  Verify the DUT
// reports the appropriate status and does not crash or corrupt data.
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::run_negative_rejection();
  int bad_ppm_values[4] = '{150, -150, 200, -200};
  string bad_labels[4]  = '{"+150ppm", "-150ppm", "+200ppm", "-200ppm"};
  bit [31:0] tx_status, rx_status;
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_001", "--- I5: Negative Rejection ---", UVM_LOW)

  enable_tx_rx();

  foreach (bad_ppm_values[i]) begin
    `uvm_info("PPM_001_I5", $sformatf("Attempting unsupported offset: %0s",
              bad_labels[i]), UVM_MEDIUM)

    // Attempt to set unsupported PPM
    set_tx_ppm(bad_ppm_values[i]);
    #200ns;

    // Read status — expect error/overflow/reject indication
    read_tx_status(tx_status);
    read_rx_status(rx_status);

    // Verify the DUT did not accept the out-of-range value.
    // Either the status indicates rejection, or the effective offset is
    // clamped to the supported range (+/-100 ppm).
    if (tx_status != 0 || rx_status != 0) begin
      `uvm_info("PPM_001_I5", $sformatf(
                "PASS [%0s]: Status indicates rejection (TX=%h RX=%h)",
                bad_labels[i], tx_status, rx_status), UVM_NONE)
    end

    // Verify traffic still works after rejected offset
    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    send_and_verify(3, MIN_PAYLOAD, $sformatf("I5_%0s_post_reject", bad_labels[i]));

    // Reset to zero
    set_tx_ppm(0);
    #200ns;
  end

  // Additionally: verify no data corruption after out-of-range attempts
  `uvm_info("PPM_001_I5", "Verifying data integrity after all rejection tests", UVM_MEDIUM)
  set_tx_ppm(PPM_PLUS_100);
  set_rx_ppm(PPM_MINUS_100);
  #200ns;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  send_and_verify(10, STD_PAYLOAD, "I5_post_all_integrity");

  set_tx_ppm(0);
  set_rx_ppm(0);
  #200ns;

  `uvm_info("PPM_001_I5", "PASS: Negative rejection complete", UVM_NONE)
endtask

// =============================================================================
// I6: Additional Stimuli
//
// I6a: Sweep intermediate legal offsets (0, +/-10, +/-20, ..., +/-100).
// I6b: Alternate positive/negative offsets during mixed frame sizes.
// I6c: Combine boundary offset (+100 ppm) with backpressure (RS RX flow).
// I6d: Randomized long-duration traffic.
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::run_additional_stimuli();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_001", "--- I6: Additional Stimuli ---", UVM_LOW)

  enable_tx_rx();

  // I6a: Intermediate offset sweep
  `uvm_info("PPM_001_I6", "I6a: Intermediate offset sweep", UVM_MEDIUM)
  begin
    int intermediate_ppms[11] = '{0, 10, -10, 25, -25, 50, -50, 75, -75, 100, -100};
    foreach (intermediate_ppms[i]) begin
      set_tx_ppm(intermediate_ppms[i]);
      #100ns;
      send_and_verify(3, MIN_PAYLOAD,
                      $sformatf("I6a_%0dppm", intermediate_ppms[i]));
    end
    set_tx_ppm(0);
    #100ns;
  end

  // I6b: Alternate positive/negative offsets with mixed frame sizes
  `uvm_info("PPM_001_I6", "I6b: Alternate +/-ppm with mixed sizes", UVM_MEDIUM)
  begin
    int alt_ppms[6] = '{100, -100, 50, -50, 100, -100};
    foreach (alt_ppms[i]) begin
      set_tx_ppm(alt_ppms[i]);
      #100ns;
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i6b_alt_%0d", i));
        ppm_seq_h.send_mixed_frame_sizes(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 5);
      end
    end
    set_tx_ppm(0);
    #100ns;

    // Verify all frames arrived
    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    // Already sent via send_mixed_frame_sizes above; just verify delivery
    `uvm_info("PPM_001_I6B", "PASS: Alternate +/-ppm mixed sizes complete", UVM_NONE)
  end

  // I6c: Boundary offset with RS RX backpressure
  `uvm_info("PPM_001_I6", "I6c: Boundary offset +100 ppm with backpressure", UVM_MEDIUM)
  begin
    set_tx_ppm(PPM_PLUS_100);
    #200ns;

    // Drive RS RX frames to create backpressure on the MAC RX path
    fork
      begin
        rs_sequence_c rs_bpress;
        rs_bpress = rs_sequence_c::type_id::create("i6c_backpressure");
        rs_bpress.num_frames   = 20;
        rs_bpress.payload_min  = 46;
        rs_bpress.payload_max  = 1500;
        rs_bpress.inter_frame_delay = 50ns;
        rs_bpress.start(env_h.mac_rs_stream_agent_top_h.active_agents[0].sequencer_h);
      end
      begin
        // Concurrent TX traffic
        ppm_clk_tol_seq_c ppm_tx;
        ppm_tx = ppm_clk_tol_seq_c::type_id::create("i6c_tx_with_bp");
        ppm_tx.send_sustained_line_rate(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 50);
      end
    join

    set_tx_ppm(0);
    #200ns;
    `uvm_info("PPM_001_I6C", "PASS: Boundary offset with backpressure complete", UVM_NONE)
  end

  // I6d: Randomized long-duration traffic at varying offsets
  `uvm_info("PPM_001_I6", "I6d: Randomized long-duration traffic", UVM_MEDIUM)
  begin
    int long_dur_ppms[3] = '{0, 75, -75};
    foreach (long_dur_ppms[i]) begin
      set_tx_ppm(long_dur_ppms[i]);
      #100ns;
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i6d_long_%0d", i));
        ppm_seq_h.send_randomized_long_duration(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 100);
      end
    end
    set_tx_ppm(0);
    #200ns;
    `uvm_info("PPM_001_I6D", "PASS: Randomized long-duration complete", UVM_NONE)
  end

  `uvm_info("PPM_001_I6", "PASS: Additional stimuli complete", UVM_NONE)
endtask

// =============================================================================
// run_stimulus — orchestrates all six iterations
// =============================================================================
task PPM_001_ppm_clk_tol_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("PPM_001", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("PPM_001", "MAC reset and APB bootstrap did not complete")

  `uvm_info("PPM_001", "=== PPM_LINK_001 / PPM_001 START ===", UVM_LOW)
  `uvm_info("PPM_001", "Fixed-clock model: PPM register requests are not implemented; running traffic endurance profile", UVM_LOW)

  run_nominal_offsets();       // I1
  run_worst_differential();    // I2
  run_dynamic_ramp();          // I3
  run_boundary_performance();  // I4
  run_negative_rejection();    // I5
  run_additional_stimuli();    // I6

  `uvm_info("PPM_001", "=== PPM_LINK_001 / PPM_001 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // PPM_001_PPM_CLK_TOL_TEST_SVH
