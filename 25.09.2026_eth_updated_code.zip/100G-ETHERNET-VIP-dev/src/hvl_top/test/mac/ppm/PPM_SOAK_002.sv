`ifndef PPM_SOAK_002_PPM_SOAK_TEST_SVH
`define PPM_SOAK_002_PPM_SOAK_TEST_SVH

//------------------------------------------------------------------------------
// Class: PPM_SOAK_002_ppm_soak_test_c
// PPM_SOAK-002 — PPM Endurance and Throughput Soak
//
// Objective: Verify sustained lossless MAC traffic operation under PPM clock
// offsets with high-volume, long-duration, and mixed-size frame traffic.
// Stress the rate-matcher, FIFOs, and data path with endurance-class workloads
// across all supported clock offsets.
//
// Scenarios / Iterations:
//   I1 — Sustained line-rate traffic at +/-100 ppm with mixed 64B/1518B/9000B
//        frames.  Verify lossless delivery at each offset.
//   I2 — 10,000+ frame endurance soak at +100 ppm.  Extended duration
//        sustained traffic to exercise long-running rate-matching.
//   I3 — 5,000 mixed-size frame soak (round-robin 64B/1518B/9000B) at
//        +/-100 ppm.  Verify lossless delivery.
//   I4 — Randomized legal PPM (0, +/-20, +/-50, +/-100) with varied IFG
//        over 200 iterations.  Verify delivery across random conditions.
//   I5 — Additional stimuli: intermediate offset sweep, alternate +/-ppm
//        with mixed frames, boundary offset + backpressure, randomized
//        long-duration traffic.
//
// Agent topology:
//   AXI TX active  — drive client frames into MAC TX path
//   RS  RX active  — RX wire-side drive (for backpressure scenarios)
//   RS  TX passive — monitor DUT TX output on wire
//   AXI RX passive — monitor DUT AXI RX delivery
//   APB  active    — always present (from base test)
//------------------------------------------------------------------------------
class PPM_SOAK_002_ppm_soak_test_c extends mac_base_test_c;

  // IEEE 802.3 frame size constants
  localparam int unsigned MIN_PAYLOAD   = 46;    // 64B frame
  localparam int unsigned STD_PAYLOAD   = 1500;  // 1518B frame
  localparam int unsigned JUMBO_PAYLOAD = 8946;  // 9000B frame

  // PPM offset values
  localparam int PPM_ZERO      = 0;
  localparam int PPM_PLUS_20   = 20;
  localparam int PPM_MINUS_20  = -20;
  localparam int PPM_PLUS_50   = 50;
  localparam int PPM_MINUS_50  = -50;
  localparam int PPM_PLUS_100  = 100;
  localparam int PPM_MINUS_100 = -100;

  // Endurance constants
  localparam int unsigned SOAK_COUNT        = 10000;
  localparam int unsigned MIXED_SOAK_COUNT  = 5000;
  localparam int unsigned RANDOM_SOAK_COUNT = 200;
  localparam int unsigned LINE_RATE_BURST   = 500;

  `uvm_component_utils(PPM_SOAK_002_ppm_soak_test_c)

  extern function new(string name = "PPM_SOAK_002_ppm_soak_test_c",
                      uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task enable_tx_rx();
  extern task set_tx_ppm(int ppm_value);
  extern task set_rx_ppm(int ppm_value);

  extern task send_and_verify(int unsigned count, int unsigned payload_bytes,
                              string label);

  extern task run_sustained_line_rate();
  extern task run_10k_endurance();
  extern task run_mixed_frame_soak();
  extern task run_random_ppm_ifg();
  extern task run_additional_stimuli();
endclass

// =============================================================================
// Constructor
// =============================================================================
function PPM_SOAK_002_ppm_soak_test_c::new(
    string name = "PPM_SOAK_002_ppm_soak_test_c",
    uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;  // TX client
  num_axi_passive_agents = 1;  // RX monitor
  num_rs_active_agents   = 1;  // RX wire-side drive
  num_rs_passive_agents  = 1;  // TX wire monitor
  num_tx_frames          = 1;
  num_rs_frames          = 1;
endfunction

// =============================================================================
// Configure: disable scoreboard TX check (PPM timing causes mismatches)
// =============================================================================
function void PPM_SOAK_002_ppm_soak_test_c::configure_test();
  super.configure_test();
  env_cfg_h.scoreboard_enable_tx_check = 1'b0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h         = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task PPM_SOAK_002_ppm_soak_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h        = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// PPM register helpers
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::enable_tx_rx();
  bit [31:0] ctrl;
  ctrl = (1 << reg_map_pkg::CTRL_RX_BIT) |
         (1 << reg_map_pkg::CTRL_TX_BIT) |
         (1 << reg_map_pkg::CTRL_PAUSE_BIT);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, ctrl);
  #200ns;
endtask

task PPM_SOAK_002_ppm_soak_test_c::set_tx_ppm(int ppm_value);
  #100ns;
endtask

task PPM_SOAK_002_ppm_soak_test_c::set_rx_ppm(int ppm_value);
  #100ns;
endtask

// =============================================================================
// send_and_verify: drive AXI TX frames, verify arrival at RS TX monitor
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::send_and_verify(
    int unsigned count,
    int unsigned payload_bytes,
    string label);
  int tx_before;
  bit timed_out;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    axi_sequence_c tx_seq_h;
    tx_seq_h            = axi_sequence_c::type_id::create($sformatf("soak_%0s", label));
    tx_seq_h.num_tx     = count;
    tx_seq_h.payload_min = payload_bytes;
    tx_seq_h.payload_max = payload_bytes;
    tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + count,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * (count > 100 ? 100 : 1), timed_out);

  if (timed_out) begin
    int tx_after;
    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    `uvm_error("PPM_SOAK_002", $sformatf(
               "FAIL [%0s]: timeout waiting for %0d frames (received %0d)",
               label, count, tx_after - tx_before))
  end else begin
    `uvm_info("PPM_SOAK_002", $sformatf(
              "PASS [%0s]: %0d frames delivered at payload=%0d B",
              label, count, payload_bytes), UVM_NONE)
  end
endtask

// =============================================================================
// I1: Sustained Line-Rate Traffic at +/-100 ppm
//
// Send sustained line-rate bursts at each boundary offset with mixed
// 64B, 1518B, and 9000B frames.  Verify lossless delivery.
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::run_sustained_line_rate();
  int ppm_values[2]    = '{PPM_PLUS_100, PPM_MINUS_100};
  string ppm_labels[2] = '{"+100ppm", "-100ppm"};
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_SOAK_002", "--- I1: Sustained Line-Rate at +/-100 ppm ---", UVM_LOW)

  enable_tx_rx();

  foreach (ppm_values[i]) begin
    `uvm_info("PPM_SOAK_002_I1", $sformatf("Sustained line-rate at %0s", ppm_labels[i]),
              UVM_MEDIUM)

    set_tx_ppm(ppm_values[i]);
    set_rx_ppm(0);
    #200ns;

    // Sustained mixed-size traffic
    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create($sformatf("i1_sustained_%0s", ppm_labels[i]));
      fork
        ppm_seq_h.send_sustained_line_rate(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h,
            LINE_RATE_BURST);
      join_none
    end

    mac_wait_utils_c::wait_for_count_at_least(tx_before + LINE_RATE_BURST,
        env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
        mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 50, timed_out);

    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    if (timed_out) begin
      `uvm_error("PPM_SOAK_002_I1", $sformatf(
                 "FAIL [%0s]: timeout (received %0d of %0d)",
                 ppm_labels[i], tx_after - tx_before, LINE_RATE_BURST))
    end else if ((tx_after - tx_before) < LINE_RATE_BURST) begin
      `uvm_error("PPM_SOAK_002_I1", $sformatf(
                 "FAIL [%0s]: frame loss (received %0d of %0d)",
                 ppm_labels[i], tx_after - tx_before, LINE_RATE_BURST))
    end else begin
      `uvm_info("PPM_SOAK_002_I1", $sformatf(
                "PASS [%0s]: %0d frames lossless at sustained line-rate",
                ppm_labels[i], LINE_RATE_BURST), UVM_NONE)
    end

    set_tx_ppm(PPM_ZERO);
    #200ns;
  end

  `uvm_info("PPM_SOAK_002_I1", "PASS: I1 complete", UVM_NONE)
endtask

// =============================================================================
// I2: 10,000+ Frame Endurance Soak at +100 ppm
//
// Extended duration sustained traffic at +100 ppm to exercise long-running
// rate-matching.  Uses 10,000 frames with extended timeout.
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::run_10k_endurance();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_SOAK_002", $sformatf("--- I2: %0d Frame Endurance at +100 ppm ---",
            SOAK_COUNT), UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_PLUS_100);
  set_rx_ppm(0);
  #200ns;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    ppm_clk_tol_seq_c ppm_seq_h;
    ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i2_endurance");
    fork
      ppm_seq_h.send_sustained_line_rate(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h,
          SOAK_COUNT);
    join_none
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + SOAK_COUNT,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 100, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  if (timed_out) begin
    `uvm_error("PPM_SOAK_002_I2", $sformatf(
               "FAIL: timeout (received %0d of %0d)", tx_after - tx_before, SOAK_COUNT))
  end else if ((tx_after - tx_before) < SOAK_COUNT) begin
    `uvm_error("PPM_SOAK_002_I2", $sformatf(
               "FAIL: frame loss (received %0d of %0d)", tx_after - tx_before, SOAK_COUNT))
  end else begin
    `uvm_info("PPM_SOAK_002_I2", $sformatf(
              "PASS: %0d frames lossless endurance at +100 ppm", SOAK_COUNT), UVM_NONE)
  end

  set_tx_ppm(PPM_ZERO);
  #200ns;

  `uvm_info("PPM_SOAK_002_I2", "PASS: I2 complete", UVM_NONE)
endtask

// =============================================================================
// I3: Mixed Frame Size Soak at +/-100 ppm
//
// 5,000 mixed-size frames (round-robin 64B/1518B/9000B) at each boundary
// offset.  Verify lossless delivery.
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::run_mixed_frame_soak();
  int ppm_values[2]    = '{PPM_PLUS_100, PPM_MINUS_100};
  string ppm_labels[2] = '{"+100ppm", "-100ppm"};
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_SOAK_002", $sformatf("--- I3: %0d Mixed-Frame Soak ---",
            MIXED_SOAK_COUNT), UVM_LOW)

  enable_tx_rx();

  foreach (ppm_values[i]) begin
    `uvm_info("PPM_SOAK_002_I3", $sformatf("Mixed-frame soak at %0s", ppm_labels[i]),
              UVM_MEDIUM)

    set_tx_ppm(ppm_values[i]);
    set_rx_ppm(0);
    #200ns;

    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create($sformatf("i3_mixed_%0s", ppm_labels[i]));
      fork
        ppm_seq_h.send_mixed_frame_sizes(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h,
            MIXED_SOAK_COUNT);
      join_none
    end

    mac_wait_utils_c::wait_for_count_at_least(tx_before + MIXED_SOAK_COUNT,
        env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
        mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 80, timed_out);

    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    if (timed_out) begin
      `uvm_error("PPM_SOAK_002_I3", $sformatf(
                 "FAIL [%0s]: timeout (received %0d of %0d)",
                 ppm_labels[i], tx_after - tx_before, MIXED_SOAK_COUNT))
    end else if ((tx_after - tx_before) < MIXED_SOAK_COUNT) begin
      `uvm_error("PPM_SOAK_002_I3", $sformatf(
                 "FAIL [%0s]: frame loss (received %0d of %0d)",
                 ppm_labels[i], tx_after - tx_before, MIXED_SOAK_COUNT))
    end else begin
      `uvm_info("PPM_SOAK_002_I3", $sformatf(
                "PASS [%0s]: %0d mixed frames lossless",
                ppm_labels[i], MIXED_SOAK_COUNT), UVM_NONE)
    end

    set_tx_ppm(PPM_ZERO);
    #200ns;
  end

  `uvm_info("PPM_SOAK_002_I3", "PASS: I3 complete", UVM_NONE)
endtask

// =============================================================================
// I4: Randomized Legal PPM and IFG
//
// 200 iterations: random PPM from legal set {0, +/-20, +/-50, +/-100},
// random IFG via send_randomized_long_duration.  Verify all frames
// delivered.
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::run_random_ppm_ifg();
  int legal_ppms[7] = '{0, PPM_PLUS_20, PPM_MINUS_20, PPM_PLUS_50,
                        PPM_MINUS_50, PPM_PLUS_100, PPM_MINUS_100};
  int tx_before, tx_after;
  bit timed_out;
  int total_sent;

  `uvm_info("PPM_SOAK_002", $sformatf("--- I4: Random PPM/IFG (%0d iterations) ---",
            RANDOM_SOAK_COUNT), UVM_LOW)

  enable_tx_rx();

  total_sent = 0;
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  repeat (RANDOM_SOAK_COUNT) begin
    int rand_ppm;
    int rand_delay;

    // Random PPM offset from legal set
    rand_ppm = legal_ppms[$urandom_range(0, 6)];

    // Random delay between iterations (0 to 200ns)
    rand_delay = $urandom_range(0, 200);

    // Apply PPM
    set_tx_ppm(rand_ppm);
    #(rand_delay * 1ns);

    // Send 1 frame with randomized IPG
    begin
      axi_sequence_c tx_seq_h;
      tx_seq_h            = axi_sequence_c::type_id::create(
          $sformatf("i4_rand_%0d", total_sent));
      tx_seq_h.num_tx     = 1;
      tx_seq_h.payload_min = MIN_PAYLOAD;
      tx_seq_h.payload_max = JUMBO_PAYLOAD;
      tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
    end

    total_sent++;
  end

  // Wait for all frames to be delivered
  mac_wait_utils_c::wait_for_count_at_least(tx_before + RANDOM_SOAK_COUNT,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 30, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  if (timed_out) begin
    `uvm_error("PPM_SOAK_002_I4", $sformatf(
               "FAIL: timeout (received %0d of %0d)", tx_after - tx_before,
               RANDOM_SOAK_COUNT))
  end else if ((tx_after - tx_before) < RANDOM_SOAK_COUNT) begin
    `uvm_error("PPM_SOAK_002_I4", $sformatf(
               "FAIL: frame loss (received %0d of %0d)", tx_after - tx_before,
               RANDOM_SOAK_COUNT))
  end else begin
    `uvm_info("PPM_SOAK_002_I4", $sformatf(
              "PASS: %0d random frames delivered across legal PPM offsets",
              RANDOM_SOAK_COUNT), UVM_NONE)
  end

  set_tx_ppm(PPM_ZERO);
  #200ns;

  `uvm_info("PPM_SOAK_002_I4", "PASS: I4 complete", UVM_NONE)
endtask

// =============================================================================
// I5: Additional Stimuli
//
// I5a: Sweep intermediate legal offsets (0, +/-10, +/-25, +/-50, +/-75, +/-100)
//      with sustained traffic at each.
// I5b: Alternate positive/negative offsets with mixed frame sizes.
// I5c: Combine boundary offset (+100 ppm) with AXI RX backpressure and
//      sustained traffic.
// I5d: Randomized long-duration traffic at varying offsets.
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::run_additional_stimuli();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_SOAK_002", "--- I5: Additional Stimuli ---", UVM_LOW)

  enable_tx_rx();

  //--------------------------------------------------------------------
  // I5a: Intermediate offset sweep with sustained traffic
  //--------------------------------------------------------------------
  `uvm_info("PPM_SOAK_002_I5", "I5a: Intermediate offset sweep", UVM_MEDIUM)
  begin
    int intermediate_ppms[11] = '{0, 10, -10, 25, -25, 50, -50, 75, -75, 100, -100};
    foreach (intermediate_ppms[i]) begin
      set_tx_ppm(intermediate_ppms[i]);
      #100ns;

      tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i5a_%0dppm", intermediate_ppms[i]));
        fork
          ppm_seq_h.send_sustained_line_rate(
              env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 50);
        join_none
      end

      mac_wait_utils_c::wait_for_count_at_least(tx_before + 50,
          env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
          mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 10, timed_out);

      tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
      if (timed_out || (tx_after - tx_before) < 50)
        `uvm_error("PPM_SOAK_002_I5A", $sformatf(
                   "FAIL [%0dppm]: received %0d of 50",
                   intermediate_ppms[i], tx_after - tx_before))
      else
        `uvm_info("PPM_SOAK_002_I5A", $sformatf(
                  "PASS [%0dppm]: 50 frames delivered", intermediate_ppms[i]), UVM_NONE)

      #50ns;
    end
    set_tx_ppm(0);
    #100ns;
  end

  //--------------------------------------------------------------------
  // I5b: Alternate +/-ppm with mixed frame sizes
  //--------------------------------------------------------------------
  `uvm_info("PPM_SOAK_002_I5", "I5b: Alternate +/-ppm mixed sizes", UVM_MEDIUM)
  begin
    int alt_ppms[6] = '{100, -100, 50, -50, 100, -100};
    foreach (alt_ppms[i]) begin
      set_tx_ppm(alt_ppms[i]);
      #100ns;

      tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i5b_alt_%0d", i));
        fork
          ppm_seq_h.send_mixed_frame_sizes(
              env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 100);
        join_none
      end

      mac_wait_utils_c::wait_for_count_at_least(tx_before + 100,
          env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
          mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 15, timed_out);

      tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
      if (timed_out || (tx_after - tx_before) < 100)
        `uvm_error("PPM_SOAK_002_I5B", $sformatf(
                   "FAIL [%0dppm]: received %0d of 100",
                   alt_ppms[i], tx_after - tx_before))
      else
        `uvm_info("PPM_SOAK_002_I5B", $sformatf(
                  "PASS [%0dppm]: 100 mixed frames delivered", alt_ppms[i]), UVM_NONE)

      #50ns;
    end
    set_tx_ppm(0);
    #100ns;
  end

  //--------------------------------------------------------------------
  // I5c: Boundary offset + AXI RX backpressure + sustained traffic
  //--------------------------------------------------------------------
  `uvm_info("PPM_SOAK_002_I5", "I5c: Boundary offset + backpressure", UVM_MEDIUM)
  begin
    set_tx_ppm(PPM_PLUS_100);
    set_rx_ppm(PPM_MINUS_100);
    #200ns;

    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    fork
      begin
        // Sustained traffic
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i5c_sustained");
        ppm_seq_h.send_sustained_line_rate(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 200);
      end
      begin
        // Apply intermittent backpressure on AXI RX
        repeat (10) begin
          axi_rx_vif.tready <= 1'b0;
          #200ns;
          axi_rx_vif.tready <= 1'b1;
          #200ns;
        end
      end
    join

    mac_wait_utils_c::wait_for_count_at_least(tx_before + 200,
        env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
        mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 30, timed_out);

    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    axi_rx_vif.tready <= 1'b1;

    if (timed_out || (tx_after - tx_before) < 200)
      `uvm_error("PPM_SOAK_002_I5C", $sformatf(
                 "FAIL: received %0d of 200", tx_after - tx_before))
    else
      `uvm_info("PPM_SOAK_002_I5C",
                "PASS: 200 frames delivered with backpressure", UVM_NONE)

    set_tx_ppm(0);
    set_rx_ppm(0);
    #200ns;
  end

  //--------------------------------------------------------------------
  // I5d: Randomized long-duration traffic at varying offsets
  //--------------------------------------------------------------------
  `uvm_info("PPM_SOAK_002_I5", "I5d: Randomized long-duration", UVM_MEDIUM)
  begin
    int long_ppms[3] = '{0, 75, -75};
    foreach (long_ppms[i]) begin
      set_tx_ppm(long_ppms[i]);
      #100ns;

      tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i5d_long_%0d", i));
        fork
          ppm_seq_h.send_randomized_long_duration(
              env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 200);
        join_none
      end

      mac_wait_utils_c::wait_for_count_at_least(tx_before + 200,
          env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
          mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 30, timed_out);

      tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

      if (timed_out || (tx_after - tx_before) < 200)
        `uvm_error("PPM_SOAK_002_I5D", $sformatf(
                   "FAIL [%0dppm]: received %0d of 200",
                   long_ppms[i], tx_after - tx_before))
      else
        `uvm_info("PPM_SOAK_002_I5D", $sformatf(
                  "PASS [%0dppm]: 200 randomized frames delivered",
                  long_ppms[i]), UVM_NONE)

      #100ns;
    end
    set_tx_ppm(0);
    #200ns;
  end

  `uvm_info("PPM_SOAK_002_I5", "PASS: I5 complete", UVM_NONE)
endtask

// =============================================================================
// run_stimulus — orchestrates all five iterations
// =============================================================================
task PPM_SOAK_002_ppm_soak_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("PPM_SOAK_002", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("PPM_SOAK_002", "MAC reset and APB bootstrap did not complete")

  `uvm_info("PPM_SOAK_002", "=== PPM_SOAK-002 / PPM_SOAK_002 START ===", UVM_LOW)

  run_sustained_line_rate();   // I1
  run_10k_endurance();         // I2
  run_mixed_frame_soak();      // I3
  run_random_ppm_ifg();        // I4
  run_additional_stimuli();    // I5

  // Final cleanup
  set_tx_ppm(PPM_ZERO);
  set_rx_ppm(PPM_ZERO);
  axi_rx_vif.tready <= 1'b1;

  `uvm_info("PPM_SOAK_002", "=== PPM_SOAK-002 / PPM_SOAK_002 ALL ITERATIONS COMPLETE ===",
            UVM_NONE)
endtask

`endif  // PPM_SOAK_002_PPM_SOAK_TEST_SVH
