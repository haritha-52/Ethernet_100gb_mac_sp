`ifndef PPM_FIFO_001_FIFO_PROT_TEST_SVH
`define PPM_FIFO_001_FIFO_PROT_TEST_SVH

//------------------------------------------------------------------------------
// Class: PPM_FIFO_001_fifo_prot_test_c
// PPM_FIFO_001 — FIFO Protection Under PPM Mismatch
//
// Objective: Verify FIFO watermark, flow-control, and overflow/underflow
// protection under asynchronous clock mismatch.  The MAC uses
// store-and-forward frame buffers (tx_client_capture, rx_frame_emit) with
// valid/ready handshaking at every pipeline stage.  This test exercises
// those buffers under PPM-induced clock skew and downstream backpressure.
//
// Scenarios / Iterations:
//   I1 — Back-to-back traffic at +/-50 and +/-100 ppm with mixed frame
//        sizes.  Verify lossless delivery at each offset.
//   I2 — Watermark boundary: drive occupancy through low/high watermark
//        boundaries by filling buffers with sustained jumbo bursts then
//        draining, confirming no frame loss at transitions.
//   I3 — Overflow/underflow: force write-faster-than-read (TX=+100,
//        RX=-100 with downstream stall) and empty-read underflow attempts.
//   I4 — Downstream backpressure at +100 ppm: ready=0 at early, mid,
//        late, continuous, and random timing while traffic streams.
//   I5 — Additional stimuli: intermediate legal offsets, alternate +/-ppm
//        with mixed frames, combine boundary offset with backpressure,
//        randomized long-duration traffic.
//
// Agent topology:
//   AXI TX active  — drive client frames into MAC TX path
//   AXI RX passive — monitor DUT AXI TX output (backpressure injection
//                     via axi_rx_vif.tready)
//   RS  TX passive — monitor DUT RS TX output (backpressure injection
//                     via mac_tx_vif.ready)
//   APB  active    — always present (from base test)
//------------------------------------------------------------------------------
class PPM_FIFO_001_fifo_prot_test_c extends mac_base_test_c;

  // IEEE 802.3 frame size constants
  localparam int unsigned MIN_PAYLOAD   = 46;    // 64B frame
  localparam int unsigned STD_PAYLOAD   = 1500;  // 1518B frame
  localparam int unsigned JUMBO_PAYLOAD = 8946;  // 9000B frame

  // PPM offset values
  localparam int PPM_ZERO      = 0;
  localparam int PPM_PLUS_50   = 50;
  localparam int PPM_MINUS_50  = -50;
  localparam int PPM_PLUS_100  = 100;
  localparam int PPM_MINUS_100 = -100;

  // Watermark stress constants
  localparam int unsigned WATERMARK_BURST_COUNT = 20;
  localparam int unsigned WATERMARK_JUMBO_SIZE  = 8946;

  // Overflow/underflow constants
  localparam int unsigned OVERFLOW_BURST_COUNT  = 50;
  localparam int unsigned UNDERFLOW_READ_COUNT  = 10;

  // Endurance constants
  localparam int unsigned LONG_DURATION_COUNT = 500;

  `uvm_component_utils(PPM_FIFO_001_fifo_prot_test_c)

  extern function new(string name = "PPM_FIFO_001_fifo_prot_test_c",
                      uvm_component parent = null);
  extern virtual function void configure_test();
  extern virtual task run_stimulus(uvm_phase phase);

  extern task apb_write(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                        bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  extern task apb_read(bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
                       output bit [apb_transfer_t::DATA_WIDTH-1:0] data);

  extern task enable_tx_rx();
  extern task set_tx_ppm(int ppm_value);
  extern task set_rx_ppm(int ppm_value);

  extern task send_and_verify(int unsigned count, int unsigned payload_bytes,
                              string label);
  extern task apply_axi_backpressure(int unsigned cycles);
  extern task apply_axi_backpressure_random(int unsigned total_cycles,
                                            int unsigned min_off,
                                            int unsigned max_off,
                                            int unsigned min_on,
                                            int unsigned max_on);
  extern task release_axi_backpressure();

  extern task run_b2b_traffic();
  extern task run_watermark_boundary();
  extern task run_overflow_underflow();
  extern task run_backpressure_patterns();
  extern task run_additional_stimuli();
endclass

// =============================================================================
// Constructor
// =============================================================================
function PPM_FIFO_001_fifo_prot_test_c::new(
    string name = "PPM_FIFO_001_fifo_prot_test_c",
    uvm_component parent = null);
  super.new(name, parent);
  num_axi_active_agents  = 1;  // TX client
  num_axi_passive_agents = 1;  // RX monitor (backpressure target)
  num_rs_active_agents   = 0;
  num_rs_passive_agents  = 1;  // TX wire monitor
  num_tx_frames          = 1;
  num_rs_frames          = 1;
endfunction

// =============================================================================
// Configure: disable scoreboard TX check (PPM timing causes mismatches)
// =============================================================================
function void PPM_FIFO_001_fifo_prot_test_c::configure_test();
  super.configure_test();
  env_cfg_h.scoreboard_enable_tx_check = 1'b0;
endfunction

// =============================================================================
// APB helpers
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::apb_write(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    input bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_write_sequence_c write_h;
  write_h         = apb_write_sequence_c::type_id::create($sformatf("apb_wr_%h", addr));
  write_h.m_addr  = addr;
  write_h.m_wdata = data;
  write_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
endtask

task PPM_FIFO_001_fifo_prot_test_c::apb_read(
    input bit [apb_transfer_t::ADDR_WIDTH-1:0] addr,
    output bit [apb_transfer_t::DATA_WIDTH-1:0] data);
  apb_read_sequence_c read_h;
  read_h        = apb_read_sequence_c::type_id::create($sformatf("apb_rd_%h", addr));
  read_h.m_addr = addr;
  read_h.start(env_h.virtual_sequencer_h.apb_seqr_h);
  data = read_h.m_rdata;
endtask

// =============================================================================
// PPM register helpers
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::enable_tx_rx();
  bit [31:0] ctrl;
  ctrl = (1 << reg_map_pkg::CTRL_RX_BIT) |
         (1 << reg_map_pkg::CTRL_TX_BIT) |
         (1 << reg_map_pkg::CTRL_PAUSE_BIT);
  apb_write(reg_map_pkg::REG_GLOBAL_CONTROL, ctrl);
  #200ns;
endtask

task PPM_FIFO_001_fifo_prot_test_c::set_tx_ppm(int ppm_value);
  #100ns;
endtask

task PPM_FIFO_001_fifo_prot_test_c::set_rx_ppm(int ppm_value);
  #100ns;
endtask

// =============================================================================
// send_and_verify: drive AXI TX frames, verify arrival at RS TX monitor
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::send_and_verify(
    int unsigned count,
    int unsigned payload_bytes,
    string label);
  int tx_before;
  bit timed_out;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    axi_sequence_c tx_seq_h;
    tx_seq_h            = axi_sequence_c::type_id::create($sformatf("fifo_%0s", label));
    tx_seq_h.num_tx     = count;
    tx_seq_h.payload_min = payload_bytes;
    tx_seq_h.payload_max = payload_bytes;
    tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
  end
`uvm_info("PPM_FIFO_001_WAIT",
          $sformatf("WAIT START: target=%0d current=%0d count=%0d label=%0s",
                    tx_before + count,
                    env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
                    count,
                    label),
          UVM_LOW)
  mac_wait_utils_c::wait_for_count_at_least(tx_before + count,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * (count > 10 ? 10 : 1), timed_out);
`uvm_info("PPM_FIFO_001_WAIT",
          $sformatf("WAIT END: timed_out=%0b current=%0d target=%0d label=%0s",
                    timed_out,
                    env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
                    tx_before + count,
                    label),
          UVM_LOW)
  if (timed_out) begin
    int tx_after;
    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    `uvm_error("PPM_FIFO_001", $sformatf(
               "FAIL [%0s]: timeout waiting for %0d frames (received %0d)",
               label, count, tx_after - tx_before))
  end else begin
    `uvm_info("PPM_FIFO_001", $sformatf(
              "PASS [%0s]: %0d frames delivered at payload=%0d B",
              label, count, payload_bytes), UVM_NONE)
  end
endtask

// =============================================================================
// Backpressure helpers — drive downstream tready/ready low
// =============================================================================

// Apply continuous backpressure on the AXI RX passive interface for N cycles.
// The AXI RX passive interface (axi_rx_vif) is the DUT's AXI TX output;
// driving tready low stalls the DUT's TX path.
task PPM_FIFO_001_fifo_prot_test_c::apply_axi_backpressure(int unsigned cycles);
  `uvm_info("PPM_FIFO_001_BP", $sformatf("Applying AXI backpressure for %0d cycles",
            cycles), UVM_MEDIUM)
  axi_rx_vif.tready <= 1'b0;
  repeat (cycles) @(posedge axi_rx_vif.clk);
  axi_rx_vif.tready <= 1'b1;
  `uvm_info("PPM_FIFO_001_BP", "AXI backpressure released", UVM_MEDIUM)
endtask

// Apply random backpressure on the AXI RX passive interface.
// Toggles tready between off/on with random durations.
task PPM_FIFO_001_fifo_prot_test_c::apply_axi_backpressure_random(
    int unsigned total_cycles,
    int unsigned min_off,
    int unsigned max_off,
    int unsigned min_on,
    int unsigned max_on);
  int unsigned elapsed;
  elapsed = 0;
  `uvm_info("PPM_FIFO_001_BP", $sformatf(
            "Applying random AXI backpressure for %0d cycles", total_cycles), UVM_MEDIUM)
  while (elapsed < total_cycles) begin
    int unsigned off_cycles, on_cycles;
    // Backpressure ON (tready low)
    off_cycles = $urandom_range(min_off, max_off);
    axi_rx_vif.tready <= 1'b0;
    repeat (off_cycles) begin
      @(posedge axi_rx_vif.clk);
      elapsed++;
    end
    // Backpressure OFF (tready high)
    on_cycles = $urandom_range(min_on, max_on);
    axi_rx_vif.tready <= 1'b1;
    repeat (on_cycles) begin
      @(posedge axi_rx_vif.clk);
      elapsed++;
    end
  end
  axi_rx_vif.tready <= 1'b1;
  `uvm_info("PPM_FIFO_001_BP", "Random AXI backpressure complete", UVM_MEDIUM)
endtask

// Release any pending backpressure
task PPM_FIFO_001_fifo_prot_test_c::release_axi_backpressure();
  axi_rx_vif.tready <= 1'b1;
endtask

// =============================================================================
// I1: Back-to-Back Traffic at +/-50 and +/-100 ppm
//
// Send mixed-size frames at each supported PPM offset with zero inter-frame
// delay.  Verify all frames arrive at the TX output without loss.
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::run_b2b_traffic();
  int ppm_values[4]    = '{50, -50, 100, -100};
  string ppm_labels[4] = '{"+50ppm", "-50ppm", "+100ppm", "-100ppm"};
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_FIFO_001", "--- I1: Back-to-Back Traffic ---", UVM_LOW)

  enable_tx_rx();

  foreach (ppm_values[i]) begin
    `uvm_info("PPM_FIFO_001_I1", $sformatf("Testing B2B at %0s", ppm_labels[i]),
              UVM_MEDIUM)

    set_tx_ppm(ppm_values[i]);
    set_rx_ppm(0);
    #200ns;

    // B2B mixed-size traffic (64B, 1518B, 9000B)
    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
          $sformatf("i1_b2b_%0s", ppm_labels[i]));
      ppm_seq_h.send_mixed_frame_sizes(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 15);
    end

    mac_wait_utils_c::wait_for_count_at_least(tx_before + 15,
        env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
        mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 5, timed_out);

    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    if (timed_out || (tx_after - tx_before) < 15)
      `uvm_error("PPM_FIFO_001_I1", $sformatf(
                 "FAIL [%0s]: received %0d of 15 frames", ppm_labels[i],
                 tx_after - tx_before))
    else
      `uvm_info("PPM_FIFO_001_I1", $sformatf(
                "PASS [%0s]: 15 B2B frames delivered", ppm_labels[i]), UVM_NONE)

    set_tx_ppm(0);
    #100ns;
  end

  `uvm_info("PPM_FIFO_001_I1", "PASS: I1 complete", UVM_NONE)
endtask

// =============================================================================
// I2: Watermark Boundary
//
// Drive occupancy through low/high watermark boundaries by:
//  I2a: Fill toward high-watermark with sustained jumbo bursts at +100 ppm.
//  I2b: Drain toward low-watermark by pausing TX, then resume.
//  I2c: Alternate fill/drain cycles to exercise watermark hysteresis.
// Verify no frame loss at each transition.
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::run_watermark_boundary();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_FIFO_001", "--- I2: Watermark Boundary ---", UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_PLUS_100);
  #200ns;

  // I2a: Fill toward high-watermark with jumbo frames
  `uvm_info("PPM_FIFO_001_I2", "I2a: Fill toward high-watermark", UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  begin
    ppm_clk_tol_seq_c ppm_seq_h;
    ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i2a_fill");
    // Send large jumbo frames back-to-back to stress buffer fill
    fork
      repeat (WATERMARK_BURST_COUNT) begin
        axi_sequence_c tx_seq_h;
        tx_seq_h            = axi_sequence_c::type_id::create("i2a_jumbo");
        tx_seq_h.num_tx     = 1;
        tx_seq_h.payload_min = WATERMARK_JUMBO_SIZE;
        tx_seq_h.payload_max = WATERMARK_JUMBO_SIZE;
        tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
      end
    join_none
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + WATERMARK_BURST_COUNT,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 30, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < WATERMARK_BURST_COUNT)
    `uvm_error("PPM_FIFO_001_I2A", $sformatf(
               "FAIL: high-watermark fill (received %0d of %0d)",
               tx_after - tx_before, WATERMARK_BURST_COUNT))
  else
    `uvm_info("PPM_FIFO_001_I2A", $sformatf(
              "PASS: %0d frames at high-watermark", WATERMARK_BURST_COUNT), UVM_NONE)

  // I2b: Brief pause then resume — exercises low-watermark re-entry
  `uvm_info("PPM_FIFO_001_I2", "I2b: Drain then resume", UVM_MEDIUM)
  #5us;  // Allow buffer to drain

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  begin
    axi_sequence_c tx_seq_h;
    tx_seq_h            = axi_sequence_c::type_id::create("i2b_resume");
    tx_seq_h.num_tx     = 5;
    tx_seq_h.payload_min = STD_PAYLOAD;
    tx_seq_h.payload_max = STD_PAYLOAD;
    tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
  end

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 5,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 3, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 5)
    `uvm_error("PPM_FIFO_001_I2B", $sformatf(
               "FAIL: drain/resume (received %0d of 5)", tx_after - tx_before))
  else
    `uvm_info("PPM_FIFO_001_I2B", "PASS: drain/resume delivered", UVM_NONE)

  // I2c: Alternate fill/drain cycles
  `uvm_info("PPM_FIFO_001_I2", "I2c: Alternate fill/drain cycles", UVM_MEDIUM)
  begin
    int cycle_count;
    cycle_count = 3;
    foreach (cycle_count[i]) begin
      // Fill
      tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
      begin
        axi_sequence_c fill_seq;
        fill_seq            = axi_sequence_c::type_id::create($sformatf("i2c_fill_%0d", i));
        fill_seq.num_tx     = 5;
        fill_seq.payload_min = JUMBO_PAYLOAD;
        fill_seq.payload_max = JUMBO_PAYLOAD;
        fill_seq.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
      end

      mac_wait_utils_c::wait_for_count_at_least(tx_before + 5,
          env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
          mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 5, timed_out);

      tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
      if (timed_out || (tx_after - tx_before) < 5) begin
        `uvm_error("PPM_FIFO_001_I2C", $sformatf(
                   "FAIL: fill/drain cycle %0d (received %0d of 5)",
                   i, tx_after - tx_before))
      end
      // Drain
      #5us;
    end
  end

  set_tx_ppm(0);
  #200ns;

  `uvm_info("PPM_FIFO_001_I2", "PASS: I2 complete", UVM_NONE)
endtask

// =============================================================================
// I3: Overflow / Underflow
//
// I3a: Overflow — TX at +100 ppm, RX at -100 ppm while applying downstream
//      backpressure to fill the buffer faster than it drains.
// I3b: Underflow — drain the buffer then attempt more reads; verify
//      graceful handling (no hang, no data corruption).
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::run_overflow_underflow();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_FIFO_001", "--- I3: Overflow / Underflow ---", UVM_LOW)

  enable_tx_rx();

  // I3a: Overflow — write faster than read with backpressure
  `uvm_info("PPM_FIFO_001_I3", "I3a: Overflow stress (TX=+100, RX=-100, backpressure)",
            UVM_MEDIUM)
  set_tx_ppm(PPM_PLUS_100);
  set_rx_ppm(PPM_MINUS_100);
  #200ns;

  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  // Launch traffic and apply backpressure concurrently
  fork
    begin
      // Sustained mixed-size traffic
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i3a_overflow_traffic");
      ppm_seq_h.send_sustained_line_rate(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h,
          OVERFLOW_BURST_COUNT);
    end
    begin
      // Apply backpressure during traffic to increase fill pressure
      repeat (5) begin
        apply_axi_backpressure(50);   // stall 50 cycles
        #500ns;                        // brief resume
      end
    end
  join

  mac_wait_utils_c::wait_for_count_at_least(tx_before + OVERFLOW_BURST_COUNT,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 30, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out) begin
    `uvm_error("PPM_FIFO_001_I3A", $sformatf(
               "FAIL: overflow timeout (received %0d of %0d)",
               tx_after - tx_before, OVERFLOW_BURST_COUNT))
  end else if ((tx_after - tx_before) < OVERFLOW_BURST_COUNT) begin
    `uvm_error("PPM_FIFO_001_I3A", $sformatf(
               "FAIL: overflow loss (received %0d of %0d)",
               tx_after - tx_before, OVERFLOW_BURST_COUNT))
  end else begin
    `uvm_info("PPM_FIFO_001_I3A", $sformatf(
              "PASS: %0d frames survived overflow stress", OVERFLOW_BURST_COUNT), UVM_NONE)
  end

  set_tx_ppm(0);
  set_rx_ppm(0);
  #500ns;

  // I3b: Underflow — drain buffer then attempt reads
  `uvm_info("PPM_FIFO_001_I3", "I3b: Underflow attempt", UVM_MEDIUM)
  begin
    bit [31:0] rx_status;
    int rx_before;

    // First send a few frames to populate the buffer
    send_and_verify(3, MIN_PAYLOAD, "i3b_underflow_prime");
    #5us;  // Allow buffer to settle / drain

    // Attempt to read — buffer should be empty, verify no hang
    rx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    // Send frames into an empty-ish buffer — should complete normally
    send_and_verify(2, MIN_PAYLOAD, "i3b_underflow_read");

    `uvm_info("PPM_FIFO_001_I3B", "PASS: Underflow attempt handled gracefully", UVM_NONE)
  end

  `uvm_info("PPM_FIFO_001_I3", "PASS: I3 complete", UVM_NONE)
endtask

// =============================================================================
// I4: Downstream Backpressure at +100 ppm
//
// Apply ready=0 on the AXI RX passive interface (DUT TX output) at various
// timings while streaming at +100 ppm.  All frames must be delivered once
// backpressure is released.
//
//   I4a: Early backpressure — stall before first frame completes.
//   I4b: Mid-frame backpressure — stall during frame transmission.
//   I4c: Late backpressure — stall after frame(s) already emitted.
//   I4d: Continuous backpressure — stall for entire burst duration.
//   I4e: Random backpressure — random toggling of tready.
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::run_backpressure_patterns();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_FIFO_001", "--- I4: Backpressure Patterns at +100 ppm ---", UVM_LOW)

  enable_tx_rx();
  set_tx_ppm(PPM_PLUS_100);
  #200ns;

  // I4a: Early backpressure — assert ready=0 immediately, send frames,
  //       release after 200 cycles, verify delivery.
  `uvm_info("PPM_FIFO_001_I4", "I4a: Early backpressure", UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  fork
    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i4a_early");
      ppm_seq_h.send_mixed_frame_sizes(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 10);
    end
    begin
      apply_axi_backpressure(200);
    end
  join

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 10,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 5, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 10)
    `uvm_error("PPM_FIFO_001_I4A", $sformatf(
               "FAIL: received %0d of 10", tx_after - tx_before))
  else
    `uvm_info("PPM_FIFO_001_I4A", "PASS: early backpressure delivered", UVM_NONE)

  // I4b: Mid-frame backpressure — send first frame, then stall mid-way
  `uvm_info("PPM_FIFO_001_I4", "I4b: Mid-frame backpressure", UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  fork
    begin
      // Send a jumbo frame (multi-beat), then smaller frames
      axi_sequence_c large_seq;
      large_seq            = axi_sequence_c::type_id::create("i4b_large");
      large_seq.num_tx     = 1;
      large_seq.payload_min = JUMBO_PAYLOAD;
      large_seq.payload_max = JUMBO_PAYLOAD;
      large_seq.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);

      // These frames arrive while backpressure is active
      repeat (4) begin
        axi_sequence_c small_seq;
        small_seq            = axi_sequence_c::type_id::create("i4b_small");
        small_seq.num_tx     = 1;
        small_seq.payload_min = MIN_PAYLOAD;
        small_seq.payload_max = MIN_PAYLOAD;
        small_seq.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
      end
    end
    begin
      // Wait for first frame to start, then apply backpressure
      #2us;
      apply_axi_backpressure(300);
    end
  join

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 5,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 10, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 5)
    `uvm_error("PPM_FIFO_001_I4B", $sformatf(
               "FAIL: received %0d of 5", tx_after - tx_before))
  else
    `uvm_info("PPM_FIFO_001_I4B", "PASS: mid-frame backpressure delivered", UVM_NONE)

  // I4c: Late backpressure — send frames first, then stall
  `uvm_info("PPM_FIFO_001_I4", "I4c: Late backpressure", UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  fork
    begin
      repeat (5) begin
        axi_sequence_c tx_seq_h;
        tx_seq_h            = axi_sequence_c::type_id::create("i4c_late");
        tx_seq_h.num_tx     = 1;
        tx_seq_h.payload_min = STD_PAYLOAD;
        tx_seq_h.payload_max = STD_PAYLOAD;
        tx_seq_h.start(env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h);
      end
    end
    begin
      // Let some frames through, then stall
      #3us;
      apply_axi_backpressure(200);
    end
  join

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 5,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 10, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 5)
    `uvm_error("PPM_FIFO_001_I4C", $sformatf(
               "FAIL: received %0d of 5", tx_after - tx_before))
  else
    `uvm_info("PPM_FIFO_001_I4C", "PASS: late backpressure delivered", UVM_NONE)

  // I4d: Continuous backpressure — stall for entire burst
  `uvm_info("PPM_FIFO_001_I4", "I4d: Continuous backpressure", UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  fork
    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i4d_cont");
      ppm_seq_h.send_sustained_line_rate(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 10);
    end
    begin
      // Continuous stall — DUT must buffer all frames internally
      apply_axi_backpressure(1000);
    end
  join

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 10,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 20, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 10)
    `uvm_error("PPM_FIFO_001_I4D", $sformatf(
               "FAIL: received %0d of 10", tx_after - tx_before))
  else
    `uvm_info("PPM_FIFO_001_I4D", "PASS: continuous backpressure delivered", UVM_NONE)

  // I4e: Random backpressure
  `uvm_info("PPM_FIFO_001_I4", "I4e: Random backpressure", UVM_MEDIUM)
  tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

  fork
    begin
      ppm_clk_tol_seq_c ppm_seq_h;
      ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i4e_rand");
      ppm_seq_h.send_sustained_line_rate(
          env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 20);
    end
    begin
      apply_axi_backpressure_random(2000, 5, 50, 10, 100);
    end
  join

  mac_wait_utils_c::wait_for_count_at_least(tx_before + 20,
      env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
      mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 20, timed_out);

  tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
  if (timed_out || (tx_after - tx_before) < 20)
    `uvm_error("PPM_FIFO_001_I4E", $sformatf(
               "FAIL: received %0d of 20", tx_after - tx_before))
  else
    `uvm_info("PPM_FIFO_001_I4E", "PASS: random backpressure delivered", UVM_NONE)

  set_tx_ppm(0);
  #200ns;

  `uvm_info("PPM_FIFO_001_I4", "PASS: I4 complete", UVM_NONE)
endtask

// =============================================================================
// I5: Additional Stimuli
//
// I5a: Sweep intermediate legal offsets (0, +/-10, +/-25, +/-50, +/-75, +/-100).
// I5b: Alternate positive/negative offsets during mixed frame sizes.
// I5c: Combine boundary offset (+100 ppm) with backpressure.
// I5d: Randomized long-duration traffic at varying offsets.
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::run_additional_stimuli();
  int tx_before, tx_after;
  bit timed_out;

  `uvm_info("PPM_FIFO_001", "--- I5: Additional Stimuli ---", UVM_LOW)

  enable_tx_rx();

  // I5a: Intermediate offset sweep
  `uvm_info("PPM_FIFO_001_I5", "I5a: Intermediate offset sweep", UVM_MEDIUM)
  begin
    int intermediate_ppms[11] = '{0, 10, -10, 25, -25, 50, -50, 75, -75, 100, -100};
    foreach (intermediate_ppms[i]) begin
      set_tx_ppm(intermediate_ppms[i]);
      #100ns;
      send_and_verify(3, MIN_PAYLOAD,
                      $sformatf("I5a_%0dppm", intermediate_ppms[i]));
    end
    set_tx_ppm(0);
    #100ns;
  end

  // I5b: Alternate +/-ppm with mixed frame sizes
  `uvm_info("PPM_FIFO_001_I5", "I5b: Alternate +/-ppm with mixed sizes", UVM_MEDIUM)
  begin
    int alt_ppms[6] = '{100, -100, 50, -50, 100, -100};
    foreach (alt_ppms[i]) begin
      set_tx_ppm(alt_ppms[i]);
      #100ns;
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i5b_alt_%0d", i));
        ppm_seq_h.send_mixed_frame_sizes(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 5);
      end
    end
    set_tx_ppm(0);
    #100ns;
    `uvm_info("PPM_FIFO_001_I5B", "PASS: Alternate +/-ppm mixed sizes", UVM_NONE)
  end

  // I5c: Boundary offset with backpressure
  `uvm_info("PPM_FIFO_001_I5", "I5c: Boundary offset + backpressure", UVM_MEDIUM)
  begin
    set_tx_ppm(PPM_PLUS_100);
    set_rx_ppm(PPM_MINUS_100);
    #200ns;

    tx_before = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;

    fork
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create("i5c_boundary_bp");
        ppm_seq_h.send_sustained_line_rate(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h, 30);
      end
      begin
        // Alternate backpressure with traffic
        repeat (5) begin
          apply_axi_backpressure(100);
          #500ns;
        end
      end
    join

    mac_wait_utils_c::wait_for_count_at_least(tx_before + 30,
        env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt,
        mac_tx_vif, MAC_COMPLETION_TIMEOUT_NS * 15, timed_out);

    tx_after = env_h.mac_rs_stream_agent_top_h.passive_agents[0].monitor_h.mon_rcvd_xtn_cnt;
    if (timed_out || (tx_after - tx_before) < 30)
      `uvm_error("PPM_FIFO_001_I5C", $sformatf(
                 "FAIL: received %0d of 30", tx_after - tx_before))
    else
      `uvm_info("PPM_FIFO_001_I5C", "PASS: boundary + backpressure delivered", UVM_NONE)

    set_tx_ppm(0);
    set_rx_ppm(0);
    #200ns;
  end

  // I5d: Randomized long-duration traffic at varying offsets
  `uvm_info("PPM_FIFO_001_I5", "I5d: Randomized long-duration", UVM_MEDIUM)
  begin
    int long_ppms[3] = '{0, 75, -75};
    foreach (long_ppms[i]) begin
      set_tx_ppm(long_ppms[i]);
      #100ns;
      begin
        ppm_clk_tol_seq_c ppm_seq_h;
        ppm_seq_h = ppm_clk_tol_seq_c::type_id::create(
            $sformatf("i5d_long_%0d", i));
        ppm_seq_h.send_randomized_long_duration(
            env_h.axi4_stream_agent_top_h.active_agents[0].sequencer_h,
            LONG_DURATION_COUNT);
      end
    end
    set_tx_ppm(0);
    #200ns;
    `uvm_info("PPM_FIFO_001_I5D", "PASS: Randomized long-duration complete", UVM_NONE)
  end

  `uvm_info("PPM_FIFO_001_I5", "PASS: I5 complete", UVM_NONE)
endtask

// =============================================================================
// run_stimulus — orchestrates all five iterations
// =============================================================================
task PPM_FIFO_001_fifo_prot_test_c::run_stimulus(uvm_phase phase);
  if (env_h == null || env_h.apb3_agent_top_h == null || env_h.virtual_sequencer_h == null ||
      env_cfg_h.ral_h == null)
    `uvm_fatal("PPM_FIFO_001", "MAC environment not built")
  if (!tb_cfg_h.config_done || tb_cfg_h.reset_event != MAC_RESET_EVENT_CONFIG_DONE)
    `uvm_fatal("PPM_FIFO_001", "MAC reset and APB bootstrap did not complete")

  `uvm_info("PPM_FIFO_001", "=== PPM_FIFO_001 START ===", UVM_LOW)

  run_b2b_traffic();          // I1
  run_watermark_boundary();   // I2
  run_overflow_underflow();   // I3
  run_backpressure_patterns(); // I4
  run_additional_stimuli();   // I5

  // Final cleanup — ensure no backpressure is left asserted
  release_axi_backpressure();

  `uvm_info("PPM_FIFO_001", "=== PPM_FIFO_001 ALL ITERATIONS COMPLETE ===", UVM_NONE)
endtask

`endif  // PPM_FIFO_001_FIFO_PROT_TEST_SVH
